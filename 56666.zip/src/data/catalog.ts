export interface Product {
  id: number;
  name: string;
  price: number;
  /** Ключ бренда товара (см. Brand). Назначается в админ-панели. */
  brandId?: string;
  /** Название серии / линейки производителя (например, «Труба полипропиленовая армированная стекловолокном PN25 VALFEX»). Задаётся в админке для объединения диаметров в один блок. */
  seriesName?: string;
  /** Размерность / диаметр товара внутри серии (например, «20x3,4 мм» или «25x4,2 мм»). */
  sizeLabel?: string;
  /** Старая цена до скидки. Показывается зачёркнутой, если она выше price. */
  oldPrice?: number;
  description: string;
  inStock: boolean;
  category: string;
  subcategory?: string;
  code: string;
  image?: string;
  /** Галерея изображений товара (dataURL или URL). */
  gallery?: string[];
  characteristics?: ProductCharacteristic[];
  /** Единица измерения: "шт" (по умолчанию) или "м" (за метр). */
  unit?: "шт" | "м";
  /** Минимальное количество метров для продажи (если unit === "м"). */
  minMeters?: number;
  /** Показывать в карточке строку «Гарантия производителя 12 месяцев».
   * Включается в админке только для технически сложных товаров. */
  warranty?: boolean;
}

export interface ProductCharacteristic {
  name: string;
  value: string;
}

/** Бренд товара. Создаётся и редактируется в админ-панели (вкладка «Бренды»). */
export interface Brand {
  key: string;
  name: string;
  /** Логотип бренда (dataURL или URL). */
  logo?: string;
  /** Страна — родина бренда (пишется в карточке товара). */
  countryOrigin?: string;
  /** Страна производства. */
  countryMade?: string;
  /** Краткая справка о бренде — открывается по иконке (i). */
  info?: string;
}

/** Флаги стран для карточки бренда. */
export const COUNTRY_FLAGS: Record<string, string> = {
  "Беларусь": "🇧🇾",
  "Германия": "🇩🇪",
  "Испания": "🇪🇸",
  "Италия": "🇮🇹",
  "Китай": "🇨🇳",
  "Корея": "🇰🇷",
  "Польша": "🇵🇱",
  "Россия": "🇷🇺",
  "Турция": "🇹🇷",
  "Финляндия": "🇫🇮",
  "Франция": "🇫🇷",
  "Чехия": "🇨🇿",
  "Швеция": "🇸🇪",
  "Япония": "🇯🇵",
};

export const COUNTRY_NAMES = Object.keys(COUNTRY_FLAGS);

/** Стартовый список брендов — дальше пополняется в админ-панели. */
export const DEFAULT_BRANDS: Brand[] = [
  {
    key: "ampm",
    name: "AM.PM",
    countryOrigin: "Германия",
    countryMade: "Германия",
    info: "Мебель и сантехника для ванной комнаты: смесители, душевые системы, аксессуары.",
  },
  {
    key: "belamos",
    name: "Belamos",
    countryOrigin: "Беларусь",
    countryMade: "Беларусь",
    info: "Скважинные, циркуляционные насосы и насосные станции для дома и участка.",
  },
  {
    key: "valtec",
    name: "Valtec",
    countryOrigin: "Италия",
    countryMade: "Италия",
    info: "Совместный российско-итальянский бренд трубной арматуры, фитинги и коллекторы.",
  },
];

export interface Subcategory {
  key: string;
  label: string;
  img?: string;
  /** Для старого каталога PPR: автоматическая привязка по части названия. */
  match?: string[];
}

export interface Category {
  key: string;
  label: string;
  img: string;
  subcategories?: Subcategory[];
}

export const DEFAULT_CATEGORIES: Category[] = [
  {
    key: "Насосы",
    label: "Насосное оборудование",
    img: "/images/cat-valves.png",
    subcategories: [
      { key: "Скважинные насосы", label: "Скважинные насосы" },
      { key: "Вибрационные насосы", label: "Вибрационные насосы" },
      { key: "Дренажные насосы", label: "Дренажные насосы" },
      { key: "Фекальные насосы", label: "Фекальные насосы" },
      { key: "Циркуляционные насосы", label: "Циркуляционные насосы" },
      { key: "Колодезные насосы", label: "Колодезные насосы" },
      { key: "Поверхностные насосы", label: "Поверхностные насосы" },
      { key: "Насосные станции", label: "Насосные станции" },
    ],
  },
  {
    key: "ppr",
    label: "PPR трубы и фитинги",
    img: "/images/cat-ppr.png",
    subcategories: [
      { key: "ppr-pipe", label: "PPR Труба", match: ["Труба"] },
      { key: "ppr-coupling", label: "PPR Муфта", match: ["Муфта"] },
      { key: "ppr-elbow", label: "PPR Уголок", match: ["Угольник", "Колено"] },
      { key: "ppr-union", label: "PPR Американка", match: ["Американка"] },
      { key: "ppr-valve", label: "PPR Кран", match: ["Кран"] },
      { key: "ppr-cross", label: "PPR Крестовина", match: ["Крестовина"] },
      { key: "ppr-cap", label: "PPR Заглушка", match: ["Заглушка"] },
    ],
  },
  {
    key: "544",
    label: "ПНД труба и фитинги",
    img: "/images/cat-ppr.png",
    subcategories: [
      { key: "ПНД Труба", label: "ПНД Труба" },
      { key: "ПНД Муфта", label: "ПНД Муфта" },
      { key: "ПНД Уголок", label: "ПНД Уголок" },
      { key: "ПНД Тройник", label: "ПНД Тройник" },
      { key: "ПНД Кран", label: "ПНД Кран" },
      { key: "ПНД Заглушка", label: "ПНД Заглушка" },
    ],
  },
  { key: "Канализация", label: "Канализация", img: "/images/cat-ppr.png" },
  { key: "Краны и Вентили", label: "Краны латунные", img: "/images/cat-valves.png" },
  {
    key: "Латунные Фитинги",
    label: "Фитинги латунные",
    img: "/images/cat-brass.png",
    subcategories: [
      { key: "Тройники", label: "Тройники" },
      { key: "Уголки", label: "Уголки" },
      { key: "Муфты", label: "Муфты" },
      { key: "Футорки", label: "Футорки" },
      { key: "Ниппели", label: "Ниппели" },
      { key: "Переходники", label: "Переходники" },
      { key: "Американки", label: "Американки" },
      { key: "Крестовины", label: "Крестовины" },
      { key: "Заглушки", label: "Заглушки" },
      { key: "Контргайки", label: "Контргайки" },
      { key: "Штуцеры", label: "Штуцеры" },
    ],
  },
  {
    key: "dushevye-kabiny",
    label: "Душевые кабины",
    img: "/images/cat-ppr.png",
    subcategories: [
      { key: "С низким поддоном", label: "С низким поддоном" },
      { key: "С средним поддоном", label: "С средним поддоном" },
      { key: "С высоким поддоном", label: "С высоким поддоном" },
    ],
  },
  { key: "Унитазы", label: "Унитазы и комплектующие", img: "/images/cat-ppr.png" },
  { key: "Ванны, экраны и комплектующие", label: "Ванны, экраны и комплектующие", img: "/images/cat-ppr.png" },
  { key: "Мойки, раковины, пьедесталы и комплектующие", label: "Мойки, раковины, пьедесталы и комплектующие", img: "/images/cat-ppr.png" },
];

export const DEFAULT_PRODUCTS: Product[] = [
  {
    "id": 1,
    "name": "Труба полипропиленовая Valtec PN25 20 мм (армированная стекловолокном)",
    "price": 170,
    "code": "VTp.705.0020",
    "category": "ppr",
    "subcategory": "ppr-pipe",
    "brandId": "valtec",
    "seriesName": "Труба полипропиленовая Valtec армированная стекловолокном PN25",
    "sizeLabel": "20×3,4 мм",
    "unit": "м",
    "minMeters": 2,
    "inStock": true,
    "image": "https://piter3tn.ru/image/cache/catalog/3tn_ru/wa-data/public/shop/products/27/11/1127/images/11014/11014.970-1000x1000.jpg",
    "description": "Труба полипропиленовая PPR, армированная стекловолокном (PN 25). Применяется в системах питьевого и хозяйственно-питьевого холодного и горячего водоснабжения, отопления.",
    "characteristics": [
      {
        "name": "Наружный диаметр",
        "value": "20 мм"
      },
      {
        "name": "Толщина стенки",
        "value": "3.4 мм"
      },
      {
        "name": "Номинальное давление",
        "value": "PN 25 (2.5 МПа)"
      },
      {
        "name": "Рабочая температура",
        "value": "до +90°C"
      },
      {
        "name": "Армирование",
        "value": "Стекловолокно (PPR-FB-PPR)"
      }
    ]
  },
  {
    "id": 2,
    "name": "Труба полипропиленовая Valtec PN25 25 мм (армированная стекловолокном)",
    "price": 225,
    "code": "VTp.705.0025",
    "category": "ppr",
    "subcategory": "ppr-pipe",
    "brandId": "valtec",
    "seriesName": "Труба полипропиленовая Valtec армированная стекловолокном PN25",
    "sizeLabel": "25×4,2 мм",
    "unit": "м",
    "minMeters": 2,
    "inStock": true,
    "description": "Труба PPR армированная стекловолокном 25 мм. Высокая термостойкость и минимальное линейное расширение.",
    "characteristics": [
      {
        "name": "Наружный диаметр",
        "value": "25 мм"
      },
      {
        "name": "Толщина стенки",
        "value": "4.2 мм"
      },
      {
        "name": "Номинальное давление",
        "value": "PN 25"
      },
      {
        "name": "Армирование",
        "value": "Стекловолокно"
      }
    ]
  },
  {
    "id": 3,
    "name": "Труба полипропиленовая Valtec PN25 32 мм (армированная стекловолокном)",
    "price": 380,
    "code": "VTp.705.0032",
    "category": "ppr",
    "subcategory": "ppr-pipe",
    "brandId": "valtec",
    "seriesName": "Труба полипропиленовая Valtec армированная стекловолокном PN25",
    "sizeLabel": "32×5,4 мм",
    "unit": "м",
    "minMeters": 2,
    "inStock": true,
    "description": "Труба PPR армированная стекловолокном 32 мм для стояков и магистралей.",
    "characteristics": [
      {
        "name": "Наружный диаметр",
        "value": "32 мм"
      },
      {
        "name": "Толщина стенки",
        "value": "5.4 мм"
      },
      {
        "name": "Номинальное давление",
        "value": "PN 25"
      }
    ]
  },
  {
    "id": 4,
    "name": "Труба полипропиленовая Valtec PN25 40 мм (армированная стекловолокном)",
    "price": 590,
    "code": "VTp.705.0040",
    "category": "ppr",
    "subcategory": "ppr-pipe",
    "brandId": "valtec",
    "seriesName": "Труба полипропиленовая Valtec армированная стекловолокном PN25",
    "sizeLabel": "40×6,7 мм",
    "unit": "м",
    "minMeters": 2,
    "inStock": true,
    "description": "Магистральная труба PPR 40 мм.",
    "characteristics": [
      {
        "name": "Наружный диаметр",
        "value": "40 мм"
      },
      {
        "name": "Толщина стенки",
        "value": "6.7 мм"
      }
    ]
  },
  {
    "id": 5,
    "name": "Труба полипропиленовая VALFEX PN25 20 мм (стекловолокно)",
    "price": 88,
    "code": "VF.PPR.20.25",
    "category": "ppr",
    "subcategory": "ppr-pipe",
    "seriesName": "Труба полипропиленовая армированная стекловолокном (PN 25) VALFEX",
    "sizeLabel": "20×3,4 мм",
    "unit": "м",
    "minMeters": 2,
    "inStock": true,
    "description": "Труба полипропиленовая армированная стекловолокном VALFEX для отопления и горячего водоснабжения.",
    "characteristics": [
      {
        "name": "Диаметр",
        "value": "20 мм"
      },
      {
        "name": "Давление",
        "value": "PN 25"
      }
    ]
  },
  {
    "id": 6,
    "name": "Труба полипропиленовая VALFEX PN25 25 мм (стекловолокно)",
    "price": 125,
    "code": "VF.PPR.25.25",
    "category": "ppr",
    "subcategory": "ppr-pipe",
    "seriesName": "Труба полипропиленовая армированная стекловолокном (PN 25) VALFEX",
    "sizeLabel": "25×4,2 мм",
    "unit": "м",
    "minMeters": 2,
    "inStock": true,
    "description": "Труба полипропиленовая армированная стекловолокном VALFEX 25 мм.",
    "characteristics": [
      {
        "name": "Диаметр",
        "value": "25 мм"
      },
      {
        "name": "Давление",
        "value": "PN 25"
      }
    ]
  },
  {
    "id": 7,
    "name": "Труба полипропиленовая VALFEX PN25 32 мм (стекловолокно)",
    "price": 205,
    "code": "VF.PPR.32.25",
    "category": "ppr",
    "subcategory": "ppr-pipe",
    "seriesName": "Труба полипропиленовая армированная стекловолокном (PN 25) VALFEX",
    "sizeLabel": "32×5,4 мм",
    "unit": "м",
    "minMeters": 2,
    "inStock": true,
    "description": "Труба полипропиленовая армированная стекловолокном VALFEX 32 мм.",
    "characteristics": [
      {
        "name": "Диаметр",
        "value": "32 мм"
      },
      {
        "name": "Давление",
        "value": "PN 25"
      }
    ]
  },
  {
    "id": 8,
    "name": "Труба полипропиленовая VALFEX PN25 40 мм (стекловолокно)",
    "price": 311,
    "code": "VF.PPR.40.25",
    "category": "ppr",
    "subcategory": "ppr-pipe",
    "seriesName": "Труба полипропиленовая армированная стекловолокном (PN 25) VALFEX",
    "sizeLabel": "40×6,7 мм",
    "unit": "м",
    "minMeters": 2,
    "inStock": true,
    "description": "Труба полипропиленовая армированная стекловолокном VALFEX 40 мм.",
    "characteristics": [
      {
        "name": "Диаметр",
        "value": "40 мм"
      },
      {
        "name": "Давление",
        "value": "PN 25"
      }
    ]
  },
  {
    "id": 9,
    "name": "Труба полипропиленовая SPK PN20 20 мм",
    "price": 75,
    "code": "SPK.20.20",
    "category": "ppr",
    "subcategory": "ppr-pipe",
    "seriesName": "Труба полипропиленовая SPK PN20",
    "sizeLabel": "20×3,4 мм",
    "unit": "м",
    "minMeters": 2,
    "inStock": true,
    "description": "Труба полипропиленовая однослойная SPK PN20 для систем холодного и умеренно горячего водоснабжения.",
    "characteristics": [
      {
        "name": "Диаметр",
        "value": "20 мм"
      },
      {
        "name": "Давление",
        "value": "PN 20"
      }
    ]
  },
  {
    "id": 10,
    "name": "Труба полипропиленовая SPK PN20 25 мм",
    "price": 112,
    "code": "SPK.25.20",
    "category": "ppr",
    "subcategory": "ppr-pipe",
    "seriesName": "Труба полипропиленовая SPK PN20",
    "sizeLabel": "25×4,2 мм",
    "unit": "м",
    "minMeters": 2,
    "inStock": true,
    "description": "Труба полипропиленовая SPK PN20 25 мм.",
    "characteristics": [
      {
        "name": "Диаметр",
        "value": "25 мм"
      },
      {
        "name": "Давление",
        "value": "PN 20"
      }
    ]
  },
  {
    "id": 11,
    "name": "Труба полипропиленовая SPK PN20 32 мм",
    "price": 185,
    "code": "SPK.32.20",
    "category": "ppr",
    "subcategory": "ppr-pipe",
    "seriesName": "Труба полипропиленовая SPK PN20",
    "sizeLabel": "32×5,4 мм",
    "unit": "м",
    "minMeters": 2,
    "inStock": true,
    "description": "Труба полипропиленовая SPK PN20 32 мм.",
    "characteristics": [
      {
        "name": "Диаметр",
        "value": "32 мм"
      },
      {
        "name": "Давление",
        "value": "PN 20"
      }
    ]
  },
  {
    "id": 12,
    "name": "Муфта полипропиленовая соединительная 20 мм",
    "price": 18,
    "code": "PPR-M20",
    "category": "ppr",
    "subcategory": "ppr-coupling",
    "inStock": true,
    "unit": "шт",
    "description": "Муфта PPR прямая 20 мм."
  },
  {
    "id": 13,
    "name": "Муфта полипропиленовая соединительная 25 мм",
    "price": 26,
    "code": "PPR-M25",
    "category": "ppr",
    "subcategory": "ppr-coupling",
    "inStock": true,
    "unit": "шт",
    "description": "Муфта PPR прямая 25 мм."
  },
  {
    "id": 14,
    "name": "Муфта полипропиленовая соединительная 32 мм",
    "price": 42,
    "code": "PPR-M32",
    "category": "ppr",
    "subcategory": "ppr-coupling",
    "inStock": true,
    "unit": "шт",
    "description": "Муфта PPR прямая 32 мм."
  },
  {
    "id": 15,
    "name": "Муфта полипропиленовая переходная 25x20 мм",
    "price": 24,
    "code": "PPR-MR2520",
    "category": "ppr",
    "subcategory": "ppr-coupling",
    "inStock": true,
    "unit": "шт",
    "description": "Редукционная муфта 25х20 мм."
  },
  {
    "id": 16,
    "name": "Муфта полипропиленовая переходная 32x25 мм",
    "price": 38,
    "code": "PPR-MR3225",
    "category": "ppr",
    "subcategory": "ppr-coupling",
    "inStock": true,
    "unit": "шт",
    "description": "Редукционная муфта 32х25 мм."
  },
  {
    "id": 17,
    "name": "Уголок полипропиленовый 90° 20 мм",
    "price": 20,
    "code": "PPR-E20-90",
    "category": "ppr",
    "subcategory": "ppr-elbow",
    "inStock": true,
    "unit": "шт",
    "description": "Угольник PPR 90 градусов 20 мм."
  },
  {
    "id": 18,
    "name": "Уголок полипропиленовый 90° 25 мм",
    "price": 28,
    "code": "PPR-E25-90",
    "category": "ppr",
    "subcategory": "ppr-elbow",
    "inStock": true,
    "unit": "шт",
    "description": "Угольник PPR 90 градусов 25 мм."
  },
  {
    "id": 19,
    "name": "Уголок полипропиленовый 90° 32 мм",
    "price": 48,
    "code": "PPR-E32-90",
    "category": "ppr",
    "subcategory": "ppr-elbow",
    "inStock": true,
    "unit": "шт",
    "description": "Угольник PPR 90 градусов 32 мм."
  },
  {
    "id": 20,
    "name": "Уголок полипропиленовый 45° 20 мм",
    "price": 24,
    "code": "PPR-E20-45",
    "category": "ppr",
    "subcategory": "ppr-elbow",
    "inStock": true,
    "unit": "шт",
    "description": "Угольник PPR 45 градусов 20 мм."
  },
  {
    "id": 21,
    "name": "Уголок полипропиленовый 45° 25 мм",
    "price": 32,
    "code": "PPR-E25-45",
    "category": "ppr",
    "subcategory": "ppr-elbow",
    "inStock": true,
    "unit": "шт",
    "description": "Угольник PPR 45 градусов 25 мм."
  },
  {
    "id": 22,
    "name": "Тройник полипропиленовый 20 мм",
    "price": 28,
    "code": "PPR-T20",
    "category": "ppr",
    "subcategory": "ppr-cross",
    "inStock": true,
    "unit": "шт",
    "description": "Тройник PPR равнопроходной 20 мм."
  },
  {
    "id": 23,
    "name": "Тройник полипропиленовый 25 мм",
    "price": 38,
    "code": "PPR-T25",
    "category": "ppr",
    "subcategory": "ppr-cross",
    "inStock": true,
    "unit": "шт",
    "description": "Тройник PPR равнопроходной 25 мм."
  },
  {
    "id": 24,
    "name": "Тройник полипропиленовый 32 мм",
    "price": 62,
    "code": "PPR-T32",
    "category": "ppr",
    "subcategory": "ppr-cross",
    "inStock": true,
    "unit": "шт",
    "description": "Тройник PPR равнопроходной 32 мм."
  },
  {
    "id": 25,
    "name": "Тройник полипропиленовый переходной 25x20x25 мм",
    "price": 42,
    "code": "PPR-TR2520",
    "category": "ppr",
    "subcategory": "ppr-cross",
    "inStock": true,
    "unit": "шт",
    "description": "Тройник редукционный 25х20х25 мм."
  },
  {
    "id": 26,
    "name": "Муфта с накидной гайкой (американка) PPR 20x1/2\" ВР",
    "price": 245,
    "code": "PPR-UN20-12",
    "category": "ppr",
    "subcategory": "ppr-union",
    "inStock": true,
    "unit": "шт",
    "description": "Разъемное соединение PPR с латунной резьбой 1/2\"."
  },
  {
    "id": 27,
    "name": "Муфта с накидной гайкой (американка) PPR 25x3/4\" ВР",
    "price": 360,
    "code": "PPR-UN25-34",
    "category": "ppr",
    "subcategory": "ppr-union",
    "inStock": true,
    "unit": "шт",
    "description": "Разъемное соединение PPR с латунной резьбой 3/4\"."
  },
  {
    "id": 28,
    "name": "Муфта комбинированная с внутренней резьбой 20x1/2\"",
    "price": 145,
    "code": "PPR-MRB20-12",
    "category": "ppr",
    "subcategory": "ppr-union",
    "inStock": true,
    "unit": "шт",
    "description": "Муфта PPR с латунной резьбой 1/2\"."
  },
  {
    "id": 29,
    "name": "Муфта комбинированная с наружной резьбой 20x1/2\"",
    "price": 165,
    "code": "PPR-MRE20-12",
    "category": "ppr",
    "subcategory": "ppr-union",
    "inStock": true,
    "unit": "шт",
    "description": "Муфта PPR с наружной латунной резьбой 1/2\"."
  },
  {
    "id": 30,
    "name": "Кран шаровой полипропиленовый 20 мм",
    "price": 280,
    "code": "PPR-V20",
    "category": "ppr",
    "subcategory": "ppr-valve",
    "inStock": true,
    "unit": "шт",
    "description": "Кран шаровой PPR 20 мм полнопроходной."
  },
  {
    "id": 31,
    "name": "Кран шаровой полипропиленовый 25 мм",
    "price": 390,
    "code": "PPR-V25",
    "category": "ppr",
    "subcategory": "ppr-valve",
    "inStock": true,
    "unit": "шт",
    "description": "Кран шаровой PPR 25 мм полнопроходной."
  },
  {
    "id": 32,
    "name": "Кран шаровой полипропиленовый 32 мм",
    "price": 580,
    "code": "PPR-V32",
    "category": "ppr",
    "subcategory": "ppr-valve",
    "inStock": true,
    "unit": "шт",
    "description": "Кран шаровой PPR 32 мм."
  },
  {
    "id": 33,
    "name": "Планка смесителя настенная полипропиленовая 20x1/2\" ВР",
    "price": 320,
    "code": "PPR-PL20",
    "category": "ppr",
    "subcategory": "ppr-union",
    "inStock": true,
    "unit": "шт",
    "description": "Комплект для подключения настенного смесителя со стандартным межосевым расстоянием 150 мм."
  },
  {
    "id": 34,
    "name": "Обвод полипропиленовый раструбный 20 мм",
    "price": 65,
    "code": "PPR-OB20",
    "category": "ppr",
    "subcategory": "ppr-elbow",
    "inStock": true,
    "unit": "шт",
    "description": "Обвод изогнутый PPR 20 мм для пересечения трубопроводов."
  },
  {
    "id": 35,
    "name": "Обвод полипропиленовый раструбный 25 мм",
    "price": 95,
    "code": "PPR-OB25",
    "category": "ppr",
    "subcategory": "ppr-elbow",
    "inStock": true,
    "unit": "шт",
    "description": "Обвод изогнутый PPR 25 мм."
  },
  {
    "id": 36,
    "name": "Заглушка полипропиленовая 20 мм",
    "price": 12,
    "code": "PPR-CAP20",
    "category": "ppr",
    "subcategory": "ppr-cap",
    "inStock": true,
    "unit": "шт",
    "description": "Заглушка PPR круглая 20 мм."
  },
  {
    "id": 37,
    "name": "Опора (клипса) полипропиленовая для труб 20 мм",
    "price": 8,
    "code": "PPR-CL20",
    "category": "ppr",
    "subcategory": "ppr-cap",
    "inStock": true,
    "unit": "шт",
    "description": "Клипса одинарная для фиксации трубы 20 мм к стене."
  },
  {
    "id": 38,
    "name": "Опора (клипса) полипропиленовая для труб 25 мм",
    "price": 11,
    "code": "PPR-CL25",
    "category": "ppr",
    "subcategory": "ppr-cap",
    "inStock": true,
    "unit": "шт",
    "description": "Клипса одинарная для фиксации трубы 25 мм к стене."
  },
  {
    "id": 39,
    "name": "Фекальный насос JEMIX ФН-125-5 (GS-400)",
    "price": 4495,
    "oldPrice": 4990,
    "code": "GS-400",
    "category": "Насосы",
    "brandId": "belamos",
    "inStock": true,
    "unit": "шт",
    "warranty": true,
    "image": "https://piter3tn.ru/image/cache/catalog/3tn_ru/wa-data/public/shop/products/27/11/1127/images/11014/11014.970-1000x1000.jpg",
    "description": "Насос фекальный погружной JEMIX ФН-125-5 предназначен для откачки канализационных, дренажных и грунтовых вод с волокнистыми включениями.",
    "characteristics": [
      {
        "name": "Мощность",
        "value": "400 Вт"
      },
      {
        "name": "Производительность",
        "value": "7.5 м³/ч (125 л/мин)"
      },
      {
        "name": "Максимальный напор",
        "value": "5 м"
      },
      {
        "name": "Диаметр патрубка",
        "value": "1\" / 1¼\" / 1½\""
      }
    ]
  },
  {
    "id": 40,
    "name": "Скважинный насос Belamos TF3-40 (кабель 20 м)",
    "price": 14800,
    "code": "TF3-40",
    "category": "Насосы",
    "brandId": "belamos",
    "inStock": true,
    "unit": "шт",
    "warranty": true,
    "description": "Скважинный насос диаметром 3 дюйма (78 мм). Подходит для скважин от 80 мм.",
    "characteristics": [
      {
        "name": "Макс. напор",
        "value": "42 м"
      },
      {
        "name": "Подача",
        "value": "2.7 м³/ч"
      },
      {
        "name": "Мощность",
        "value": "550 Вт"
      },
      {
        "name": "Длина кабеля",
        "value": "20 м"
      }
    ]
  },
  {
    "id": 41,
    "name": "Скважинный насос Belamos TF3-60 (кабель 35 м)",
    "price": 18200,
    "code": "TF3-60",
    "category": "Насосы",
    "brandId": "belamos",
    "inStock": true,
    "unit": "шт",
    "warranty": true,
    "description": "Глубинный насос Belamos TF3-60 для систем водоснабжения загородного дома.",
    "characteristics": [
      {
        "name": "Макс. напор",
        "value": "60 м"
      },
      {
        "name": "Подача",
        "value": "2.7 м³/ч"
      },
      {
        "name": "Мощность",
        "value": "800 Вт"
      },
      {
        "name": "Длина кабеля",
        "value": "35 м"
      }
    ]
  },
  {
    "id": 42,
    "name": "Скважинный насос Belamos TF3-80 (кабель 50 м)",
    "price": 22400,
    "code": "TF3-80",
    "category": "Насосы",
    "brandId": "belamos",
    "inStock": true,
    "unit": "шт",
    "warranty": true,
    "description": "Глубинный насос Belamos TF3-80 с кабелем 50 м для глубоких скважин.",
    "characteristics": [
      {
        "name": "Макс. напор",
        "value": "85 м"
      },
      {
        "name": "Подача",
        "value": "2.7 м³/ч"
      },
      {
        "name": "Мощность",
        "value": "1000 Вт"
      },
      {
        "name": "Длина кабеля",
        "value": "50 м"
      }
    ]
  },
  {
    "id": 43,
    "name": "Ванна стальная ВИЗ Antika 170x70 см с ножками",
    "price": 12000,
    "oldPrice": 14500,
    "code": "ANT-17070",
    "category": "Ванны, экраны и комплектующие",
    "brandId": "antika",
    "inStock": true,
    "unit": "шт",
    "warranty": true,
    "description": "Стальная эмалированная ванна Antika 170х70 см от Верх-Исетского металлургического завода (ВИЗ). Прочное стеклокерамическое покрытие, устойчивость к царапинам и бытовой химии, опорные ножки в комплекте.",
    "characteristics": [
      {
        "name": "Длина",
        "value": "170 см"
      },
      {
        "name": "Ширина",
        "value": "70 см"
      },
      {
        "name": "Глубина",
        "value": "40 см"
      },
      {
        "name": "Материал",
        "value": "Сталь эмалированная (1.8 мм)"
      },
      {
        "name": "Объем",
        "value": "180 л"
      },
      {
        "name": "Цвет",
        "value": "Белый глянцевый"
      }
    ]
  },
  {
    "id": 0,
    "name": "Душевая Кабина Лайн 90*90 В",
    "price": 41380,
    "code": "DK469",
    "brandId": "triton",
    "category": "dushevye-kabiny",
    "subcategory": "С средним поддоном",
    "inStock": false,
    "unit": "шт",
    "warranty": true,
    "description": "Душевая кабина Triton (Душевая Кабина Лайн 90*90 В). Надежное закаленное стекло, усиленный акриловый поддон с металлическим каркасом, качественные ролики и заводская гарантия производителя.",
    "image": "https://piter3tn.ru/image/cache/catalog/image/catalog/wa-data/public/shop/products/85/12/1285/images/14088/14088.970-1000x1000.jpg",
    "gallery": [
      "https://piter3tn.ru/image/cache/catalog/image/catalog/wa-data/public/shop/products/85/12/1285/images/14088/14088.970-1000x1000.jpg",
      "https://piter3tn.ru/image/cache/catalog/wa-data/public/shop/products/85/12/1285/images/14089/14089.970-1000x1000.jpg",
      "https://piter3tn.ru/image/cache/catalog/wa-data/public/shop/products/85/12/1285/images/14101/14101.970-1000x1000.jpg",
      "https://piter3tn.ru/image/cache/catalog/wa-data/public/shop/products/85/12/1285/images/14102/14102.970-1000x1000.jpg",
      "https://piter3tn.ru/image/cache/catalog/wa-data/public/shop/products/85/12/1285/images/14103/14103.970-1000x1000.jpg",
      "https://piter3tn.ru/image/cache/catalog/wa-data/public/shop/products/85/12/1285/images/14104/14104.970-1000x1000.jpg",
      "https://piter3tn.ru/image/cache/catalog/wa-data/public/shop/products/85/12/1285/images/14100/14100.970-1000x1000.jpg",
      "https://piter3tn.ru/image/cache/catalog/wa-data/public/shop/products/85/12/1285/images/14106/14106.970-1000x1000.jpg"
    ],
    "characteristics": [
      {
        "name": "Высота поддона",
        "value": "310 мм"
      },
      {
        "name": "Глубина поддона",
        "value": "200 мм"
      },
      {
        "name": "Диаметр слива",
        "value": "50 мм"
      },
      {
        "name": "Длина",
        "value": "900 мм"
      },
      {
        "name": "Материал",
        "value": "Закалённое стекло, металлический профиль, акрил"
      },
      {
        "name": "Размер",
        "value": "90х90"
      },
      {
        "name": "Тип (цвет, рисунок) переднего стекла",
        "value": "Лайн"
      },
      {
        "name": "Тип кабины",
        "value": "Закрытая кабина"
      },
      {
        "name": "Тип поддона",
        "value": "Средний"
      }
    ]
  },
  {
    "id": 0,
    "name": "Душевая Кабина Тритон Грэй-Блэк 90х90 В",
    "price": 44900,
    "code": "DK378",
    "brandId": "triton",
    "category": "dushevye-kabiny",
    "subcategory": "С средним поддоном",
    "inStock": false,
    "unit": "шт",
    "warranty": true,
    "description": "Душевая кабина Triton (Душевая Кабина Тритон Грэй-Блэк 90х90 В). Надежное закаленное стекло, усиленный акриловый поддон с металлическим каркасом, качественные ролики и заводская гарантия производителя.",
    "image": "https://piter3tn.ru/image/cache/catalog/3tn_ru/wa-data/public/shop/products/19/11/1119/images/10844/10844.970-1000x1000.jpg",
    "gallery": [
      "https://piter3tn.ru/image/cache/catalog/3tn_ru/wa-data/public/shop/products/19/11/1119/images/10844/10844.970-1000x1000.jpg",
      "https://piter3tn.ru/image/cache/catalog/3tn_ru/wa-data/public/shop/products/19/11/1119/images/10845/10845.970-1000x1000.png",
      "https://piter3tn.ru/image/cache/catalog/3tn_ru/wa-data/public/shop/products/19/11/1119/images/10847/10847.970-1000x1000.jpg",
      "https://piter3tn.ru/image/cache/catalog/3tn_ru/wa-data/public/shop/products/19/11/1119/images/10846/10846.970-1000x1000.jpg",
      "https://piter3tn.ru/image/cache/catalog/3tn_ru/wa-data/public/shop/products/19/11/1119/images/10848/10848.970-1000x1000.jpg",
      "https://piter3tn.ru/image/cache/catalog/3tn_ru/wa-data/public/shop/products/19/11/1119/images/10849/10849.970-1000x1000.jpg",
      "https://piter3tn.ru/image/cache/catalog/3tn_ru/wa-data/public/shop/products/19/11/1119/images/10850/10850.970-1000x1000.jpg",
      "https://piter3tn.ru/image/cache/catalog/3tn_ru/wa-data/public/shop/products/19/11/1119/images/10851/10851.970-1000x1000.png"
    ],
    "characteristics": [
      {
        "name": "Высота поддона",
        "value": "310 мм"
      },
      {
        "name": "Глубина поддона",
        "value": "200 мм"
      },
      {
        "name": "Диаметр слива",
        "value": "50 мм"
      },
      {
        "name": "Длина",
        "value": "900 мм"
      },
      {
        "name": "Материал",
        "value": "Закалённое стекло, металлический профиль, акрил"
      },
      {
        "name": "Размер",
        "value": "90х90"
      },
      {
        "name": "Тип (цвет, рисунок) переднего стекла",
        "value": "Тонированное"
      },
      {
        "name": "Тип кабины",
        "value": "Закрытая кабина"
      },
      {
        "name": "Тип поддона",
        "value": "Средний"
      }
    ]
  },
  {
    "id": 0,
    "name": "Душевая кабина Тритон Вельвет 80х80 А (низкий поддон)",
    "price": 34530,
    "code": "DK355",
    "brandId": "triton",
    "category": "dushevye-kabiny",
    "subcategory": "С низким поддоном",
    "inStock": false,
    "unit": "шт",
    "warranty": true,
    "description": "Душевая кабина Triton (Душевая кабина Тритон Вельвет 80х80 А (низкий поддон)). Надежное закаленное стекло, усиленный акриловый поддон с металлическим каркасом, качественные ролики и заводская гарантия производителя.",
    "image": "https://piter3tn.ru/image/cache/catalog/3tn_ru/wa-data/public/shop/products/27/11/1127/images/11014/11014.970-1000x1000.jpg",
    "gallery": [
      "https://piter3tn.ru/image/cache/catalog/3tn_ru/wa-data/public/shop/products/27/11/1127/images/11014/11014.970-1000x1000.jpg",
      "https://piter3tn.ru/image/cache/catalog/3tn_ru/wa-data/public/shop/products/27/11/1127/images/11098/11098.970-1000x1000.jpg",
      "https://piter3tn.ru/image/cache/catalog/3tn_ru/wa-data/public/shop/products/27/11/1127/images/11099/11099.970-1000x1000.jpg",
      "https://piter3tn.ru/image/cache/catalog/3tn_ru/wa-data/public/shop/products/27/11/1127/images/11100/11100.970-1000x1000.jpg",
      "https://piter3tn.ru/image/cache/catalog/3tn_ru/wa-data/public/shop/products/27/11/1127/images/11017/11017.970-1000x1000.png",
      "https://piter3tn.ru/image/cache/catalog/3tn_ru/wa-data/public/shop/products/27/11/1127/images/11019/11019.970-1000x1000.jpg",
      "https://piter3tn.ru/image/cache/catalog/3tn_ru/wa-data/public/shop/products/27/11/1127/images/11103/11103.970-1000x1000.jpg",
      "https://piter3tn.ru/image/cache/catalog/3tn_ru/wa-data/public/shop/products/27/11/1127/images/11022/11022.970-1000x1000.jpg"
    ],
    "characteristics": [
      {
        "name": "Высота поддона",
        "value": "170 мм"
      },
      {
        "name": "Глубина поддона",
        "value": "65 мм"
      },
      {
        "name": "Диаметр слива",
        "value": "90 мм"
      },
      {
        "name": "Длина",
        "value": "800 мм"
      },
      {
        "name": "Материал",
        "value": "Закалённое стекло, металлический профиль, акрил"
      },
      {
        "name": "Размер",
        "value": "80х80"
      },
      {
        "name": "Смеситель (душевой набор)",
        "value": "Triton DN4 с верхним душем"
      },
      {
        "name": "Тип (цвет, рисунок) переднего стекла",
        "value": "Матовое"
      },
      {
        "name": "Тип кабины",
        "value": "Закрытая кабина"
      }
    ]
  },
  {
    "id": 0,
    "name": "Душевая кабина Тритон Вельвет 90х90 А (низкий поддон)",
    "price": 38370,
    "code": "DK218",
    "brandId": "triton",
    "category": "dushevye-kabiny",
    "subcategory": "С низким поддоном",
    "inStock": false,
    "unit": "шт",
    "warranty": true,
    "description": "Душевая кабина Triton (Душевая кабина Тритон Вельвет 90х90 А (низкий поддон)). Надежное закаленное стекло, усиленный акриловый поддон с металлическим каркасом, качественные ролики и заводская гарантия производителя.",
    "image": "https://piter3tn.ru/image/cache/catalog/3tn_ru/wa-data/public/shop/products/85/07/785/images/9818/9818.970-1000x1000.jpg",
    "gallery": [
      "https://piter3tn.ru/image/cache/catalog/3tn_ru/wa-data/public/shop/products/85/07/785/images/9818/9818.970-1000x1000.jpg",
      "https://piter3tn.ru/image/cache/catalog/3tn_ru/wa-data/public/shop/products/85/07/785/images/9819/9819.970-1000x1000.jpg",
      "https://piter3tn.ru/image/cache/catalog/3tn_ru/wa-data/public/shop/products/85/07/785/images/9816/9816.970-1000x1000.png",
      "https://piter3tn.ru/image/cache/catalog/3tn_ru/wa-data/public/shop/products/85/07/785/images/9817/9817.970-1000x1000.png",
      "https://piter3tn.ru/image/cache/catalog/3tn_ru/wa-data/public/shop/products/85/07/785/images/9815/9815.970-1000x1000.png",
      "https://piter3tn.ru/image/cache/catalog/3tn_ru/wa-data/public/shop/products/85/07/785/images/9820/9820.970-1000x1000.jpg",
      "https://piter3tn.ru/image/cache/catalog/3tn_ru/wa-data/public/shop/products/85/07/785/images/11522/11522.970-1000x1000.jpg",
      "https://piter3tn.ru/image/cache/catalog/3tn_ru/wa-data/public/shop/products/85/07/785/images/11523/11523.970-1000x1000.jpg"
    ],
    "characteristics": [
      {
        "name": "Высота поддона",
        "value": "170 мм"
      },
      {
        "name": "Глубина поддона",
        "value": "65 мм"
      },
      {
        "name": "Диаметр слива",
        "value": "90 мм"
      },
      {
        "name": "Длина",
        "value": "900 мм"
      },
      {
        "name": "Материал",
        "value": "Закалённое стекло, металлический профиль, акрил"
      },
      {
        "name": "Размер",
        "value": "90х90"
      },
      {
        "name": "Смеситель (душевой набор)",
        "value": "Triton DN4 с верхним душем"
      },
      {
        "name": "Тип (цвет, рисунок) переднего стекла",
        "value": "Вельвет"
      },
      {
        "name": "Тип кабины",
        "value": "Закрытая кабина"
      }
    ]
  },
  {
    "id": 0,
    "name": "Душевая кабина Тритон Вельвет 90х90 В (средний поддон)",
    "price": 40590,
    "code": "DK219",
    "brandId": "triton",
    "category": "dushevye-kabiny",
    "subcategory": "С средним поддоном",
    "inStock": false,
    "unit": "шт",
    "warranty": true,
    "description": "Душевая кабина Triton (Душевая кабина Тритон Вельвет 90х90 В (средний поддон)). Надежное закаленное стекло, усиленный акриловый поддон с металлическим каркасом, качественные ролики и заводская гарантия производителя.",
    "image": "https://piter3tn.ru/image/cache/catalog/3tn_ru/wa-data/public/shop/products/88/07/788/images/9825/9825.970-1000x1000.jpg",
    "gallery": [
      "https://piter3tn.ru/image/cache/catalog/3tn_ru/wa-data/public/shop/products/88/07/788/images/9825/9825.970-1000x1000.jpg",
      "https://piter3tn.ru/image/cache/catalog/3tn_ru/wa-data/public/shop/products/88/07/788/images/9826/9826.970-1000x1000.jpg",
      "https://piter3tn.ru/image/cache/catalog/3tn_ru/wa-data/public/shop/products/88/07/788/images/9823/9823.970-1000x1000.png",
      "https://piter3tn.ru/image/cache/catalog/3tn_ru/wa-data/public/shop/products/88/07/788/images/9824/9824.970-1000x1000.png",
      "https://piter3tn.ru/image/cache/catalog/3tn_ru/wa-data/public/shop/products/88/07/788/images/9822/9822.970-1000x1000.png",
      "https://piter3tn.ru/image/cache/catalog/3tn_ru/wa-data/public/shop/products/88/07/788/images/9821/9821.970-1000x1000.jpg",
      "https://piter3tn.ru/image/cache/catalog/3tn_ru/wa-data/public/shop/products/88/07/788/images/11524/11524.970-1000x1000.jpg",
      "https://piter3tn.ru/image/cache/catalog/3tn_ru/wa-data/public/shop/products/88/07/788/images/11525/11525.970-1000x1000.jpg"
    ],
    "characteristics": [
      {
        "name": "Высота поддона",
        "value": "310 мм"
      },
      {
        "name": "Глубина поддона",
        "value": "200 мм"
      },
      {
        "name": "Диаметр слива",
        "value": "50 мм"
      },
      {
        "name": "Длина",
        "value": "900 мм"
      },
      {
        "name": "Материал",
        "value": "Закалённое стекло, металлический профиль, акрил"
      },
      {
        "name": "Размер",
        "value": "90х90"
      },
      {
        "name": "Смеситель (душевой набор)",
        "value": "Triton DN4 с верхним душем"
      },
      {
        "name": "Тип (цвет, рисунок) переднего стекла",
        "value": "Вельвет"
      },
      {
        "name": "Тип кабины",
        "value": "Закрытая кабина"
      }
    ]
  },
  {
    "id": 0,
    "name": "Душевая кабина Тритон Вельвет-К 90*90 А",
    "price": 40710,
    "code": "DK356",
    "brandId": "triton",
    "category": "dushevye-kabiny",
    "subcategory": "С низким поддоном",
    "inStock": false,
    "unit": "шт",
    "warranty": true,
    "description": "Душевая кабина Triton (Душевая кабина Тритон Вельвет-К 90*90 А). Надежное закаленное стекло, усиленный акриловый поддон с металлическим каркасом, качественные ролики и заводская гарантия производителя.",
    "image": "https://piter3tn.ru/image/cache/catalog/3tn_ru/wa-data/public/shop/products/14/11/1114/images/10535/10535.970-1000x1000.png",
    "gallery": [
      "https://piter3tn.ru/image/cache/catalog/3tn_ru/wa-data/public/shop/products/14/11/1114/images/10535/10535.970-1000x1000.png",
      "https://piter3tn.ru/image/cache/catalog/3tn_ru/wa-data/public/shop/products/14/11/1114/images/10536/10536.970-1000x1000.png",
      "https://piter3tn.ru/image/cache/catalog/3tn_ru/wa-data/public/shop/products/14/11/1114/images/10537/10537.970-1000x1000.jpg",
      "https://piter3tn.ru/image/cache/catalog/3tn_ru/wa-data/public/shop/products/14/11/1114/images/10538/10538.970-1000x1000.jpg",
      "https://piter3tn.ru/image/cache/catalog/3tn_ru/wa-data/public/shop/products/14/11/1114/images/10539/10539.970-1000x1000.jpg",
      "https://piter3tn.ru/image/cache/catalog/3tn_ru/wa-data/public/shop/products/14/11/1114/images/10540/10540.970-1000x1000.jpg",
      "https://piter3tn.ru/image/cache/catalog/3tn_ru/wa-data/public/shop/products/14/11/1114/images/10541/10541.970-1000x1000.jpg",
      "https://piter3tn.ru/image/cache/catalog/3tn_ru/wa-data/public/shop/products/14/11/1114/images/10542/10542.970-1000x1000.jpg"
    ],
    "characteristics": [
      {
        "name": "Высота поддона",
        "value": "170 мм"
      },
      {
        "name": "Глубина поддона",
        "value": "65 мм"
      },
      {
        "name": "Диаметр слива",
        "value": "90 мм"
      },
      {
        "name": "Длина",
        "value": "900 мм"
      },
      {
        "name": "Материал",
        "value": "Закалённое стекло, металлический профиль, акрил"
      },
      {
        "name": "Размер",
        "value": "90х90"
      },
      {
        "name": "Смеситель (душевой набор)",
        "value": "Triton DN4 с верхним душем"
      },
      {
        "name": "Тип (цвет, рисунок) переднего стекла",
        "value": "Матовый"
      },
      {
        "name": "Тип кабины",
        "value": "Закрытая кабина"
      }
    ]
  },
  {
    "id": 0,
    "name": "Душевая кабина Тритон Вельвет 90х90 Б (высокий поддон)",
    "price": 39840,
    "code": "DK370",
    "brandId": "triton",
    "category": "dushevye-kabiny",
    "subcategory": "С высоким поддоном",
    "inStock": false,
    "unit": "шт",
    "warranty": true,
    "description": "Душевая кабина Triton (Душевая кабина Тритон Вельвет 90х90 Б (высокий поддон)). Надежное закаленное стекло, усиленный акриловый поддон с металлическим каркасом, качественные ролики и заводская гарантия производителя.",
    "image": "https://piter3tn.ru/image/cache/catalog/3tn_ru/wa-data/public/shop/products/11/11/1111/images/10410/10410.970-1000x1000.png",
    "gallery": [
      "https://piter3tn.ru/image/cache/catalog/3tn_ru/wa-data/public/shop/products/11/11/1111/images/10410/10410.970-1000x1000.png",
      "https://piter3tn.ru/image/cache/catalog/3tn_ru/wa-data/public/shop/products/11/11/1111/images/10409/10409.970-1000x1000.png",
      "https://piter3tn.ru/image/cache/catalog/3tn_ru/wa-data/public/shop/products/11/11/1111/images/10411/10411.970-1000x1000.jpg",
      "https://piter3tn.ru/image/cache/catalog/3tn_ru/wa-data/public/shop/products/11/11/1111/images/10412/10412.970-1000x1000.jpg",
      "https://piter3tn.ru/image/cache/catalog/3tn_ru/wa-data/public/shop/products/11/11/1111/images/10413/10413.970-1000x1000.jpg",
      "https://piter3tn.ru/image/cache/catalog/3tn_ru/wa-data/public/shop/products/11/11/1111/images/10401/10401.970-1000x1000.jpg",
      "https://piter3tn.ru/image/cache/catalog/3tn_ru/wa-data/public/shop/products/11/11/1111/images/11526/11526.970-1000x1000.jpg",
      "https://piter3tn.ru/image/cache/catalog/3tn_ru/wa-data/public/shop/products/11/11/1111/images/11527/11527.970-1000x1000.jpg"
    ],
    "characteristics": [
      {
        "name": "Высота поддона",
        "value": "450 мм"
      },
      {
        "name": "Глубина поддона",
        "value": "350 мм"
      },
      {
        "name": "Диаметр слива",
        "value": "50 мм"
      },
      {
        "name": "Длина",
        "value": "900 мм"
      },
      {
        "name": "Материал",
        "value": "Закалённое стекло, металлический профиль, акрил"
      },
      {
        "name": "Размер",
        "value": "90х90"
      },
      {
        "name": "Смеситель (душевой набор)",
        "value": "Triton DN4 с верхним душем"
      },
      {
        "name": "Тип (цвет, рисунок) переднего стекла",
        "value": "Матовый"
      },
      {
        "name": "Тип кабины",
        "value": "Закрытая кабина"
      }
    ]
  },
  {
    "id": 0,
    "name": "Душевая кабина Тритон Грэй-Вайт 90*90 В",
    "price": 45050,
    "code": "DK380",
    "brandId": "triton",
    "category": "dushevye-kabiny",
    "subcategory": "С средним поддоном",
    "inStock": false,
    "unit": "шт",
    "warranty": true,
    "description": "Душевая кабина Triton (Душевая кабина Тритон Грэй-Вайт 90*90 В). Надежное закаленное стекло, усиленный акриловый поддон с металлическим каркасом, качественные ролики и заводская гарантия производителя.",
    "image": "https://piter3tn.ru/image/cache/catalog/3tn_ru/wa-data/public/shop/products/17/11/1117/images/10786/10786.970-1000x1000.jpg",
    "gallery": [
      "https://piter3tn.ru/image/cache/catalog/3tn_ru/wa-data/public/shop/products/17/11/1117/images/10786/10786.970-1000x1000.jpg",
      "https://piter3tn.ru/image/cache/catalog/3tn_ru/wa-data/public/shop/products/17/11/1117/images/10794/10794.970-1000x1000.jpg",
      "https://piter3tn.ru/image/cache/catalog/3tn_ru/wa-data/public/shop/products/17/11/1117/images/10788/10788.970-1000x1000.png",
      "https://piter3tn.ru/image/cache/catalog/3tn_ru/wa-data/public/shop/products/17/11/1117/images/10789/10789.970-1000x1000.png",
      "https://piter3tn.ru/image/cache/catalog/3tn_ru/wa-data/public/shop/products/17/11/1117/images/10791/10791.970-1000x1000.jpg",
      "https://piter3tn.ru/image/cache/catalog/3tn_ru/wa-data/public/shop/products/17/11/1117/images/10792/10792.970-1000x1000.png",
      "https://piter3tn.ru/image/cache/catalog/3tn_ru/wa-data/public/shop/products/17/11/1117/images/10793/10793.970-1000x1000.jpg",
      "https://piter3tn.ru/image/cache/catalog/3tn_ru/wa-data/public/shop/products/17/11/1117/images/10779/10779.970-1000x1000.jpg"
    ],
    "characteristics": [
      {
        "name": "Высота поддона",
        "value": "310 мм"
      },
      {
        "name": "Глубина поддона",
        "value": "200 мм"
      },
      {
        "name": "Диаметр слива",
        "value": "50 мм"
      },
      {
        "name": "Длина",
        "value": "900 мм"
      },
      {
        "name": "Материал",
        "value": "Закалённое стекло, металлический профиль, акрил"
      },
      {
        "name": "Размер",
        "value": "90х90"
      },
      {
        "name": "Тип (цвет, рисунок) переднего стекла",
        "value": "Тонированное"
      },
      {
        "name": "Тип кабины",
        "value": "Закрытая кабина"
      },
      {
        "name": "Тип поддона",
        "value": "Средний"
      }
    ]
  },
  {
    "id": 0,
    "name": "Душевая Кабина Тритон Вельвет 80*80 В",
    "price": 36340,
    "code": "DK405",
    "brandId": "triton",
    "category": "dushevye-kabiny",
    "subcategory": "С средним поддоном",
    "inStock": false,
    "unit": "шт",
    "warranty": true,
    "description": "Душевая кабина Triton (Душевая Кабина Тритон Вельвет 80*80 В). Надежное закаленное стекло, усиленный акриловый поддон с металлическим каркасом, качественные ролики и заводская гарантия производителя.",
    "image": "https://piter3tn.ru/image/cache/catalog/3tn_ru/wa-data/public/shop/products/28/11/1128/images/11028/11028.970-1000x1000.jpg",
    "gallery": [
      "https://piter3tn.ru/image/cache/catalog/3tn_ru/wa-data/public/shop/products/28/11/1128/images/11028/11028.970-1000x1000.jpg",
      "https://piter3tn.ru/image/cache/catalog/3tn_ru/wa-data/public/shop/products/28/11/1128/images/11029/11029.970-1000x1000.jpg",
      "https://piter3tn.ru/image/cache/catalog/3tn_ru/wa-data/public/shop/products/28/11/1128/images/11030/11030.970-1000x1000.png",
      "https://piter3tn.ru/image/cache/catalog/3tn_ru/wa-data/public/shop/products/28/11/1128/images/11031/11031.970-1000x1000.png",
      "https://piter3tn.ru/image/cache/catalog/3tn_ru/wa-data/public/shop/products/28/11/1128/images/11032/11032.970-1000x1000.png",
      "https://piter3tn.ru/image/cache/catalog/3tn_ru/wa-data/public/shop/products/28/11/1128/images/11033/11033.970-1000x1000.jpg",
      "https://piter3tn.ru/image/cache/catalog/3tn_ru/wa-data/public/shop/products/28/11/1128/images/11284/11284.970-1000x1000.jpg",
      "https://piter3tn.ru/image/cache/catalog/3tn_ru/wa-data/public/shop/products/28/11/1128/images/11036/11036.970-1000x1000.jpg"
    ],
    "characteristics": [
      {
        "name": "Высота поддона",
        "value": "310 мм"
      },
      {
        "name": "Глубина поддона",
        "value": "200 мм"
      },
      {
        "name": "Диаметр слива",
        "value": "50 мм"
      },
      {
        "name": "Длина",
        "value": "800 мм"
      },
      {
        "name": "Материал",
        "value": "Закалённое стекло, металлический профиль, акрил"
      },
      {
        "name": "Размер",
        "value": "80х80"
      },
      {
        "name": "Тип (цвет, рисунок) переднего стекла",
        "value": "Вельвет (матовое)"
      },
      {
        "name": "Тип кабины",
        "value": "Закрытая кабина"
      },
      {
        "name": "Тип поддона",
        "value": "Средний"
      }
    ]
  },
  {
    "id": 0,
    "name": "Душевая кабина Тритон Грэй 90*90 А",
    "price": 41960,
    "code": "DK372",
    "brandId": "triton",
    "category": "dushevye-kabiny",
    "subcategory": "С низким поддоном",
    "inStock": false,
    "unit": "шт",
    "warranty": true,
    "description": "Душевая кабина Triton (Душевая кабина Тритон Грэй 90*90 А). Надежное закаленное стекло, усиленный акриловый поддон с металлическим каркасом, качественные ролики и заводская гарантия производителя.",
    "image": "https://piter3tn.ru/image/cache/catalog/3tn_ru/wa-data/public/shop/products/33/11/1133/images/11214/11214.970-1000x1000.jpg",
    "gallery": [
      "https://piter3tn.ru/image/cache/catalog/3tn_ru/wa-data/public/shop/products/33/11/1133/images/11214/11214.970-1000x1000.jpg",
      "https://piter3tn.ru/image/cache/catalog/3tn_ru/wa-data/public/shop/products/33/11/1133/images/11215/11215.970-1000x1000.jpg",
      "https://piter3tn.ru/image/cache/catalog/3tn_ru/wa-data/public/shop/products/33/11/1133/images/11216/11216.970-1000x1000.jpg",
      "https://piter3tn.ru/image/cache/catalog/3tn_ru/wa-data/public/shop/products/33/11/1133/images/11217/11217.970-1000x1000.jpg",
      "https://piter3tn.ru/image/cache/catalog/3tn_ru/wa-data/public/shop/products/33/11/1133/images/11218/11218.970-1000x1000.jpg",
      "https://piter3tn.ru/image/cache/catalog/3tn_ru/wa-data/public/shop/products/33/11/1133/images/11220/11220.970-1000x1000.jpg",
      "https://piter3tn.ru/image/cache/catalog/3tn_ru/wa-data/public/shop/products/33/11/1133/images/11113/11113.970-1000x1000.jpg",
      "https://piter3tn.ru/image/cache/catalog/3tn_ru/wa-data/public/shop/products/33/11/1133/images/11221/11221.970-1000x1000.jpg"
    ],
    "characteristics": [
      {
        "name": "Высота поддона",
        "value": "170 мм"
      },
      {
        "name": "Глубина поддона",
        "value": "65 мм"
      },
      {
        "name": "Диаметр слива",
        "value": "90 мм"
      },
      {
        "name": "Длина",
        "value": "900 мм"
      },
      {
        "name": "Материал",
        "value": "Закалённое стекло, металлический профиль, акрил"
      },
      {
        "name": "Размер",
        "value": "90х90"
      },
      {
        "name": "Тип (цвет, рисунок) переднего стекла",
        "value": "Тонированное"
      },
      {
        "name": "Тип кабины",
        "value": "Закрытая кабина"
      },
      {
        "name": "Тип поддона",
        "value": "Низкий"
      }
    ]
  },
  {
    "id": 0,
    "name": "Душевая Кабина Тритон Грэй-Блэк 90х90 А",
    "price": 44200,
    "code": "DK377",
    "brandId": "triton",
    "category": "dushevye-kabiny",
    "subcategory": "С низким поддоном",
    "inStock": false,
    "unit": "шт",
    "warranty": true,
    "description": "Душевая кабина Triton (Душевая Кабина Тритон Грэй-Блэк 90х90 А). Надежное закаленное стекло, усиленный акриловый поддон с металлическим каркасом, качественные ролики и заводская гарантия производителя.",
    "image": "https://piter3tn.ru/image/cache/catalog/3tn_ru/wa-data/public/shop/products/18/11/1118/images/10812/10812.970-1000x1000.jpg",
    "gallery": [
      "https://piter3tn.ru/image/cache/catalog/3tn_ru/wa-data/public/shop/products/18/11/1118/images/10812/10812.970-1000x1000.jpg",
      "https://piter3tn.ru/image/cache/catalog/3tn_ru/wa-data/public/shop/products/18/11/1118/images/10813/10813.970-1000x1000.jpg",
      "https://piter3tn.ru/image/cache/catalog/3tn_ru/wa-data/public/shop/products/18/11/1118/images/10817/10817.970-1000x1000.jpg",
      "https://piter3tn.ru/image/cache/catalog/3tn_ru/wa-data/public/shop/products/18/11/1118/images/10818/10818.970-1000x1000.jpg",
      "https://piter3tn.ru/image/cache/catalog/3tn_ru/wa-data/public/shop/products/18/11/1118/images/10820/10820.970-1000x1000.jpg",
      "https://piter3tn.ru/image/cache/catalog/3tn_ru/wa-data/public/shop/products/18/11/1118/images/10819/10819.970-1000x1000.jpg",
      "https://piter3tn.ru/image/cache/catalog/3tn_ru/wa-data/public/shop/products/18/11/1118/images/10821/10821.970-1000x1000.jpg",
      "https://piter3tn.ru/image/cache/catalog/3tn_ru/wa-data/public/shop/products/18/11/1118/images/10822/10822.970-1000x1000.jpg"
    ],
    "characteristics": [
      {
        "name": "Высота поддона",
        "value": "170 мм"
      },
      {
        "name": "Глубина поддона",
        "value": "65 мм"
      },
      {
        "name": "Диаметр слива",
        "value": "90 мм"
      },
      {
        "name": "Длина",
        "value": "900 мм"
      },
      {
        "name": "Материал",
        "value": "Закалённое стекло, металлический профиль, акрил"
      },
      {
        "name": "Размер",
        "value": "90х90"
      },
      {
        "name": "Тип (цвет, рисунок) переднего стекла",
        "value": "Тонированное"
      },
      {
        "name": "Тип кабины",
        "value": "Закрытая кабина"
      },
      {
        "name": "Тип поддона",
        "value": "Низкий"
      }
    ]
  },
  {
    "id": 0,
    "name": "Душевая Кабина Тритон Грэй 90х90 В",
    "price": 44170,
    "code": "DK373",
    "brandId": "triton",
    "category": "dushevye-kabiny",
    "subcategory": "С средним поддоном",
    "inStock": false,
    "unit": "шт",
    "warranty": true,
    "description": "Душевая кабина Triton (Душевая Кабина Тритон Грэй 90х90 В). Надежное закаленное стекло, усиленный акриловый поддон с металлическим каркасом, качественные ролики и заводская гарантия производителя.",
    "image": "https://piter3tn.ru/image/cache/catalog/image/catalog/3tn-ru/wa-data/public/shop/products/34/11/1134/images/11143/11143.970-1000x1000.png",
    "gallery": [
      "https://piter3tn.ru/image/cache/catalog/image/catalog/3tn-ru/wa-data/public/shop/products/34/11/1134/images/11143/11143.970-1000x1000.png",
      "https://piter3tn.ru/image/cache/catalog/3tn_ru/wa-data/public/shop/products/34/11/1134/images/11136/11136.970-1000x1000.jpg",
      "https://piter3tn.ru/image/cache/catalog/3tn_ru/wa-data/public/shop/products/34/11/1134/images/11137/11137.970-1000x1000.jpg",
      "https://piter3tn.ru/image/cache/catalog/3tn_ru/wa-data/public/shop/products/34/11/1134/images/11138/11138.970-1000x1000.png",
      "https://piter3tn.ru/image/cache/catalog/3tn_ru/wa-data/public/shop/products/34/11/1134/images/11139/11139.970-1000x1000.jpg",
      "https://piter3tn.ru/image/cache/catalog/3tn_ru/wa-data/public/shop/products/34/11/1134/images/11141/11141.970-1000x1000.jpg",
      "https://piter3tn.ru/image/cache/catalog/3tn_ru/wa-data/public/shop/products/34/11/1134/images/11142/11142.970-1000x1000.jpg",
      "https://piter3tn.ru/image/cache/catalog/3tn_ru/wa-data/public/shop/products/34/11/1134/images/11143/11143.970-1000x1000.png"
    ],
    "characteristics": [
      {
        "name": "Высота поддона",
        "value": "310 мм"
      },
      {
        "name": "Глубина поддона",
        "value": "200 мм"
      },
      {
        "name": "Диаметр слива",
        "value": "50 мм"
      },
      {
        "name": "Длина",
        "value": "900 мм"
      },
      {
        "name": "Материал",
        "value": "Закалённое стекло, металлический профиль, акрил"
      },
      {
        "name": "Размер",
        "value": "90х90"
      },
      {
        "name": "Тип (цвет, рисунок) переднего стекла",
        "value": "Тонированное"
      },
      {
        "name": "Тип кабины",
        "value": "Закрытая кабина"
      },
      {
        "name": "Тип поддона",
        "value": "Средний"
      }
    ]
  },
  {
    "id": 0,
    "name": "Душевая кабина Тритон Коралл 120х80 (левая) А (низкий поддон)",
    "price": 44210,
    "code": "DK240",
    "brandId": "triton",
    "category": "dushevye-kabiny",
    "subcategory": "С низким поддоном",
    "inStock": false,
    "unit": "шт",
    "warranty": true,
    "description": "Душевая кабина Triton (Душевая кабина Тритон Коралл 120х80 (левая) А (низкий поддон)). Надежное закаленное стекло, усиленный акриловый поддон с металлическим каркасом, качественные ролики и заводская гарантия производителя.",
    "image": "https://piter3tn.ru/image/cache/catalog/3tn_ru/wa-data/public/shop/products/02/08/802/images/10047/10047.970-1000x1000.jpg",
    "gallery": [
      "https://piter3tn.ru/image/cache/catalog/3tn_ru/wa-data/public/shop/products/02/08/802/images/10047/10047.970-1000x1000.jpg",
      "https://piter3tn.ru/image/cache/catalog/3tn_ru/wa-data/public/shop/products/02/08/802/images/10046/10046.970-1000x1000.jpg",
      "https://piter3tn.ru/image/cache/catalog/3tn_ru/wa-data/public/shop/products/02/08/802/images/10027/10027.970-1000x1000.jpg",
      "https://piter3tn.ru/image/cache/catalog/3tn_ru/wa-data/public/shop/products/02/08/802/images/10028/10028.970-1000x1000.jpg",
      "https://piter3tn.ru/image/cache/catalog/3tn_ru/wa-data/public/shop/products/02/08/802/images/10029/10029.970-1000x1000.jpg",
      "https://piter3tn.ru/image/cache/catalog/3tn_ru/wa-data/public/shop/products/02/08/802/images/10030/10030.970-1000x1000.jpg",
      "https://piter3tn.ru/image/cache/catalog/3tn_ru/wa-data/public/shop/products/02/08/802/images/9915/9915.970-1000x1000.jpg",
      "https://piter3tn.ru/image/cache/catalog/3tn_ru/wa-data/public/shop/products/02/08/802/images/10055/10055.970-1000x1000.jpg"
    ],
    "characteristics": [
      {
        "name": "Высота поддона",
        "value": "170 мм"
      },
      {
        "name": "Глубина поддона",
        "value": "65 мм"
      },
      {
        "name": "Диаметр слива",
        "value": "90 мм"
      },
      {
        "name": "Длина",
        "value": "800 мм"
      },
      {
        "name": "Материал",
        "value": "Закалённое стекло, металлический профиль, акрил"
      },
      {
        "name": "Размер",
        "value": "120х80"
      },
      {
        "name": "Смеситель (душевой набор)",
        "value": "Triton DN4 с верхним душем"
      },
      {
        "name": "Тип (цвет, рисунок) переднего стекла",
        "value": "Мозаика"
      },
      {
        "name": "Тип кабины",
        "value": "Закрытая кабина"
      }
    ]
  },
  {
    "id": 0,
    "name": "Душевая кабина Тритон Коралл-Лайт 120*80 А лев. (6 мест+сифон D90)",
    "price": 44210,
    "code": "DK383",
    "brandId": "triton",
    "category": "dushevye-kabiny",
    "subcategory": "С низким поддоном",
    "inStock": false,
    "unit": "шт",
    "warranty": true,
    "description": "Душевая кабина Triton (Душевая кабина Тритон Коралл-Лайт 120*80 А лев. (6 мест+сифон D90)). Надежное закаленное стекло, усиленный акриловый поддон с металлическим каркасом, качественные ролики и заводская гарантия производителя.",
    "image": "https://piter3tn.ru/image/cache/catalog/3tn_ru/wa-data/public/shop/products/85/11/1185/images/12081/12081.970-1000x1000.jpg",
    "gallery": [
      "https://piter3tn.ru/image/cache/catalog/3tn_ru/wa-data/public/shop/products/85/11/1185/images/12081/12081.970-1000x1000.jpg",
      "https://piter3tn.ru/image/cache/catalog/3tn_ru/wa-data/public/shop/products/85/11/1185/images/12082/12082.970-1000x1000.jpg",
      "https://piter3tn.ru/image/cache/catalog/3tn_ru/wa-data/public/shop/products/85/11/1185/images/12080/12080.970-1000x1000.jpg",
      "https://piter3tn.ru/image/cache/catalog/3tn_ru/wa-data/public/shop/products/85/11/1185/images/12083/12083.970-1000x1000.jpg",
      "https://piter3tn.ru/image/cache/catalog/3tn_ru/wa-data/public/shop/products/85/11/1185/images/12079/12079.970-1000x1000.jpg",
      "https://piter3tn.ru/image/cache/catalog/3tn_ru/wa-data/public/shop/products/85/11/1185/images/12078/12078.970-1000x1000.jpg",
      "https://piter3tn.ru/image/cache/catalog/3tn_ru/wa-data/public/shop/products/85/11/1185/images/12077/12077.970-1000x1000.jpg",
      "https://piter3tn.ru/image/cache/catalog/3tn_ru/wa-data/public/shop/products/85/11/1185/images/12045/12045.970-1000x1000.jpg"
    ],
    "characteristics": [
      {
        "name": "Высота поддона",
        "value": "170 мм"
      },
      {
        "name": "Глубина поддона",
        "value": "65 мм"
      },
      {
        "name": "Диаметр слива",
        "value": "90 мм"
      },
      {
        "name": "Длина",
        "value": "1200 мм"
      },
      {
        "name": "Материал",
        "value": "Закалённое стекло, металлический профиль, акрил"
      },
      {
        "name": "Размер",
        "value": "120х80"
      },
      {
        "name": "Тип (цвет, рисунок) переднего стекла",
        "value": "Лайт 120*80 А"
      },
      {
        "name": "Тип кабины",
        "value": "Закрытая кабина"
      },
      {
        "name": "Тип поддона",
        "value": "Низкий"
      }
    ]
  },
  {
    "id": 0,
    "name": "Душевая кабина Тритон Коралл 120х80 (правая) А (низкий поддон)",
    "price": 44210,
    "code": "DK241",
    "brandId": "triton",
    "category": "dushevye-kabiny",
    "subcategory": "С низким поддоном",
    "inStock": false,
    "unit": "шт",
    "warranty": true,
    "description": "Душевая кабина Triton (Душевая кабина Тритон Коралл 120х80 (правая) А (низкий поддон)). Надежное закаленное стекло, усиленный акриловый поддон с металлическим каркасом, качественные ролики и заводская гарантия производителя.",
    "image": "https://piter3tn.ru/image/cache/catalog/3tn_ru/wa-data/public/shop/products/03/08/803/images/10043/10043.970-1000x1000.jpg",
    "gallery": [
      "https://piter3tn.ru/image/cache/catalog/3tn_ru/wa-data/public/shop/products/03/08/803/images/10043/10043.970-1000x1000.jpg",
      "https://piter3tn.ru/image/cache/catalog/3tn_ru/wa-data/public/shop/products/03/08/803/images/10044/10044.970-1000x1000.jpg",
      "https://piter3tn.ru/image/cache/catalog/3tn_ru/wa-data/public/shop/products/03/08/803/images/10040/10040.970-1000x1000.jpg",
      "https://piter3tn.ru/image/cache/catalog/3tn_ru/wa-data/public/shop/products/03/08/803/images/10039/10039.970-1000x1000.jpg",
      "https://piter3tn.ru/image/cache/catalog/3tn_ru/wa-data/public/shop/products/03/08/803/images/10041/10041.970-1000x1000.jpg",
      "https://piter3tn.ru/image/cache/catalog/3tn_ru/wa-data/public/shop/products/03/08/803/images/10042/10042.970-1000x1000.jpg",
      "https://piter3tn.ru/image/cache/catalog/3tn_ru/wa-data/public/shop/products/03/08/803/images/9914/9914.970-1000x1000.jpg",
      "https://piter3tn.ru/image/cache/catalog/3tn_ru/wa-data/public/shop/products/03/08/803/images/10057/10057.970-1000x1000.jpg"
    ],
    "characteristics": [
      {
        "name": "Высота поддона",
        "value": "170 мм"
      },
      {
        "name": "Глубина поддона",
        "value": "65 мм"
      },
      {
        "name": "Диаметр слива",
        "value": "90 мм"
      },
      {
        "name": "Длина",
        "value": "800 мм"
      },
      {
        "name": "Материал",
        "value": "Закалённое стекло, металлический профиль, акрил"
      },
      {
        "name": "Размер",
        "value": "120х80"
      },
      {
        "name": "Смеситель (душевой набор)",
        "value": "Triton DN4 с верхним душем"
      },
      {
        "name": "Тип (цвет, рисунок) переднего стекла",
        "value": "Мозаика"
      },
      {
        "name": "Тип кабины",
        "value": "Закрытая кабина"
      }
    ]
  },
  {
    "id": 0,
    "name": "Душевая кабина Тритон Коралл 120х80 (левая) В (средний поддон с сиденьем)",
    "price": 46350,
    "code": "DK235",
    "brandId": "triton",
    "category": "dushevye-kabiny",
    "subcategory": "С низким поддоном",
    "inStock": false,
    "unit": "шт",
    "warranty": true,
    "description": "Душевая кабина Triton (Душевая кабина Тритон Коралл 120х80 (левая) В (средний поддон с сиденьем)). Надежное закаленное стекло, усиленный акриловый поддон с металлическим каркасом, качественные ролики и заводская гарантия производителя.",
    "image": "https://piter3tn.ru/image/cache/catalog/3tn_ru/wa-data/public/shop/products/08/08/808/images/10037/10037.970-1000x1000.jpg",
    "gallery": [
      "https://piter3tn.ru/image/cache/catalog/3tn_ru/wa-data/public/shop/products/08/08/808/images/10037/10037.970-1000x1000.jpg",
      "https://piter3tn.ru/image/cache/catalog/3tn_ru/wa-data/public/shop/products/08/08/808/images/10032/10032.970-1000x1000.jpg",
      "https://piter3tn.ru/image/cache/catalog/3tn_ru/wa-data/public/shop/products/08/08/808/images/10033/10033.970-1000x1000.jpg",
      "https://piter3tn.ru/image/cache/catalog/3tn_ru/wa-data/public/shop/products/08/08/808/images/10034/10034.970-1000x1000.jpg",
      "https://piter3tn.ru/image/cache/catalog/3tn_ru/wa-data/public/shop/products/08/08/808/images/10035/10035.970-1000x1000.jpg",
      "https://piter3tn.ru/image/cache/catalog/3tn_ru/wa-data/public/shop/products/08/08/808/images/10036/10036.970-1000x1000.jpg",
      "https://piter3tn.ru/image/cache/catalog/3tn_ru/wa-data/public/shop/products/08/08/808/images/6398/6398.970-1000x1000.png",
      "https://piter3tn.ru/image/cache/catalog/3tn_ru/wa-data/public/shop/products/08/08/808/images/9912/9912.970-1000x1000.jpg"
    ],
    "characteristics": [
      {
        "name": "Высота поддона",
        "value": "310 мм"
      },
      {
        "name": "Глубина поддона",
        "value": "200 мм"
      },
      {
        "name": "Диаметр слива",
        "value": "50 мм"
      },
      {
        "name": "Длина",
        "value": "800 мм"
      },
      {
        "name": "Материал",
        "value": "Закалённое стекло, металлический профиль, акрил"
      },
      {
        "name": "Размер",
        "value": "120х80"
      },
      {
        "name": "Смеситель (душевой набор)",
        "value": "Triton DN4 с верхним душем"
      },
      {
        "name": "Тип (цвет, рисунок) переднего стекла",
        "value": "Мозаика"
      },
      {
        "name": "Тип кабины",
        "value": "Закрытая кабина"
      }
    ]
  },
  {
    "id": 0,
    "name": "Душевая Кабина Тритон Грэй-Вайт 90х90 А",
    "price": 44360,
    "code": "DK379",
    "brandId": "triton",
    "category": "dushevye-kabiny",
    "subcategory": "С низким поддоном",
    "inStock": false,
    "unit": "шт",
    "warranty": true,
    "description": "Душевая кабина Triton (Душевая Кабина Тритон Грэй-Вайт 90х90 А). Надежное закаленное стекло, усиленный акриловый поддон с металлическим каркасом, качественные ролики и заводская гарантия производителя.",
    "image": "https://piter3tn.ru/image/cache/catalog/3tn_ru/wa-data/public/shop/products/16/11/1116/images/10755/10755.970-1000x1000.jpg",
    "gallery": [
      "https://piter3tn.ru/image/cache/catalog/3tn_ru/wa-data/public/shop/products/16/11/1116/images/10755/10755.970-1000x1000.jpg",
      "https://piter3tn.ru/image/cache/catalog/3tn_ru/wa-data/public/shop/products/16/11/1116/images/10756/10756.970-1000x1000.jpg",
      "https://piter3tn.ru/image/cache/catalog/3tn_ru/wa-data/public/shop/products/16/11/1116/images/10757/10757.970-1000x1000.jpg",
      "https://piter3tn.ru/image/cache/catalog/3tn_ru/wa-data/public/shop/products/16/11/1116/images/10758/10758.970-1000x1000.jpg",
      "https://piter3tn.ru/image/cache/catalog/3tn_ru/wa-data/public/shop/products/16/11/1116/images/10759/10759.970-1000x1000.jpg",
      "https://piter3tn.ru/image/cache/catalog/3tn_ru/wa-data/public/shop/products/16/11/1116/images/10760/10760.970-1000x1000.jpg",
      "https://piter3tn.ru/image/cache/catalog/3tn_ru/wa-data/public/shop/products/16/11/1116/images/10761/10761.970-1000x1000.jpg",
      "https://piter3tn.ru/image/cache/catalog/3tn_ru/wa-data/public/shop/products/16/11/1116/images/10762/10762.970-1000x1000.jpg"
    ],
    "characteristics": [
      {
        "name": "Высота поддона",
        "value": "170 мм"
      },
      {
        "name": "Глубина поддона",
        "value": "65 мм"
      },
      {
        "name": "Диаметр слива",
        "value": "90 мм"
      },
      {
        "name": "Длина",
        "value": "900 мм"
      },
      {
        "name": "Материал",
        "value": "Закалённое стекло, металлический профиль, акрил"
      },
      {
        "name": "Размер",
        "value": "90х90"
      },
      {
        "name": "Тип (цвет, рисунок) переднего стекла",
        "value": "Тонированное"
      },
      {
        "name": "Тип кабины",
        "value": "Закрытая кабина"
      },
      {
        "name": "Тип поддона",
        "value": "Низкий"
      }
    ]
  },
  {
    "id": 0,
    "name": "Душевая кабина Тритон Коралл-Лайт 120*80 А прав. (6 мест+сифон D90)",
    "price": 44210,
    "code": "DK384",
    "brandId": "triton",
    "category": "dushevye-kabiny",
    "subcategory": "С низким поддоном",
    "inStock": false,
    "unit": "шт",
    "warranty": true,
    "description": "Душевая кабина Triton (Душевая кабина Тритон Коралл-Лайт 120*80 А прав. (6 мест+сифон D90)). Надежное закаленное стекло, усиленный акриловый поддон с металлическим каркасом, качественные ролики и заводская гарантия производителя.",
    "image": "https://piter3tn.ru/image/cache/catalog/3tn_ru/wa-data/public/shop/products/84/11/1184/images/12071/12071.970-1000x1000.jpg",
    "gallery": [
      "https://piter3tn.ru/image/cache/catalog/3tn_ru/wa-data/public/shop/products/84/11/1184/images/12071/12071.970-1000x1000.jpg",
      "https://piter3tn.ru/image/cache/catalog/3tn_ru/wa-data/public/shop/products/84/11/1184/images/12070/12070.970-1000x1000.jpg",
      "https://piter3tn.ru/image/cache/catalog/3tn_ru/wa-data/public/shop/products/84/11/1184/images/12075/12075.970-1000x1000.jpg",
      "https://piter3tn.ru/image/cache/catalog/3tn_ru/wa-data/public/shop/products/84/11/1184/images/12072/12072.970-1000x1000.jpg",
      "https://piter3tn.ru/image/cache/catalog/3tn_ru/wa-data/public/shop/products/84/11/1184/images/12076/12076.970-1000x1000.jpg",
      "https://piter3tn.ru/image/cache/catalog/3tn_ru/wa-data/public/shop/products/84/11/1184/images/12073/12073.970-1000x1000.jpg",
      "https://piter3tn.ru/image/cache/catalog/3tn_ru/wa-data/public/shop/products/84/11/1184/images/12074/12074.970-1000x1000.jpg",
      "https://piter3tn.ru/image/cache/catalog/3tn_ru/wa-data/public/shop/products/84/11/1184/images/12069/12069.970-1000x1000.jpg"
    ],
    "characteristics": [
      {
        "name": "Высота поддона",
        "value": "170 мм"
      },
      {
        "name": "Глубина поддона",
        "value": "65 мм"
      },
      {
        "name": "Диаметр слива",
        "value": "90 мм"
      },
      {
        "name": "Длина",
        "value": "1200 мм"
      },
      {
        "name": "Материал",
        "value": "Закалённое стекло, металлический профиль, акрил"
      },
      {
        "name": "Размер",
        "value": "120х80"
      },
      {
        "name": "Тип (цвет, рисунок) переднего стекла",
        "value": "Лайт 120*80 А"
      },
      {
        "name": "Тип кабины",
        "value": "Закрытая кабина"
      },
      {
        "name": "Тип поддона",
        "value": "Низкий"
      }
    ]
  },
  {
    "id": 0,
    "name": "Душевая кабина Тритон Лайт 100х100 А (низкий поддон)",
    "price": 44380,
    "code": "DK206",
    "brandId": "triton",
    "category": "dushevye-kabiny",
    "subcategory": "С низким поддоном",
    "inStock": false,
    "unit": "шт",
    "warranty": true,
    "description": "Душевая кабина Triton (Душевая кабина Тритон Лайт 100х100 А (низкий поддон)). Надежное закаленное стекло, усиленный акриловый поддон с металлическим каркасом, качественные ролики и заводская гарантия производителя.",
    "image": "https://piter3tn.ru/image/cache/catalog/3tn_ru/wa-data/public/shop/products/66/07/766/images/11468/11468.970-1000x1000.jpg",
    "gallery": [
      "https://piter3tn.ru/image/cache/catalog/3tn_ru/wa-data/public/shop/products/66/07/766/images/11468/11468.970-1000x1000.jpg",
      "https://piter3tn.ru/image/cache/catalog/3tn_ru/wa-data/public/shop/products/66/07/766/images/11467/11467.970-1000x1000.jpg",
      "https://piter3tn.ru/image/cache/catalog/3tn_ru/wa-data/public/shop/products/66/07/766/images/11469/11469.970-1000x1000.png",
      "https://piter3tn.ru/image/cache/catalog/3tn_ru/wa-data/public/shop/products/66/07/766/images/11470/11470.970-1000x1000.jpg",
      "https://piter3tn.ru/image/cache/catalog/3tn_ru/wa-data/public/shop/products/66/07/766/images/11471/11471.970-1000x1000.jpg",
      "https://piter3tn.ru/image/cache/catalog/3tn_ru/wa-data/public/shop/products/66/07/766/images/11472/11472.970-1000x1000.jpg",
      "https://piter3tn.ru/image/cache/catalog/3tn_ru/wa-data/public/shop/products/66/07/766/images/11473/11473.970-1000x1000.jpg",
      "https://piter3tn.ru/image/cache/catalog/3tn_ru/wa-data/public/shop/products/66/07/766/images/11474/11474.970-1000x1000.jpg"
    ],
    "characteristics": [
      {
        "name": "Высота поддона",
        "value": "170 мм"
      },
      {
        "name": "Глубина поддона",
        "value": "65 мм"
      },
      {
        "name": "Диаметр слива",
        "value": "90 мм"
      },
      {
        "name": "Длина",
        "value": "1000 мм"
      },
      {
        "name": "Материал",
        "value": "Закалённое стекло, металлический профиль, акрил"
      },
      {
        "name": "Размер",
        "value": "100х100"
      },
      {
        "name": "Смеситель (душевой набор)",
        "value": "Triton DN4 с верхним душем"
      },
      {
        "name": "Тип (цвет, рисунок) переднего стекла",
        "value": "Лайт"
      },
      {
        "name": "Тип кабины",
        "value": "Закрытая кабина"
      }
    ]
  },
  {
    "id": 0,
    "name": "Душевая кабина Тритон Коралл-Лайт 120*80 В прав. (6 мест+сифон D50)",
    "price": 46350,
    "code": "DK386",
    "brandId": "triton",
    "category": "dushevye-kabiny",
    "subcategory": "С низким поддоном",
    "inStock": false,
    "unit": "шт",
    "warranty": true,
    "description": "Душевая кабина Triton (Душевая кабина Тритон Коралл-Лайт 120*80 В прав. (6 мест+сифон D50)). Надежное закаленное стекло, усиленный акриловый поддон с металлическим каркасом, качественные ролики и заводская гарантия производителя.",
    "image": "https://piter3tn.ru/image/cache/catalog/3tn_ru/wa-data/public/shop/products/83/11/1183/images/12062/12062.970-1000x1000.jpg",
    "gallery": [
      "https://piter3tn.ru/image/cache/catalog/3tn_ru/wa-data/public/shop/products/83/11/1183/images/12062/12062.970-1000x1000.jpg",
      "https://piter3tn.ru/image/cache/catalog/3tn_ru/wa-data/public/shop/products/83/11/1183/images/12061/12061.970-1000x1000.jpg",
      "https://piter3tn.ru/image/cache/catalog/3tn_ru/wa-data/public/shop/products/83/11/1183/images/12066/12066.970-1000x1000.jpg",
      "https://piter3tn.ru/image/cache/catalog/3tn_ru/wa-data/public/shop/products/83/11/1183/images/12063/12063.970-1000x1000.jpg",
      "https://piter3tn.ru/image/cache/catalog/3tn_ru/wa-data/public/shop/products/83/11/1183/images/12067/12067.970-1000x1000.jpg",
      "https://piter3tn.ru/image/cache/catalog/3tn_ru/wa-data/public/shop/products/83/11/1183/images/12064/12064.970-1000x1000.jpg",
      "https://piter3tn.ru/image/cache/catalog/3tn_ru/wa-data/public/shop/products/83/11/1183/images/12065/12065.970-1000x1000.jpg",
      "https://piter3tn.ru/image/cache/catalog/3tn_ru/wa-data/public/shop/products/83/11/1183/images/12068/12068.970-1000x1000.jpg"
    ],
    "characteristics": [
      {
        "name": "Высота поддона",
        "value": "310 мм"
      },
      {
        "name": "Глубина поддона",
        "value": "200 мм"
      },
      {
        "name": "Диаметр слива",
        "value": "50 мм"
      },
      {
        "name": "Длина",
        "value": "1200 мм"
      },
      {
        "name": "Материал",
        "value": "Закалённое стекло, металлический профиль, акрил"
      },
      {
        "name": "Размер",
        "value": "120х80"
      },
      {
        "name": "Тип (цвет, рисунок) переднего стекла",
        "value": "Лайт 120*80 В"
      },
      {
        "name": "Тип кабины",
        "value": "Закрытая кабина"
      },
      {
        "name": "Тип поддона",
        "value": "Средний"
      }
    ]
  },
  {
    "id": 0,
    "name": "Душевая кабина Тритон Коралл-Лайт 120*80 В лев. (6 мест+сифон D50)",
    "price": 46350,
    "code": "DK385",
    "brandId": "triton",
    "category": "dushevye-kabiny",
    "subcategory": "С низким поддоном",
    "inStock": false,
    "unit": "шт",
    "warranty": true,
    "description": "Душевая кабина Triton (Душевая кабина Тритон Коралл-Лайт 120*80 В лев. (6 мест+сифон D50)). Надежное закаленное стекло, усиленный акриловый поддон с металлическим каркасом, качественные ролики и заводская гарантия производителя.",
    "image": "https://piter3tn.ru/image/cache/catalog/3tn_ru/wa-data/public/shop/products/82/11/1182/images/12058/12058.970-1000x1000.jpg",
    "gallery": [
      "https://piter3tn.ru/image/cache/catalog/3tn_ru/wa-data/public/shop/products/82/11/1182/images/12058/12058.970-1000x1000.jpg",
      "https://piter3tn.ru/image/cache/catalog/3tn_ru/wa-data/public/shop/products/82/11/1182/images/12059/12059.970-1000x1000.jpg",
      "https://piter3tn.ru/image/cache/catalog/3tn_ru/wa-data/public/shop/products/82/11/1182/images/12056/12056.970-1000x1000.jpg",
      "https://piter3tn.ru/image/cache/catalog/3tn_ru/wa-data/public/shop/products/82/11/1182/images/12053/12053.970-1000x1000.jpg",
      "https://piter3tn.ru/image/cache/catalog/3tn_ru/wa-data/public/shop/products/82/11/1182/images/12054/12054.970-1000x1000.jpg",
      "https://piter3tn.ru/image/cache/catalog/3tn_ru/wa-data/public/shop/products/82/11/1182/images/12057/12057.970-1000x1000.jpg",
      "https://piter3tn.ru/image/cache/catalog/3tn_ru/wa-data/public/shop/products/82/11/1182/images/12055/12055.970-1000x1000.jpg",
      "https://piter3tn.ru/image/cache/catalog/3tn_ru/wa-data/public/shop/products/82/11/1182/images/11997/11997.970-1000x1000.png"
    ],
    "characteristics": [
      {
        "name": "Высота поддона",
        "value": "310 мм"
      },
      {
        "name": "Глубина поддона",
        "value": "200 мм"
      },
      {
        "name": "Диаметр слива",
        "value": "50 мм"
      },
      {
        "name": "Длина",
        "value": "1200 мм"
      },
      {
        "name": "Материал",
        "value": "Закалённое стекло, металлический профиль, акрил"
      },
      {
        "name": "Размер",
        "value": "120х80"
      },
      {
        "name": "Тип (цвет, рисунок) переднего стекла",
        "value": "Лайт 120*80 В"
      },
      {
        "name": "Тип кабины",
        "value": "Закрытая кабина"
      },
      {
        "name": "Тип поддона",
        "value": "Средний"
      }
    ]
  },
  {
    "id": 0,
    "name": "Душевая кабина Тритон Лайт 90*90 А (для ДН1 без крыши) (6 мест+сифон D90)",
    "price": 32910,
    "code": "DK396",
    "brandId": "triton",
    "category": "dushevye-kabiny",
    "subcategory": "С низким поддоном",
    "inStock": false,
    "unit": "шт",
    "warranty": true,
    "description": "Душевая кабина Triton (Душевая кабина Тритон Лайт 90*90 А (для ДН1 без крыши) (6 мест+сифон D90)). Надежное закаленное стекло, усиленный акриловый поддон с металлическим каркасом, качественные ролики и заводская гарантия производителя.",
    "image": "https://piter3tn.ru/image/cache/catalog/3tn_ru/wa-data/public/shop/products/55/11/1155/images/11578/11578.970-1000x1000.jpg",
    "gallery": [
      "https://piter3tn.ru/image/cache/catalog/3tn_ru/wa-data/public/shop/products/55/11/1155/images/11578/11578.970-1000x1000.jpg",
      "https://piter3tn.ru/image/cache/catalog/3tn_ru/wa-data/public/shop/products/55/11/1155/images/11577/11577.970-1000x1000.jpg",
      "https://piter3tn.ru/image/cache/catalog/3tn_ru/wa-data/public/shop/products/55/11/1155/images/11579/11579.970-1000x1000.jpg",
      "https://piter3tn.ru/image/cache/catalog/3tn_ru/wa-data/public/shop/products/55/11/1155/images/11580/11580.970-1000x1000.jpg",
      "https://piter3tn.ru/image/cache/catalog/3tn_ru/wa-data/public/shop/products/55/11/1155/images/11568/11568.970-1000x1000.jpg",
      "https://piter3tn.ru/image/cache/catalog/3tn_ru/wa-data/public/shop/products/55/11/1155/images/11583/11583.970-1000x1000.png",
      "https://piter3tn.ru/image/cache/catalog/3tn_ru/wa-data/public/shop/products/55/11/1155/images/11582/11582.970-1000x1000.png",
      "https://piter3tn.ru/image/cache/catalog/3tn_ru/wa-data/public/shop/products/55/11/1155/images/11585/11585.970-1000x1000.jpg"
    ],
    "characteristics": [
      {
        "name": "Высота поддона",
        "value": "170 мм"
      },
      {
        "name": "Глубина поддона",
        "value": "65 мм"
      },
      {
        "name": "Диаметр слива",
        "value": "90 мм"
      },
      {
        "name": "Длина",
        "value": "900 мм"
      },
      {
        "name": "Материал",
        "value": "Закалённое стекло, металлический профиль, акрил"
      },
      {
        "name": "Размер",
        "value": "90х90"
      },
      {
        "name": "Тип (цвет, рисунок) переднего стекла",
        "value": "Лайт"
      },
      {
        "name": "Тип кабины",
        "value": "Кабина без крыши"
      },
      {
        "name": "Тип поддона",
        "value": "Низкий"
      }
    ]
  },
  {
    "id": 0,
    "name": "Душевая кабина Тритон Лайт 90х90 А (низкий поддон)",
    "price": 38470,
    "code": "DK208",
    "brandId": "triton",
    "category": "dushevye-kabiny",
    "subcategory": "С низким поддоном",
    "inStock": false,
    "unit": "шт",
    "warranty": true,
    "description": "Душевая кабина Triton (Душевая кабина Тритон Лайт 90х90 А (низкий поддон)). Надежное закаленное стекло, усиленный акриловый поддон с металлическим каркасом, качественные ролики и заводская гарантия производителя.",
    "image": "https://piter3tn.ru/image/cache/catalog/3tn_ru/wa-data/public/shop/products/68/07/768/images/11453/11453.970-1000x1000.jpg",
    "gallery": [
      "https://piter3tn.ru/image/cache/catalog/3tn_ru/wa-data/public/shop/products/68/07/768/images/11453/11453.970-1000x1000.jpg",
      "https://piter3tn.ru/image/cache/catalog/3tn_ru/wa-data/public/shop/products/68/07/768/images/11452/11452.970-1000x1000.jpg",
      "https://piter3tn.ru/image/cache/catalog/3tn_ru/wa-data/public/shop/products/68/07/768/images/11454/11454.970-1000x1000.png",
      "https://piter3tn.ru/image/cache/catalog/3tn_ru/wa-data/public/shop/products/68/07/768/images/11455/11455.970-1000x1000.jpg",
      "https://piter3tn.ru/image/cache/catalog/3tn_ru/wa-data/public/shop/products/68/07/768/images/11456/11456.970-1000x1000.jpg",
      "https://piter3tn.ru/image/cache/catalog/3tn_ru/wa-data/public/shop/products/68/07/768/images/11457/11457.970-1000x1000.jpg",
      "https://piter3tn.ru/image/cache/catalog/3tn_ru/wa-data/public/shop/products/68/07/768/images/11458/11458.970-1000x1000.jpg",
      "https://piter3tn.ru/image/cache/catalog/3tn_ru/wa-data/public/shop/products/68/07/768/images/11459/11459.970-1000x1000.jpg"
    ],
    "characteristics": [
      {
        "name": "Высота поддона",
        "value": "170 мм"
      },
      {
        "name": "Глубина поддона",
        "value": "65 мм"
      },
      {
        "name": "Диаметр слива",
        "value": "90 мм"
      },
      {
        "name": "Длина",
        "value": "900 мм"
      },
      {
        "name": "Материал",
        "value": "Закалённое стекло, металлический профиль, акрил"
      },
      {
        "name": "Размер",
        "value": "90х90"
      },
      {
        "name": "Смеситель (душевой набор)",
        "value": "Triton DN4 с верхним душем"
      },
      {
        "name": "Тип (цвет, рисунок) переднего стекла",
        "value": "Лайт"
      },
      {
        "name": "Тип кабины",
        "value": "Закрытая кабина"
      }
    ]
  },
  {
    "id": 0,
    "name": "Душевая кабина Тритон Лайт 90х90 Б (высокий поддон)",
    "price": 39410,
    "code": "DK209",
    "brandId": "triton",
    "category": "dushevye-kabiny",
    "subcategory": "С высоким поддоном",
    "inStock": false,
    "unit": "шт",
    "warranty": true,
    "description": "Душевая кабина Triton (Душевая кабина Тритон Лайт 90х90 Б (высокий поддон)). Надежное закаленное стекло, усиленный акриловый поддон с металлическим каркасом, качественные ролики и заводская гарантия производителя.",
    "image": "https://piter3tn.ru/image/cache/catalog/3tn_ru/wa-data/public/shop/products/69/07/769/images/11461/11461.970-1000x1000.jpg",
    "gallery": [
      "https://piter3tn.ru/image/cache/catalog/3tn_ru/wa-data/public/shop/products/69/07/769/images/11461/11461.970-1000x1000.jpg",
      "https://piter3tn.ru/image/cache/catalog/3tn_ru/wa-data/public/shop/products/69/07/769/images/11460/11460.970-1000x1000.jpg",
      "https://piter3tn.ru/image/cache/catalog/3tn_ru/wa-data/public/shop/products/69/07/769/images/11462/11462.970-1000x1000.jpg",
      "https://piter3tn.ru/image/cache/catalog/3tn_ru/wa-data/public/shop/products/69/07/769/images/11463/11463.970-1000x1000.jpg",
      "https://piter3tn.ru/image/cache/catalog/3tn_ru/wa-data/public/shop/products/69/07/769/images/11464/11464.970-1000x1000.jpg",
      "https://piter3tn.ru/image/cache/catalog/3tn_ru/wa-data/public/shop/products/69/07/769/images/11465/11465.970-1000x1000.jpg",
      "https://piter3tn.ru/image/cache/catalog/3tn_ru/wa-data/public/shop/products/69/07/769/images/11466/11466.970-1000x1000.jpg",
      "https://piter3tn.ru/image/cache/catalog/3tn_ru/wa-data/public/shop/products/69/07/769/images/11534/11534.970-1000x1000.jpg"
    ],
    "characteristics": [
      {
        "name": "Высота поддона",
        "value": "450 мм"
      },
      {
        "name": "Глубина поддона",
        "value": "350 мм"
      },
      {
        "name": "Диаметр слива",
        "value": "50 мм"
      },
      {
        "name": "Длина",
        "value": "900 мм"
      },
      {
        "name": "Материал",
        "value": "Закалённое стекло, металлический профиль, акрил"
      },
      {
        "name": "Размер",
        "value": "90х90"
      },
      {
        "name": "Смеситель (душевой набор)",
        "value": "Triton DN4 с верхним душем"
      },
      {
        "name": "Тип (цвет, рисунок) переднего стекла",
        "value": "Лайт"
      },
      {
        "name": "Тип кабины",
        "value": "Закрытая кабина"
      }
    ]
  },
  {
    "id": 0,
    "name": "Душевая кабина Тритон Лайт 90х90 В (средний поддон)",
    "price": 40680,
    "code": "DK210",
    "brandId": "triton",
    "category": "dushevye-kabiny",
    "subcategory": "С средним поддоном",
    "inStock": false,
    "unit": "шт",
    "warranty": true,
    "description": "Душевая кабина Triton (Душевая кабина Тритон Лайт 90х90 В (средний поддон)). Надежное закаленное стекло, усиленный акриловый поддон с металлическим каркасом, качественные ролики и заводская гарантия производителя.",
    "image": "https://piter3tn.ru/image/cache/catalog/3tn_ru/wa-data/public/shop/products/70/07/770/images/11445/11445.970-1000x1000.jpg",
    "gallery": [
      "https://piter3tn.ru/image/cache/catalog/3tn_ru/wa-data/public/shop/products/70/07/770/images/11445/11445.970-1000x1000.jpg",
      "https://piter3tn.ru/image/cache/catalog/3tn_ru/wa-data/public/shop/products/70/07/770/images/11446/11446.970-1000x1000.jpg",
      "https://piter3tn.ru/image/cache/catalog/3tn_ru/wa-data/public/shop/products/70/07/770/images/11447/11447.970-1000x1000.jpg",
      "https://piter3tn.ru/image/cache/catalog/3tn_ru/wa-data/public/shop/products/70/07/770/images/11448/11448.970-1000x1000.jpg",
      "https://piter3tn.ru/image/cache/catalog/3tn_ru/wa-data/public/shop/products/70/07/770/images/11449/11449.970-1000x1000.jpg",
      "https://piter3tn.ru/image/cache/catalog/3tn_ru/wa-data/public/shop/products/70/07/770/images/11450/11450.970-1000x1000.jpg",
      "https://piter3tn.ru/image/cache/catalog/3tn_ru/wa-data/public/shop/products/70/07/770/images/11451/11451.970-1000x1000.jpg",
      "https://piter3tn.ru/image/cache/catalog/3tn_ru/wa-data/public/shop/products/70/07/770/images/11536/11536.970-1000x1000.jpg"
    ],
    "characteristics": [
      {
        "name": "Высота поддона",
        "value": "310 мм"
      },
      {
        "name": "Глубина поддона",
        "value": "200 мм"
      },
      {
        "name": "Диаметр слива",
        "value": "50 мм"
      },
      {
        "name": "Длина",
        "value": "900 мм"
      },
      {
        "name": "Материал",
        "value": "Закалённое стекло, металлический профиль, акрил"
      },
      {
        "name": "Размер",
        "value": "90х90"
      },
      {
        "name": "Смеситель (душевой набор)",
        "value": "Triton DN4 с верхним душем"
      },
      {
        "name": "Тип (цвет, рисунок) переднего стекла",
        "value": "Лайт"
      },
      {
        "name": "Тип кабины",
        "value": "Закрытая кабина"
      }
    ]
  },
  {
    "id": 0,
    "name": "Душевая кабина Тритон Лайт 100х100 В (средний поддон)",
    "price": 44750,
    "code": "DK207",
    "brandId": "triton",
    "category": "dushevye-kabiny",
    "subcategory": "С средним поддоном",
    "inStock": false,
    "unit": "шт",
    "warranty": true,
    "description": "Душевая кабина Triton (Душевая кабина Тритон Лайт 100х100 В (средний поддон)). Надежное закаленное стекло, усиленный акриловый поддон с металлическим каркасом, качественные ролики и заводская гарантия производителя.",
    "image": "https://piter3tn.ru/image/cache/catalog/3tn_ru/wa-data/public/shop/products/67/07/767/images/11476/11476.970-1000x1000.jpg",
    "gallery": [
      "https://piter3tn.ru/image/cache/catalog/3tn_ru/wa-data/public/shop/products/67/07/767/images/11476/11476.970-1000x1000.jpg",
      "https://piter3tn.ru/image/cache/catalog/3tn_ru/wa-data/public/shop/products/67/07/767/images/11475/11475.970-1000x1000.jpg",
      "https://piter3tn.ru/image/cache/catalog/3tn_ru/wa-data/public/shop/products/67/07/767/images/11477/11477.970-1000x1000.png",
      "https://piter3tn.ru/image/cache/catalog/3tn_ru/wa-data/public/shop/products/67/07/767/images/11478/11478.970-1000x1000.jpg",
      "https://piter3tn.ru/image/cache/catalog/3tn_ru/wa-data/public/shop/products/67/07/767/images/11479/11479.970-1000x1000.jpg",
      "https://piter3tn.ru/image/cache/catalog/3tn_ru/wa-data/public/shop/products/67/07/767/images/11480/11480.970-1000x1000.jpg",
      "https://piter3tn.ru/image/cache/catalog/3tn_ru/wa-data/public/shop/products/67/07/767/images/11481/11481.970-1000x1000.jpg",
      "https://piter3tn.ru/image/cache/catalog/3tn_ru/wa-data/public/shop/products/67/07/767/images/11482/11482.970-1000x1000.jpg"
    ],
    "characteristics": [
      {
        "name": "Высота поддона",
        "value": "310 мм"
      },
      {
        "name": "Глубина поддона",
        "value": "200 мм"
      },
      {
        "name": "Диаметр слива",
        "value": "50 мм"
      },
      {
        "name": "Длина",
        "value": "1000 мм"
      },
      {
        "name": "Материал",
        "value": "Закалённое стекло, металлический профиль, акрил"
      },
      {
        "name": "Размер",
        "value": "100х100"
      },
      {
        "name": "Смеситель (душевой набор)",
        "value": "Triton DN4 с верхним душем"
      },
      {
        "name": "Тип (цвет, рисунок) переднего стекла",
        "value": "Лайт"
      },
      {
        "name": "Тип кабины",
        "value": "Закрытая кабина"
      }
    ]
  },
  {
    "id": 0,
    "name": "Душевая кабина Тритон Мозаика 100*100 В (7 мест+сифон D50мм)",
    "price": 44750,
    "code": "DK66",
    "brandId": "triton",
    "category": "dushevye-kabiny",
    "subcategory": "С средним поддоном",
    "inStock": false,
    "unit": "шт",
    "warranty": true,
    "description": "Душевая кабина Triton (Душевая кабина Тритон Мозаика 100*100 В (7 мест+сифон D50мм)). Надежное закаленное стекло, усиленный акриловый поддон с металлическим каркасом, качественные ролики и заводская гарантия производителя.",
    "image": "https://piter3tn.ru/image/cache/catalog/3tn_ru/wa-data/public/shop/products/12/04/412/images/10964/10964.970-1000x1000.jpg",
    "gallery": [
      "https://piter3tn.ru/image/cache/catalog/3tn_ru/wa-data/public/shop/products/12/04/412/images/10964/10964.970-1000x1000.jpg",
      "https://piter3tn.ru/image/cache/catalog/3tn_ru/wa-data/public/shop/products/12/04/412/images/10963/10963.970-1000x1000.jpg",
      "https://piter3tn.ru/image/cache/catalog/3tn_ru/wa-data/public/shop/products/12/04/412/images/9508/9508.970-1000x1000.jpg",
      "https://piter3tn.ru/image/cache/catalog/3tn_ru/wa-data/public/shop/products/12/04/412/images/9506/9506.970-1000x1000.jpg",
      "https://piter3tn.ru/image/cache/catalog/3tn_ru/wa-data/public/shop/products/12/04/412/images/9507/9507.970-1000x1000.jpg",
      "https://piter3tn.ru/image/cache/catalog/3tn_ru/wa-data/public/shop/products/12/04/412/images/11546/11546.970-1000x1000.jpg",
      "https://piter3tn.ru/image/cache/catalog/3tn_ru/wa-data/public/shop/products/12/04/412/images/11547/11547.970-1000x1000.jpg",
      "https://piter3tn.ru/image/cache/catalog/3tn_ru/wa-data/public/shop/products/12/04/412/images/9909/9909.970-1000x1000.jpg"
    ],
    "characteristics": [
      {
        "name": "Высота поддона",
        "value": "310 мм"
      },
      {
        "name": "Глубина поддона",
        "value": "200 мм"
      },
      {
        "name": "Диаметр слива",
        "value": "50 мм"
      },
      {
        "name": "Длина",
        "value": "1000 мм"
      },
      {
        "name": "Материал",
        "value": "Закалённое стекло, металлический профиль, акрил"
      },
      {
        "name": "Размер",
        "value": "100х100"
      },
      {
        "name": "Тип (цвет, рисунок) переднего стекла",
        "value": "Мозаика"
      },
      {
        "name": "Тип кабины",
        "value": "Закрытая кабина"
      },
      {
        "name": "Тип поддона",
        "value": "Средний"
      }
    ]
  },
  {
    "id": 0,
    "name": "Душевая кабина Тритон Мозаика 90*90 А (7 мест+сифон D90)",
    "price": 38470,
    "code": "DK89",
    "brandId": "triton",
    "category": "dushevye-kabiny",
    "subcategory": "С низким поддоном",
    "inStock": false,
    "unit": "шт",
    "warranty": true,
    "description": "Душевая кабина Triton (Душевая кабина Тритон Мозаика 90*90 А (7 мест+сифон D90)). Надежное закаленное стекло, усиленный акриловый поддон с металлическим каркасом, качественные ролики и заводская гарантия производителя.",
    "image": "https://piter3tn.ru/image/cache/catalog/3tn_ru/wa-data/public/shop/products/78/03/378/images/10218/10218.970-1000x1000.jpg",
    "gallery": [
      "https://piter3tn.ru/image/cache/catalog/3tn_ru/wa-data/public/shop/products/78/03/378/images/10218/10218.970-1000x1000.jpg",
      "https://piter3tn.ru/image/cache/catalog/3tn_ru/wa-data/public/shop/products/78/03/378/images/10219/10219.970-1000x1000.jpg",
      "https://piter3tn.ru/image/cache/catalog/3tn_ru/wa-data/public/shop/products/78/03/378/images/10182/10182.970-1000x1000.jpg",
      "https://piter3tn.ru/image/cache/catalog/3tn_ru/wa-data/public/shop/products/78/03/378/images/10183/10183.970-1000x1000.jpg",
      "https://piter3tn.ru/image/cache/catalog/3tn_ru/wa-data/public/shop/products/78/03/378/images/10181/10181.970-1000x1000.jpg",
      "https://piter3tn.ru/image/cache/catalog/3tn_ru/wa-data/public/shop/products/78/03/378/images/11538/11538.970-1000x1000.jpg",
      "https://piter3tn.ru/image/cache/catalog/3tn_ru/wa-data/public/shop/products/78/03/378/images/11539/11539.970-1000x1000.jpg",
      "https://piter3tn.ru/image/cache/catalog/3tn_ru/wa-data/public/shop/products/78/03/378/images/9901/9901.970-1000x1000.jpg"
    ],
    "characteristics": [
      {
        "name": "Высота поддона",
        "value": "170 мм"
      },
      {
        "name": "Глубина поддона",
        "value": "65 мм"
      },
      {
        "name": "Диаметр слива",
        "value": "90 мм"
      },
      {
        "name": "Длина",
        "value": "900 мм"
      },
      {
        "name": "Материал",
        "value": "Закалённое стекло, металлический профиль, акрил"
      },
      {
        "name": "Размер",
        "value": "90х90"
      },
      {
        "name": "Тип (цвет, рисунок) переднего стекла",
        "value": "Мозаика"
      },
      {
        "name": "Тип кабины",
        "value": "Закрытая кабина"
      },
      {
        "name": "Тип поддона",
        "value": "Низкий"
      }
    ]
  },
  {
    "id": 0,
    "name": "Душевая кабина Тритон Мозаика 90*90 В (7 мест+сифон D50)",
    "price": 40680,
    "code": "DK137",
    "brandId": "triton",
    "category": "dushevye-kabiny",
    "subcategory": "С средним поддоном",
    "inStock": false,
    "unit": "шт",
    "warranty": true,
    "description": "Душевая кабина Triton (Душевая кабина Тритон Мозаика 90*90 В (7 мест+сифон D50)). Надежное закаленное стекло, усиленный акриловый поддон с металлическим каркасом, качественные ролики и заводская гарантия производителя.",
    "image": "https://piter3tn.ru/image/cache/catalog/3tn_ru/wa-data/public/shop/products/99/03/399/images/10961/10961.970-1000x1000.jpg",
    "gallery": [
      "https://piter3tn.ru/image/cache/catalog/3tn_ru/wa-data/public/shop/products/99/03/399/images/10961/10961.970-1000x1000.jpg",
      "https://piter3tn.ru/image/cache/catalog/3tn_ru/wa-data/public/shop/products/99/03/399/images/10962/10962.970-1000x1000.jpg",
      "https://piter3tn.ru/image/cache/catalog/3tn_ru/wa-data/public/shop/products/99/03/399/images/10191/10191.970-1000x1000.jpg",
      "https://piter3tn.ru/image/cache/catalog/3tn_ru/wa-data/public/shop/products/99/03/399/images/10190/10190.970-1000x1000.jpg",
      "https://piter3tn.ru/image/cache/catalog/3tn_ru/wa-data/public/shop/products/99/03/399/images/10192/10192.970-1000x1000.jpg",
      "https://piter3tn.ru/image/cache/catalog/3tn_ru/wa-data/public/shop/products/99/03/399/images/10193/10193.970-1000x1000.jpg",
      "https://piter3tn.ru/image/cache/catalog/3tn_ru/wa-data/public/shop/products/99/03/399/images/11542/11542.970-1000x1000.jpg",
      "https://piter3tn.ru/image/cache/catalog/3tn_ru/wa-data/public/shop/products/99/03/399/images/11543/11543.970-1000x1000.jpg"
    ],
    "characteristics": [
      {
        "name": "Высота поддона",
        "value": "310 мм"
      },
      {
        "name": "Глубина поддона",
        "value": "200 мм"
      },
      {
        "name": "Диаметр слива",
        "value": "50 мм"
      },
      {
        "name": "Длина",
        "value": "900 мм"
      },
      {
        "name": "Материал",
        "value": "Закалённое стекло, металлический профиль, акрил"
      },
      {
        "name": "Размер",
        "value": "90х90"
      },
      {
        "name": "Тип (цвет, рисунок) переднего стекла",
        "value": "Мозаика"
      },
      {
        "name": "Тип кабины",
        "value": "Закрытая кабина"
      },
      {
        "name": "Тип поддона",
        "value": "Средний"
      }
    ]
  },
  {
    "id": 0,
    "name": "Душевая кабина Тритон Мозаика 100*100 А (7 мест+сифон D90мм)",
    "price": 44380,
    "code": "DK60",
    "brandId": "triton",
    "category": "dushevye-kabiny",
    "subcategory": "С низким поддоном",
    "inStock": false,
    "unit": "шт",
    "warranty": true,
    "description": "Душевая кабина Triton (Душевая кабина Тритон Мозаика 100*100 А (7 мест+сифон D90мм)). Надежное закаленное стекло, усиленный акриловый поддон с металлическим каркасом, качественные ролики и заводская гарантия производителя.",
    "image": "https://piter3tn.ru/image/cache/catalog/3tn_ru/wa-data/public/shop/products/07/04/407/images/10949/10949.970-1000x1000.jpg",
    "gallery": [
      "https://piter3tn.ru/image/cache/catalog/3tn_ru/wa-data/public/shop/products/07/04/407/images/10949/10949.970-1000x1000.jpg",
      "https://piter3tn.ru/image/cache/catalog/3tn_ru/wa-data/public/shop/products/07/04/407/images/9502/9502.970-1000x1000.jpg",
      "https://piter3tn.ru/image/cache/catalog/3tn_ru/wa-data/public/shop/products/07/04/407/images/9499/9499.970-1000x1000.jpg",
      "https://piter3tn.ru/image/cache/catalog/3tn_ru/wa-data/public/shop/products/07/04/407/images/9501/9501.970-1000x1000.jpg",
      "https://piter3tn.ru/image/cache/catalog/3tn_ru/wa-data/public/shop/products/07/04/407/images/11544/11544.970-1000x1000.jpg",
      "https://piter3tn.ru/image/cache/catalog/3tn_ru/wa-data/public/shop/products/07/04/407/images/11545/11545.970-1000x1000.jpg",
      "https://piter3tn.ru/image/cache/catalog/3tn_ru/wa-data/public/shop/products/07/04/407/images/9910/9910.970-1000x1000.jpg",
      "https://piter3tn.ru/image/cache/catalog/3tn_ru/wa-data/public/shop/products/07/04/407/images/10297/10297.970-1000x1000.jpg"
    ],
    "characteristics": [
      {
        "name": "Высота поддона",
        "value": "170 мм"
      },
      {
        "name": "Глубина поддона",
        "value": "65 мм"
      },
      {
        "name": "Диаметр слива",
        "value": "90 мм"
      },
      {
        "name": "Длина",
        "value": "1000 мм"
      },
      {
        "name": "Материал",
        "value": "Закалённое стекло, металлический профиль, акрил"
      },
      {
        "name": "Размер",
        "value": "100х100"
      },
      {
        "name": "Тип (цвет, рисунок) переднего стекла",
        "value": "Мозаика"
      },
      {
        "name": "Тип кабины",
        "value": "Закрытая кабина"
      },
      {
        "name": "Тип поддона",
        "value": "Низкий"
      }
    ]
  },
  {
    "id": 0,
    "name": "Душевая кабина Тритон Нова 88х88",
    "price": 37560,
    "code": "DK350",
    "brandId": "triton",
    "category": "dushevye-kabiny",
    "subcategory": "С низким поддоном",
    "inStock": false,
    "unit": "шт",
    "warranty": true,
    "description": "Душевая кабина Triton (Душевая кабина Тритон Нова 88х88). Надежное закаленное стекло, усиленный акриловый поддон с металлическим каркасом, качественные ролики и заводская гарантия производителя.",
    "image": "https://piter3tn.ru/image/cache/catalog/3tn_ru/wa-data/public/shop/products/93/10/1093/images/9657/9657.970-1000x1000.png",
    "gallery": [
      "https://piter3tn.ru/image/cache/catalog/3tn_ru/wa-data/public/shop/products/93/10/1093/images/9657/9657.970-1000x1000.png",
      "https://piter3tn.ru/image/cache/catalog/3tn_ru/wa-data/public/shop/products/93/10/1093/images/9658/9658.970-1000x1000.png",
      "https://piter3tn.ru/image/cache/catalog/3tn_ru/wa-data/public/shop/products/93/10/1093/images/9660/9660.970-1000x1000.png",
      "https://piter3tn.ru/image/cache/catalog/3tn_ru/wa-data/public/shop/products/93/10/1093/images/9659/9659.970-1000x1000.png",
      "https://piter3tn.ru/image/cache/catalog/3tn_ru/wa-data/public/shop/products/93/10/1093/images/9661/9661.970-1000x1000.jpg",
      "https://piter3tn.ru/image/cache/catalog/3tn_ru/wa-data/public/shop/products/93/10/1093/images/9662/9662.970-1000x1000.jpg",
      "https://piter3tn.ru/image/cache/catalog/3tn_ru/wa-data/public/shop/products/93/10/1093/images/10237/10237.970-1000x1000.jpg",
      "https://piter3tn.ru/image/cache/catalog/3tn_ru/wa-data/public/shop/products/93/10/1093/images/9652/9652.970-1000x1000.jpg"
    ],
    "characteristics": [
      {
        "name": "Высота поддона",
        "value": "170 мм"
      },
      {
        "name": "Глубина поддона",
        "value": "65 мм"
      },
      {
        "name": "Диаметр слива",
        "value": "50 мм"
      },
      {
        "name": "Длина",
        "value": "880 мм"
      },
      {
        "name": "Материал",
        "value": "Закалённое стекло, металлический профиль, акрил"
      },
      {
        "name": "Размер",
        "value": "88х88"
      },
      {
        "name": "Смеситель (душевой набор)",
        "value": "Triton DN4 с верхним душем"
      },
      {
        "name": "Тип (цвет, рисунок) переднего стекла",
        "value": "Прозрачное"
      },
      {
        "name": "Тип кабины",
        "value": "Закрытая кабина"
      }
    ]
  },
  {
    "id": 0,
    "name": "Душевая кабина Тритон Стандарт Мозаика 90х90 Б",
    "price": 39410,
    "code": "DK113",
    "brandId": "triton",
    "category": "dushevye-kabiny",
    "subcategory": "С высоким поддоном",
    "inStock": false,
    "unit": "шт",
    "warranty": true,
    "description": "Душевая кабина Triton (Душевая кабина Тритон Стандарт Мозаика 90х90 Б). Надежное закаленное стекло, усиленный акриловый поддон с металлическим каркасом, качественные ролики и заводская гарантия производителя.",
    "image": "https://piter3tn.ru/image/cache/catalog/3tn_ru/wa-data/public/shop/products/89/03/389/images/10384/10384.970-1000x1000.png",
    "gallery": [
      "https://piter3tn.ru/image/cache/catalog/3tn_ru/wa-data/public/shop/products/89/03/389/images/10384/10384.970-1000x1000.png",
      "https://piter3tn.ru/image/cache/catalog/3tn_ru/wa-data/public/shop/products/89/03/389/images/10383/10383.970-1000x1000.png",
      "https://piter3tn.ru/image/cache/catalog/3tn_ru/wa-data/public/shop/products/89/03/389/images/10385/10385.970-1000x1000.jpg",
      "https://piter3tn.ru/image/cache/catalog/3tn_ru/wa-data/public/shop/products/89/03/389/images/10386/10386.970-1000x1000.jpg",
      "https://piter3tn.ru/image/cache/catalog/3tn_ru/wa-data/public/shop/products/89/03/389/images/10387/10387.970-1000x1000.jpg",
      "https://piter3tn.ru/image/cache/catalog/3tn_ru/wa-data/public/shop/products/89/03/389/images/11541/11541.970-1000x1000.jpg",
      "https://piter3tn.ru/image/cache/catalog/3tn_ru/wa-data/public/shop/products/89/03/389/images/11540/11540.970-1000x1000.jpg",
      "https://piter3tn.ru/image/cache/catalog/3tn_ru/wa-data/public/shop/products/89/03/389/images/10308/10308.970-1000x1000.jpg"
    ],
    "characteristics": [
      {
        "name": "Высота поддона",
        "value": "450 мм"
      },
      {
        "name": "Глубина поддона",
        "value": "350 мм"
      },
      {
        "name": "Диаметр слива",
        "value": "50 мм"
      },
      {
        "name": "Длина",
        "value": "900 мм"
      },
      {
        "name": "Материал",
        "value": "Закалённое стекло, металлический профиль, акрил"
      },
      {
        "name": "Размер",
        "value": "90х90"
      },
      {
        "name": "Смеситель (душевой набор)",
        "value": "Triton DN4 с верхним душем"
      },
      {
        "name": "Тип (цвет, рисунок) переднего стекла",
        "value": "Узорчатое"
      },
      {
        "name": "Тип кабины",
        "value": "Закрытая кабина"
      }
    ]
  },
  {
    "id": 0,
    "name": "Душевая кабина Тритон Топ 90*90 А (7 мест+сифон D90)",
    "price": 39090,
    "code": "DK382",
    "brandId": "triton",
    "category": "dushevye-kabiny",
    "subcategory": "С низким поддоном",
    "inStock": false,
    "unit": "шт",
    "warranty": true,
    "description": "Душевая кабина Triton (Душевая кабина Тритон Топ 90*90 А (7 мест+сифон D90)). Надежное закаленное стекло, усиленный акриловый поддон с металлическим каркасом, качественные ролики и заводская гарантия производителя.",
    "image": "https://piter3tn.ru/image/cache/catalog/3tn_ru/wa-data/public/shop/products/98/09/998/images/10248/10248.970-1000x1000.png",
    "gallery": [
      "https://piter3tn.ru/image/cache/catalog/3tn_ru/wa-data/public/shop/products/98/09/998/images/10248/10248.970-1000x1000.png",
      "https://piter3tn.ru/image/cache/catalog/3tn_ru/wa-data/public/shop/products/98/09/998/images/10247/10247.970-1000x1000.png",
      "https://piter3tn.ru/image/cache/catalog/3tn_ru/wa-data/public/shop/products/98/09/998/images/10249/10249.970-1000x1000.jpg",
      "https://piter3tn.ru/image/cache/catalog/3tn_ru/wa-data/public/shop/products/98/09/998/images/10250/10250.970-1000x1000.jpg",
      "https://piter3tn.ru/image/cache/catalog/3tn_ru/wa-data/public/shop/products/98/09/998/images/10242/10242.970-1000x1000.jpg",
      "https://piter3tn.ru/image/cache/catalog/3tn_ru/wa-data/public/shop/products/98/09/998/images/10238/10238.970-1000x1000.jpg",
      "https://piter3tn.ru/image/cache/catalog/3tn_ru/wa-data/public/shop/products/98/09/998/images/8552/8552.970-1000x1000.png",
      "https://piter3tn.ru/image/cache/catalog/3tn_ru/wa-data/public/shop/products/98/09/998/images/8654/8654.970-1000x1000.png"
    ],
    "characteristics": [
      {
        "name": "Высота поддона",
        "value": "170 мм"
      },
      {
        "name": "Глубина поддона",
        "value": "65 мм"
      },
      {
        "name": "Диаметр слива",
        "value": "90 мм"
      },
      {
        "name": "Длина",
        "value": "900 мм"
      },
      {
        "name": "Материал",
        "value": "Закалённое стекло, металлический профиль, акрил"
      },
      {
        "name": "Размер",
        "value": "90х90"
      },
      {
        "name": "Тип (цвет, рисунок) переднего стекла",
        "value": "Прозрачное"
      },
      {
        "name": "Тип кабины",
        "value": "Закрытая кабина"
      },
      {
        "name": "Тип поддона",
        "value": "Низкий"
      }
    ]
  },
  {
    "id": 0,
    "name": "Душевая кабина Тритон Топ 90х90 В (средний поддон) с полкой",
    "price": 41300,
    "code": "DK367",
    "brandId": "triton",
    "category": "dushevye-kabiny",
    "subcategory": "С средним поддоном",
    "inStock": false,
    "unit": "шт",
    "warranty": true,
    "description": "Душевая кабина Triton (Душевая кабина Тритон Топ 90х90 В (средний поддон) с полкой). Надежное закаленное стекло, усиленный акриловый поддон с металлическим каркасом, качественные ролики и заводская гарантия производителя.",
    "image": "https://piter3tn.ru/image/cache/catalog/3tn_ru/wa-data/public/shop/products/13/11/1113/images/10731/10731.970-1000x1000.jpg",
    "gallery": [
      "https://piter3tn.ru/image/cache/catalog/3tn_ru/wa-data/public/shop/products/13/11/1113/images/10731/10731.970-1000x1000.jpg",
      "https://piter3tn.ru/image/cache/catalog/3tn_ru/wa-data/public/shop/products/13/11/1113/images/10730/10730.970-1000x1000.jpg",
      "https://piter3tn.ru/image/cache/catalog/3tn_ru/wa-data/public/shop/products/13/11/1113/images/10733/10733.970-1000x1000.jpg",
      "https://piter3tn.ru/image/cache/catalog/3tn_ru/wa-data/public/shop/products/13/11/1113/images/10732/10732.970-1000x1000.jpg",
      "https://piter3tn.ru/image/cache/catalog/3tn_ru/wa-data/public/shop/products/13/11/1113/images/10734/10734.970-1000x1000.jpg",
      "https://piter3tn.ru/image/cache/catalog/3tn_ru/wa-data/public/shop/products/13/11/1113/images/10735/10735.970-1000x1000.jpg",
      "https://piter3tn.ru/image/cache/catalog/3tn_ru/wa-data/public/shop/products/13/11/1113/images/10736/10736.970-1000x1000.jpg",
      "https://piter3tn.ru/image/cache/catalog/3tn_ru/wa-data/public/shop/products/13/11/1113/images/10509/10509.970-1000x1000.jpg"
    ],
    "characteristics": [
      {
        "name": "Высота поддона",
        "value": "310 мм"
      },
      {
        "name": "Глубина поддона",
        "value": "200 мм"
      },
      {
        "name": "Диаметр слива",
        "value": "50 мм"
      },
      {
        "name": "Длина",
        "value": "900 мм"
      },
      {
        "name": "Материал",
        "value": "Закалённое стекло, металлический профиль, акрил"
      },
      {
        "name": "Размер",
        "value": "88х88"
      },
      {
        "name": "Смеситель (душевой набор)",
        "value": "Triton DN4 с верхним душем"
      },
      {
        "name": "Тип (цвет, рисунок) переднего стекла",
        "value": "Без рисунка"
      },
      {
        "name": "Тип кабины",
        "value": "Закрытая кабина"
      }
    ]
  },
  {
    "id": 0,
    "name": "Душевая кабина Тритон Ультра 80х80",
    "price": 33890,
    "code": "DK242",
    "brandId": "triton",
    "category": "dushevye-kabiny",
    "subcategory": "С низким поддоном",
    "inStock": false,
    "unit": "шт",
    "warranty": true,
    "description": "Душевая кабина Triton (Душевая кабина Тритон Ультра 80х80). Надежное закаленное стекло, усиленный акриловый поддон с металлическим каркасом, качественные ролики и заводская гарантия производителя.",
    "image": "https://piter3tn.ru/image/cache/catalog/image/catalog/product/dushevye-kabiny/triton-ultra-80/kabina/ultra-80-1-vd-500x500.jpg",
    "characteristics": [
      {
        "name": "Высота поддона",
        "value": "170 мм"
      },
      {
        "name": "Глубина поддона",
        "value": "65 мм"
      },
      {
        "name": "Диаметр слива",
        "value": "90 мм"
      },
      {
        "name": "Длина",
        "value": "800 мм"
      },
      {
        "name": "Материал",
        "value": "Закалённое стекло, металлический профиль, акрил"
      },
      {
        "name": "Размер",
        "value": "80х80"
      },
      {
        "name": "Смеситель (душевой набор)",
        "value": "Triton DN4 с верхним душем"
      },
      {
        "name": "Тип (цвет, рисунок) переднего стекла",
        "value": "Прозрачное"
      },
      {
        "name": "Тип кабины",
        "value": "Закрытая кабина"
      }
    ]
  },
  {
    "id": 0,
    "name": "Душевая кабина Тритон Экстра 88х88",
    "price": 35350,
    "code": "DK351",
    "brandId": "triton",
    "category": "dushevye-kabiny",
    "subcategory": "С низким поддоном",
    "inStock": false,
    "unit": "шт",
    "warranty": true,
    "description": "Душевая кабина Triton (Душевая кабина Тритон Экстра 88х88). Надежное закаленное стекло, усиленный акриловый поддон с металлическим каркасом, качественные ролики и заводская гарантия производителя.",
    "image": "https://piter3tn.ru/image/cache/catalog/3tn_ru/wa-data/public/shop/products/91/10/1091/images/9626/9626.970-1000x1000.png",
    "gallery": [
      "https://piter3tn.ru/image/cache/catalog/3tn_ru/wa-data/public/shop/products/91/10/1091/images/9626/9626.970-1000x1000.png",
      "https://piter3tn.ru/image/cache/catalog/3tn_ru/wa-data/public/shop/products/91/10/1091/images/9627/9627.970-1000x1000.png",
      "https://piter3tn.ru/image/cache/catalog/3tn_ru/wa-data/public/shop/products/91/10/1091/images/9629/9629.970-1000x1000.jpg",
      "https://piter3tn.ru/image/cache/catalog/3tn_ru/wa-data/public/shop/products/91/10/1091/images/9628/9628.970-1000x1000.jpg",
      "https://piter3tn.ru/image/cache/catalog/3tn_ru/wa-data/public/shop/products/91/10/1091/images/9630/9630.970-1000x1000.jpg",
      "https://piter3tn.ru/image/cache/catalog/3tn_ru/wa-data/public/shop/products/91/10/1091/images/9631/9631.970-1000x1000.jpg",
      "https://piter3tn.ru/image/cache/catalog/3tn_ru/wa-data/public/shop/products/91/10/1091/images/9885/9885.970-1000x1000.jpg",
      "https://piter3tn.ru/image/cache/catalog/3tn_ru/wa-data/public/shop/products/91/10/1091/images/9632/9632.970-1000x1000.jpg"
    ],
    "characteristics": [
      {
        "name": "Высота поддона",
        "value": "170 мм"
      },
      {
        "name": "Глубина поддона",
        "value": "65 мм"
      },
      {
        "name": "Диаметр слива",
        "value": "50 мм"
      },
      {
        "name": "Длина",
        "value": "880 мм"
      },
      {
        "name": "Материал",
        "value": "Закалённое стекло, металлический профиль, акрил"
      },
      {
        "name": "Размер",
        "value": "88х88"
      },
      {
        "name": "Смеситель (душевой набор)",
        "value": "Triton DN4 с верхним душем"
      },
      {
        "name": "Тип (цвет, рисунок) переднего стекла",
        "value": "Прозрачное"
      },
      {
        "name": "Тип кабины",
        "value": "Закрытая кабина"
      }
    ]
  },
  {
    "id": 0,
    "name": "Душевая Кабина Ультра 80*80 В",
    "price": 35700,
    "code": "DK407",
    "brandId": "triton",
    "category": "dushevye-kabiny",
    "subcategory": "С средним поддоном",
    "inStock": false,
    "unit": "шт",
    "warranty": true,
    "description": "Душевая кабина Triton (Душевая Кабина Ультра 80*80 В). Надежное закаленное стекло, усиленный акриловый поддон с металлическим каркасом, качественные ролики и заводская гарантия производителя.",
    "image": "https://piter3tn.ru/image/cache/catalog/3tn_ru/wa-data/public/shop/products/03/12/1203/images/12401/12401.970-1000x1000.jpg",
    "gallery": [
      "https://piter3tn.ru/image/cache/catalog/3tn_ru/wa-data/public/shop/products/03/12/1203/images/12401/12401.970-1000x1000.jpg",
      "https://piter3tn.ru/image/cache/catalog/3tn_ru/wa-data/public/shop/products/03/12/1203/images/12385/12385.970-1000x1000.png",
      "https://piter3tn.ru/image/cache/catalog/3tn_ru/wa-data/public/shop/products/03/12/1203/images/12387/12387.970-1000x1000.jpg",
      "https://piter3tn.ru/image/cache/catalog/3tn_ru/wa-data/public/shop/products/03/12/1203/images/12395/12395.970-1000x1000.jpg",
      "https://piter3tn.ru/image/cache/catalog/3tn_ru/wa-data/public/shop/products/03/12/1203/images/12388/12388.970-1000x1000.jpg",
      "https://piter3tn.ru/image/cache/catalog/3tn_ru/wa-data/public/shop/products/03/12/1203/images/12364/12364.970-1000x1000.jpg",
      "https://piter3tn.ru/image/cache/catalog/3tn_ru/wa-data/public/shop/products/03/12/1203/images/12365/12365.970-1000x1000.jpg",
      "https://piter3tn.ru/image/cache/catalog/3tn_ru/wa-data/public/shop/products/03/12/1203/images/12366/12366.970-1000x1000.jpg"
    ],
    "characteristics": [
      {
        "name": "Высота поддона",
        "value": "310 мм"
      },
      {
        "name": "Глубина поддона",
        "value": "200 мм"
      },
      {
        "name": "Диаметр слива",
        "value": "50 мм"
      },
      {
        "name": "Длина",
        "value": "800 мм"
      },
      {
        "name": "Материал",
        "value": "Закалённое стекло, металлический профиль, акрил"
      },
      {
        "name": "Размер",
        "value": "80х80"
      },
      {
        "name": "Тип (цвет, рисунок) переднего стекла",
        "value": "Прозрачное"
      },
      {
        "name": "Тип кабины",
        "value": "Закрытая кабина"
      },
      {
        "name": "Тип поддона",
        "value": "Средний"
      }
    ]
  },
  {
    "id": 0,
    "name": "Душевая кабина Тритон Ультра 80х80 без крыши",
    "price": 29720,
    "code": "DK459",
    "brandId": "triton",
    "category": "dushevye-kabiny",
    "subcategory": "С низким поддоном",
    "inStock": false,
    "unit": "шт",
    "warranty": true,
    "description": "Душевая кабина Triton (Душевая кабина Тритон Ультра 80х80 без крыши). Надежное закаленное стекло, усиленный акриловый поддон с металлическим каркасом, качественные ролики и заводская гарантия производителя.",
    "image": "https://piter3tn.ru/image/cache/catalog/3tn_ru/wa-data/public/shop/products/59/12/1259/images/13590/13590.970-1000x1000.jpg",
    "gallery": [
      "https://piter3tn.ru/image/cache/catalog/3tn_ru/wa-data/public/shop/products/59/12/1259/images/13590/13590.970-1000x1000.jpg",
      "https://piter3tn.ru/image/cache/catalog/3tn_ru/wa-data/public/shop/products/59/12/1259/images/13582/13582.970-1000x1000.jpg",
      "https://piter3tn.ru/image/cache/catalog/3tn_ru/wa-data/public/shop/products/59/12/1259/images/13583/13583.970-1000x1000.jpg",
      "https://piter3tn.ru/image/cache/catalog/3tn_ru/wa-data/public/shop/products/59/12/1259/images/13584/13584.970-1000x1000.jpg",
      "https://piter3tn.ru/image/cache/catalog/3tn_ru/wa-data/public/shop/products/59/12/1259/images/13585/13585.970-1000x1000.jpg",
      "https://piter3tn.ru/image/cache/catalog/3tn_ru/wa-data/public/shop/products/59/12/1259/images/13579/13579.970-1000x1000.jpg",
      "https://piter3tn.ru/image/cache/catalog/3tn_ru/wa-data/public/shop/products/59/12/1259/images/13576/13576.970-1000x1000.png",
      "https://piter3tn.ru/image/cache/catalog/3tn_ru/wa-data/public/shop/products/59/12/1259/images/13577/13577.970-1000x1000.png"
    ],
    "characteristics": [
      {
        "name": "Высота поддона",
        "value": "170 мм"
      },
      {
        "name": "Глубина поддона",
        "value": "65 мм"
      },
      {
        "name": "Диаметр слива",
        "value": "90 мм"
      },
      {
        "name": "Длина",
        "value": "800 мм"
      },
      {
        "name": "Материал",
        "value": "Закалённое стекло, металлический профиль, акрил"
      },
      {
        "name": "Размер",
        "value": "80х80"
      },
      {
        "name": "Тип (цвет, рисунок) переднего стекла",
        "value": "Прозрачное"
      },
      {
        "name": "Тип кабины",
        "value": "Кабина без крыши"
      },
      {
        "name": "Тип поддона",
        "value": "Низкий"
      }
    ]
  },
  {
    "id": 0,
    "name": "Душевая кабина Тритон Квадро 100х80",
    "price": 47890,
    "code": "DK263",
    "brandId": "triton",
    "category": "dushevye-kabiny",
    "subcategory": "С низким поддоном",
    "inStock": false,
    "unit": "шт",
    "warranty": true,
    "description": "Душевая кабина Triton (Душевая кабина Тритон Квадро 100х80). Надежное закаленное стекло, усиленный акриловый поддон с металлическим каркасом, качественные ролики и заводская гарантия производителя.",
    "image": "https://piter3tn.ru/image/cache/catalog/3tn_ru/wa-data/public/shop/products/58/07/758/images/11768/11768.970-1000x1000.png",
    "gallery": [
      "https://piter3tn.ru/image/cache/catalog/3tn_ru/wa-data/public/shop/products/58/07/758/images/11768/11768.970-1000x1000.png",
      "https://piter3tn.ru/image/cache/catalog/3tn_ru/wa-data/public/shop/products/58/07/758/images/11760/11760.970-1000x1000.jpg",
      "https://piter3tn.ru/image/cache/catalog/3tn_ru/wa-data/public/shop/products/58/07/758/images/11761/11761.970-1000x1000.jpg",
      "https://piter3tn.ru/image/cache/catalog/3tn_ru/wa-data/public/shop/products/58/07/758/images/11762/11762.970-1000x1000.jpg",
      "https://piter3tn.ru/image/cache/catalog/3tn_ru/wa-data/public/shop/products/58/07/758/images/9911/9911.970-1000x1000.jpg",
      "https://piter3tn.ru/image/cache/catalog/3tn_ru/wa-data/public/shop/products/58/07/758/images/11740/11740.970-1000x1000.jpg",
      "https://piter3tn.ru/image/cache/catalog/3tn_ru/wa-data/public/shop/products/58/07/758/images/5709/5709.970-1000x1000.jpg",
      "https://piter3tn.ru/image/cache/catalog/3tn_ru/wa-data/public/shop/products/58/07/758/images/9423/9423.970-1000x1000.jpg"
    ],
    "characteristics": [
      {
        "name": "Высота поддона",
        "value": "170 мм"
      },
      {
        "name": "Глубина поддона",
        "value": "65 мм"
      },
      {
        "name": "Диаметр слива",
        "value": "90 мм"
      },
      {
        "name": "Длина",
        "value": "800 мм"
      },
      {
        "name": "Материал",
        "value": "Закалённое стекло, металлический профиль, акрил"
      },
      {
        "name": "Размер",
        "value": "100х80"
      },
      {
        "name": "Смеситель (душевой набор)",
        "value": "Triton DN4 с верхним душем"
      },
      {
        "name": "Тип (цвет, рисунок) переднего стекла",
        "value": "Полосы"
      },
      {
        "name": "Тип кабины",
        "value": "Закрытая кабина"
      }
    ]
  },
  {
    "id": 0,
    "name": "Душевая Кабина Рич-Графит 120*90 А (правая)",
    "price": 72620,
    "code": "DK536",
    "brandId": "triton",
    "category": "dushevye-kabiny",
    "subcategory": "С низким поддоном",
    "inStock": false,
    "unit": "шт",
    "warranty": true,
    "description": "Душевая кабина Triton (Душевая Кабина Рич-Графит 120*90 А (правая)). Надежное закаленное стекло, усиленный акриловый поддон с металлическим каркасом, качественные ролики и заводская гарантия производителя.",
    "image": "https://piter3tn.ru/image/cache/catalog/wa-data/public/shop/products/54/13/1354/images/16498/16498.970-1000x1000.jpg",
    "gallery": [
      "https://piter3tn.ru/image/cache/catalog/wa-data/public/shop/products/54/13/1354/images/16498/16498.970-1000x1000.jpg",
      "https://piter3tn.ru/image/cache/catalog/wa-data/public/shop/products/54/13/1354/images/16497/16497.970-1000x1000.jpg",
      "https://piter3tn.ru/image/cache/catalog/wa-data/public/shop/products/54/13/1354/images/15871/15871.970-1000x1000.jpg",
      "https://piter3tn.ru/image/cache/catalog/wa-data/public/shop/products/54/13/1354/images/15858/15858.970-1000x1000.jpg",
      "https://piter3tn.ru/image/cache/catalog/wa-data/public/shop/products/54/13/1354/images/15872/15872.970-1000x1000.jpg",
      "https://piter3tn.ru/image/cache/catalog/wa-data/public/shop/products/54/13/1354/images/15873/15873.970-1000x1000.jpg",
      "https://piter3tn.ru/image/cache/catalog/wa-data/public/shop/products/54/13/1354/images/15874/15874.970-1000x1000.jpg",
      "https://piter3tn.ru/image/cache/catalog/wa-data/public/shop/products/54/13/1354/images/16354/16354.970-1000x1000.jpg"
    ],
    "characteristics": [
      {
        "name": "Высота поддона",
        "value": "170 мм"
      },
      {
        "name": "Глубина поддона",
        "value": "45 мм"
      },
      {
        "name": "Диаметр слива",
        "value": "50 мм"
      },
      {
        "name": "Длина",
        "value": "1200 мм"
      },
      {
        "name": "Материал",
        "value": "Алюминий"
      },
      {
        "name": "Размер",
        "value": "120х90"
      },
      {
        "name": "Тип (цвет, рисунок) переднего стекла",
        "value": "Прозрачное"
      },
      {
        "name": "Тип кабины",
        "value": "Закрытая кабина"
      },
      {
        "name": "Тип поддона",
        "value": "Низкий"
      }
    ]
  },
  {
    "id": 0,
    "name": "Душевая Кабина Рич-Блэк 120*90 А (правая)",
    "price": 69870,
    "code": "DK535",
    "brandId": "triton",
    "category": "dushevye-kabiny",
    "subcategory": "С низким поддоном",
    "inStock": false,
    "unit": "шт",
    "warranty": true,
    "description": "Душевая кабина Triton (Душевая Кабина Рич-Блэк 120*90 А (правая)). Надежное закаленное стекло, усиленный акриловый поддон с металлическим каркасом, качественные ролики и заводская гарантия производителя.",
    "image": "https://piter3tn.ru/image/cache/catalog/wa-data/public/shop/products/50/13/1350/images/15817/15817.970-1000x1000.jpg",
    "gallery": [
      "https://piter3tn.ru/image/cache/catalog/wa-data/public/shop/products/50/13/1350/images/15817/15817.970-1000x1000.jpg",
      "https://piter3tn.ru/image/cache/catalog/wa-data/public/shop/products/50/13/1350/images/15816/15816.970-1000x1000.jpg",
      "https://piter3tn.ru/image/cache/catalog/wa-data/public/shop/products/50/13/1350/images/15818/15818.970-1000x1000.jpg",
      "https://piter3tn.ru/image/cache/catalog/wa-data/public/shop/products/50/13/1350/images/15819/15819.970-1000x1000.jpg",
      "https://piter3tn.ru/image/cache/catalog/wa-data/public/shop/products/50/13/1350/images/15823/15823.970-1000x1000.jpg",
      "https://piter3tn.ru/image/cache/catalog/wa-data/public/shop/products/50/13/1350/images/15782/15782.970-1000x1000.jpg",
      "https://piter3tn.ru/image/cache/catalog/wa-data/public/shop/products/50/13/1350/images/15824/15824.970-1000x1000.jpg",
      "https://piter3tn.ru/image/cache/catalog/wa-data/public/shop/products/50/13/1350/images/16352/16352.970-1000x1000.jpg"
    ],
    "characteristics": [
      {
        "name": "Высота поддона",
        "value": "170 мм"
      },
      {
        "name": "Глубина поддона",
        "value": "45 мм"
      },
      {
        "name": "Диаметр слива",
        "value": "50 мм"
      },
      {
        "name": "Длина",
        "value": "1200 мм"
      },
      {
        "name": "Материал",
        "value": "Алюминий"
      },
      {
        "name": "Размер",
        "value": "120х90"
      },
      {
        "name": "Тип (цвет, рисунок) переднего стекла",
        "value": "Прозрачное"
      },
      {
        "name": "Тип кабины",
        "value": "Закрытая кабина"
      },
      {
        "name": "Тип поддона",
        "value": "Низкий"
      }
    ]
  },
  {
    "id": 0,
    "name": "Душевая Кабина Рич-Хром 120*90 А (правая)",
    "price": 71220,
    "code": "DK537",
    "brandId": "triton",
    "category": "dushevye-kabiny",
    "subcategory": "С низким поддоном",
    "inStock": false,
    "unit": "шт",
    "warranty": true,
    "description": "Душевая кабина Triton (Душевая Кабина Рич-Хром 120*90 А (правая)). Надежное закаленное стекло, усиленный акриловый поддон с металлическим каркасом, качественные ролики и заводская гарантия производителя.",
    "image": "https://piter3tn.ru/image/cache/catalog/wa-data/public/shop/products/53/13/1353/images/15843/15843.970-1000x1000.jpg",
    "gallery": [
      "https://piter3tn.ru/image/cache/catalog/wa-data/public/shop/products/53/13/1353/images/15843/15843.970-1000x1000.jpg",
      "https://piter3tn.ru/image/cache/catalog/wa-data/public/shop/products/53/13/1353/images/15844/15844.970-1000x1000.jpg",
      "https://piter3tn.ru/image/cache/catalog/wa-data/public/shop/products/53/13/1353/images/15846/15846.970-1000x1000.jpg",
      "https://piter3tn.ru/image/cache/catalog/wa-data/public/shop/products/53/13/1353/images/15845/15845.970-1000x1000.jpg",
      "https://piter3tn.ru/image/cache/catalog/wa-data/public/shop/products/53/13/1353/images/15831/15831.970-1000x1000.jpg",
      "https://piter3tn.ru/image/cache/catalog/wa-data/public/shop/products/53/13/1353/images/15847/15847.970-1000x1000.jpg",
      "https://piter3tn.ru/image/cache/catalog/wa-data/public/shop/products/53/13/1353/images/16353/16353.970-1000x1000.jpg",
      "https://piter3tn.ru/image/cache/catalog/wa-data/public/shop/products/53/13/1353/images/15850/15850.970-1000x1000.jpg"
    ],
    "characteristics": [
      {
        "name": "Высота поддона",
        "value": "170 мм"
      },
      {
        "name": "Глубина поддона",
        "value": "45 мм"
      },
      {
        "name": "Диаметр слива",
        "value": "50 мм"
      },
      {
        "name": "Длина",
        "value": "1200 мм"
      },
      {
        "name": "Материал",
        "value": "Алюминий"
      },
      {
        "name": "Размер",
        "value": "120х90"
      },
      {
        "name": "Тип (цвет, рисунок) переднего стекла",
        "value": "Прозрачное"
      },
      {
        "name": "Тип кабины",
        "value": "Закрытая кабина"
      },
      {
        "name": "Тип поддона",
        "value": "Низкий"
      }
    ]
  },
  {
    "id": 0,
    "name": "Душевая кабина Тритон Квадро 120х80",
    "price": 51710,
    "code": "DK264",
    "brandId": "triton",
    "category": "dushevye-kabiny",
    "subcategory": "С низким поддоном",
    "inStock": false,
    "unit": "шт",
    "warranty": true,
    "description": "Душевая кабина Triton (Душевая кабина Тритон Квадро 120х80). Надежное закаленное стекло, усиленный акриловый поддон с металлическим каркасом, качественные ролики и заводская гарантия производителя.",
    "image": "https://piter3tn.ru/image/cache/catalog/3tn_ru/wa-data/public/shop/products/59/07/759/images/11769/11769.970-1000x1000.png",
    "gallery": [
      "https://piter3tn.ru/image/cache/catalog/3tn_ru/wa-data/public/shop/products/59/07/759/images/11769/11769.970-1000x1000.png",
      "https://piter3tn.ru/image/cache/catalog/3tn_ru/wa-data/public/shop/products/59/07/759/images/11765/11765.970-1000x1000.jpg",
      "https://piter3tn.ru/image/cache/catalog/3tn_ru/wa-data/public/shop/products/59/07/759/images/11766/11766.970-1000x1000.jpg",
      "https://piter3tn.ru/image/cache/catalog/3tn_ru/wa-data/public/shop/products/59/07/759/images/11767/11767.970-1000x1000.jpg",
      "https://piter3tn.ru/image/cache/catalog/3tn_ru/wa-data/public/shop/products/59/07/759/images/9916/9916.970-1000x1000.jpg",
      "https://piter3tn.ru/image/cache/catalog/3tn_ru/wa-data/public/shop/products/59/07/759/images/11741/11741.970-1000x1000.jpg",
      "https://piter3tn.ru/image/cache/catalog/3tn_ru/wa-data/public/shop/products/59/07/759/images/5715/5715.970-1000x1000.jpg",
      "https://piter3tn.ru/image/cache/catalog/3tn_ru/wa-data/public/shop/products/59/07/759/images/9422/9422.970-1000x1000.jpg"
    ],
    "characteristics": [
      {
        "name": "Высота поддона",
        "value": "170 мм"
      },
      {
        "name": "Глубина поддона",
        "value": "65 мм"
      },
      {
        "name": "Диаметр слива",
        "value": "90 мм"
      },
      {
        "name": "Длина",
        "value": "800 мм"
      },
      {
        "name": "Материал",
        "value": "Закалённое стекло, металлический профиль, акрил"
      },
      {
        "name": "Размер",
        "value": "120х80"
      },
      {
        "name": "Смеситель (душевой набор)",
        "value": "Triton DN4 с верхним душем"
      },
      {
        "name": "Тип (цвет, рисунок) переднего стекла",
        "value": "Полосы"
      },
      {
        "name": "Тип кабины",
        "value": "Закрытая кабина"
      }
    ]
  },
  {
    "id": 0,
    "name": "Душевая кабина Тритон Коралл 120х80 (правая) В (средний поддон с сиденьем)",
    "price": 46350,
    "code": "DK236",
    "brandId": "triton",
    "category": "dushevye-kabiny",
    "subcategory": "С низким поддоном",
    "inStock": false,
    "unit": "шт",
    "warranty": true,
    "description": "Душевая кабина Triton (Душевая кабина Тритон Коралл 120х80 (правая) В (средний поддон с сиденьем)). Надежное закаленное стекло, усиленный акриловый поддон с металлическим каркасом, качественные ролики и заводская гарантия производителя.",
    "image": "https://piter3tn.ru/image/cache/catalog/image/catalog/product//dusheviye/korall/41-500x500.png",
    "characteristics": [
      {
        "name": "Высота поддона",
        "value": "310 мм"
      },
      {
        "name": "Глубина поддона",
        "value": "200 мм"
      },
      {
        "name": "Диаметр слива",
        "value": "50 мм"
      },
      {
        "name": "Длина",
        "value": "1200 мм"
      },
      {
        "name": "Материал",
        "value": "Закалённое стекло, металлический профиль, акрил"
      },
      {
        "name": "Размер",
        "value": "120х80"
      },
      {
        "name": "Смеситель (душевой набор)",
        "value": "Triton DN4 с верхним душем"
      },
      {
        "name": "Тип (цвет, рисунок) переднего стекла",
        "value": "Мозаика"
      },
      {
        "name": "Тип кабины",
        "value": "Закрытая кабина"
      }
    ]
  },
  {
    "id": 0,
    "name": "Душевая кабина Тритон Полосы 90*90 Б (9 мест+сифон D50)",
    "price": 39410,
    "code": "DK155",
    "brandId": "triton",
    "category": "dushevye-kabiny",
    "subcategory": "С высоким поддоном",
    "inStock": false,
    "unit": "шт",
    "warranty": true,
    "description": "Душевая кабина Triton (Душевая кабина Тритон Полосы 90*90 Б (9 мест+сифон D50)). Надежное закаленное стекло, усиленный акриловый поддон с металлическим каркасом, качественные ролики и заводская гарантия производителя.",
    "image": "https://piter3tn.ru/image/cache/catalog/3tn_ru/wa-data/public/shop/products/47/06/647/images/10959/10959.970-1000x1000.jpg",
    "gallery": [
      "https://piter3tn.ru/image/cache/catalog/3tn_ru/wa-data/public/shop/products/47/06/647/images/10959/10959.970-1000x1000.jpg",
      "https://piter3tn.ru/image/cache/catalog/3tn_ru/wa-data/public/shop/products/47/06/647/images/10960/10960.970-1000x1000.jpg",
      "https://piter3tn.ru/image/cache/catalog/3tn_ru/wa-data/public/shop/products/47/06/647/images/10208/10208.970-1000x1000.jpg",
      "https://piter3tn.ru/image/cache/catalog/3tn_ru/wa-data/public/shop/products/47/06/647/images/10209/10209.970-1000x1000.jpg",
      "https://piter3tn.ru/image/cache/catalog/3tn_ru/wa-data/public/shop/products/47/06/647/images/10211/10211.970-1000x1000.jpg",
      "https://piter3tn.ru/image/cache/catalog/3tn_ru/wa-data/public/shop/products/47/06/647/images/11549/11549.970-1000x1000.jpg",
      "https://piter3tn.ru/image/cache/catalog/3tn_ru/wa-data/public/shop/products/47/06/647/images/11548/11548.970-1000x1000.jpg",
      "https://piter3tn.ru/image/cache/catalog/3tn_ru/wa-data/public/shop/products/47/06/647/images/9898/9898.970-1000x1000.jpg"
    ],
    "characteristics": [
      {
        "name": "Высота поддона",
        "value": "450 мм"
      },
      {
        "name": "Глубина поддона",
        "value": "350 мм"
      },
      {
        "name": "Диаметр слива",
        "value": "50 мм"
      },
      {
        "name": "Длина",
        "value": "900 мм"
      },
      {
        "name": "Материал",
        "value": "Закалённое стекло, металлический профиль, акрил"
      },
      {
        "name": "Размер",
        "value": "90х90"
      },
      {
        "name": "Тип (цвет, рисунок) переднего стекла",
        "value": "Полосы"
      },
      {
        "name": "Тип кабины",
        "value": "Закрытая кабина"
      },
      {
        "name": "Тип поддона",
        "value": "Глубокий"
      }
    ]
  },
  {
    "id": 0,
    "name": "Душевая кабина Тритон Прайм-Блэк М3 90*90А",
    "price": 47350,
    "code": "DK401",
    "brandId": "triton",
    "category": "dushevye-kabiny",
    "subcategory": "С низким поддоном",
    "inStock": false,
    "unit": "шт",
    "warranty": true,
    "description": "Душевая кабина Triton (Душевая кабина Тритон Прайм-Блэк М3 90*90А). Надежное закаленное стекло, усиленный акриловый поддон с металлическим каркасом, качественные ролики и заводская гарантия производителя.",
    "image": "https://piter3tn.ru/image/cache/catalog/3tn_ru/wa-data/public/shop/products/70/11/1170/images/11802/11802.970-1000x1000.png",
    "gallery": [
      "https://piter3tn.ru/image/cache/catalog/3tn_ru/wa-data/public/shop/products/70/11/1170/images/11802/11802.970-1000x1000.png",
      "https://piter3tn.ru/image/cache/catalog/3tn_ru/wa-data/public/shop/products/70/11/1170/images/11801/11801.970-1000x1000.png",
      "https://piter3tn.ru/image/cache/catalog/3tn_ru/wa-data/public/shop/products/70/11/1170/images/11803/11803.970-1000x1000.jpg",
      "https://piter3tn.ru/image/cache/catalog/3tn_ru/wa-data/public/shop/products/70/11/1170/images/11804/11804.970-1000x1000.jpg",
      "https://piter3tn.ru/image/cache/catalog/3tn_ru/wa-data/public/shop/products/70/11/1170/images/11806/11806.970-1000x1000.jpg",
      "https://piter3tn.ru/image/cache/catalog/3tn_ru/wa-data/public/shop/products/70/11/1170/images/11794/11794.970-1000x1000.jpg",
      "https://piter3tn.ru/image/cache/catalog/3tn_ru/wa-data/public/shop/products/70/11/1170/images/11807/11807.970-1000x1000.jpg",
      "https://piter3tn.ru/image/cache/catalog/3tn_ru/wa-data/public/shop/products/70/11/1170/images/11805/11805.970-1000x1000.jpg"
    ],
    "characteristics": [
      {
        "name": "Высота поддона",
        "value": "170 мм"
      },
      {
        "name": "Глубина поддона",
        "value": "45 мм"
      },
      {
        "name": "Диаметр слива",
        "value": "90 мм"
      },
      {
        "name": "Длина",
        "value": "900 мм"
      },
      {
        "name": "Материал",
        "value": "Закалённое стекло, металлический профиль, акрил"
      },
      {
        "name": "Размер",
        "value": "90х90"
      },
      {
        "name": "Тип (цвет, рисунок) переднего стекла",
        "value": "Прозрачное"
      },
      {
        "name": "Тип кабины",
        "value": "Закрытая кабина"
      },
      {
        "name": "Тип поддона",
        "value": "Низкий"
      }
    ]
  },
  {
    "id": 0,
    "name": "Душевая кабина Тритон Стандарт Полосы 90х90 В",
    "price": 40680,
    "code": "DK138",
    "brandId": "triton",
    "category": "dushevye-kabiny",
    "subcategory": "С средним поддоном",
    "inStock": false,
    "unit": "шт",
    "warranty": true,
    "description": "Душевая кабина Triton (Душевая кабина Тритон Стандарт Полосы 90х90 В). Надежное закаленное стекло, усиленный акриловый поддон с металлическим каркасом, качественные ролики и заводская гарантия производителя.",
    "image": "https://piter3tn.ru/image/cache/catalog/3tn_ru/wa-data/public/shop/products/52/06/652/images/10953/10953.970-1000x1000.jpg",
    "gallery": [
      "https://piter3tn.ru/image/cache/catalog/3tn_ru/wa-data/public/shop/products/52/06/652/images/10953/10953.970-1000x1000.jpg",
      "https://piter3tn.ru/image/cache/catalog/3tn_ru/wa-data/public/shop/products/52/06/652/images/10954/10954.970-1000x1000.jpg",
      "https://piter3tn.ru/image/cache/catalog/3tn_ru/wa-data/public/shop/products/52/06/652/images/10195/10195.970-1000x1000.jpg",
      "https://piter3tn.ru/image/cache/catalog/3tn_ru/wa-data/public/shop/products/52/06/652/images/10194/10194.970-1000x1000.jpg",
      "https://piter3tn.ru/image/cache/catalog/3tn_ru/wa-data/public/shop/products/52/06/652/images/10197/10197.970-1000x1000.png",
      "https://piter3tn.ru/image/cache/catalog/3tn_ru/wa-data/public/shop/products/52/06/652/images/10196/10196.970-1000x1000.jpg",
      "https://piter3tn.ru/image/cache/catalog/3tn_ru/wa-data/public/shop/products/52/06/652/images/11551/11551.970-1000x1000.jpg",
      "https://piter3tn.ru/image/cache/catalog/3tn_ru/wa-data/public/shop/products/52/06/652/images/11550/11550.970-1000x1000.jpg"
    ],
    "characteristics": [
      {
        "name": "Высота поддона",
        "value": "310 мм"
      },
      {
        "name": "Глубина поддона",
        "value": "200 мм"
      },
      {
        "name": "Диаметр слива",
        "value": "50 мм"
      },
      {
        "name": "Длина",
        "value": "900 мм"
      },
      {
        "name": "Материал",
        "value": "Закалённое стекло, металлический профиль, акрил"
      },
      {
        "name": "Размер",
        "value": "90х90"
      },
      {
        "name": "Смеситель (душевой набор)",
        "value": "Triton DN4 с верхним душем"
      },
      {
        "name": "Тип (цвет, рисунок) переднего стекла",
        "value": "Узорчатое"
      },
      {
        "name": "Тип кабины",
        "value": "Закрытая кабина"
      }
    ]
  },
  {
    "id": 0,
    "name": "Душевая кабина Тритон Стандарт Полосы 100х100 В",
    "price": 44750,
    "code": "DK172",
    "brandId": "triton",
    "category": "dushevye-kabiny",
    "subcategory": "С средним поддоном",
    "inStock": false,
    "unit": "шт",
    "warranty": true,
    "description": "Душевая кабина Triton (Душевая кабина Тритон Стандарт Полосы 100х100 В). Надежное закаленное стекло, усиленный акриловый поддон с металлическим каркасом, качественные ролики и заводская гарантия производителя.",
    "image": "https://piter3tn.ru/image/cache/catalog/3tn_ru/wa-data/public/shop/products/24/07/724/images/10952/10952.970-1000x1000.jpg",
    "gallery": [
      "https://piter3tn.ru/image/cache/catalog/3tn_ru/wa-data/public/shop/products/24/07/724/images/10952/10952.970-1000x1000.jpg",
      "https://piter3tn.ru/image/cache/catalog/3tn_ru/wa-data/public/shop/products/24/07/724/images/9534/9534.970-1000x1000.jpg",
      "https://piter3tn.ru/image/cache/catalog/3tn_ru/wa-data/public/shop/products/24/07/724/images/9532/9532.970-1000x1000.jpg",
      "https://piter3tn.ru/image/cache/catalog/3tn_ru/wa-data/public/shop/products/24/07/724/images/11556/11556.970-1000x1000.jpg",
      "https://piter3tn.ru/image/cache/catalog/3tn_ru/wa-data/public/shop/products/24/07/724/images/11557/11557.970-1000x1000.jpg",
      "https://piter3tn.ru/image/cache/catalog/3tn_ru/wa-data/public/shop/products/24/07/724/images/9908/9908.970-1000x1000.jpg",
      "https://piter3tn.ru/image/cache/catalog/3tn_ru/wa-data/public/shop/products/24/07/724/images/10299/10299.970-1000x1000.jpg",
      "https://piter3tn.ru/image/cache/catalog/3tn_ru/wa-data/public/shop/products/24/07/724/images/9536/9536.970-1000x1000.jpg"
    ],
    "characteristics": [
      {
        "name": "Высота поддона",
        "value": "310 мм"
      },
      {
        "name": "Глубина поддона",
        "value": "200 мм"
      },
      {
        "name": "Диаметр слива",
        "value": "50 мм"
      },
      {
        "name": "Длина",
        "value": "1000 мм"
      },
      {
        "name": "Материал",
        "value": "Закалённое стекло, металлический профиль, акрил"
      },
      {
        "name": "Размер",
        "value": "100х100"
      },
      {
        "name": "Смеситель (душевой набор)",
        "value": "Triton DN4 с верхним душем"
      },
      {
        "name": "Тип (цвет, рисунок) переднего стекла",
        "value": "Узорчатое"
      },
      {
        "name": "Тип кабины",
        "value": "Закрытая кабина"
      }
    ]
  },
  {
    "id": 0,
    "name": "Душевая кабина Тритон Прайм-Сатин М3 90*90А",
    "price": 47520,
    "code": "DK402",
    "brandId": "triton",
    "category": "dushevye-kabiny",
    "subcategory": "С низким поддоном",
    "inStock": false,
    "unit": "шт",
    "warranty": true,
    "description": "Душевая кабина Triton (Душевая кабина Тритон Прайм-Сатин М3 90*90А). Надежное закаленное стекло, усиленный акриловый поддон с металлическим каркасом, качественные ролики и заводская гарантия производителя.",
    "image": "https://piter3tn.ru/image/cache/catalog/3tn_ru/wa-data/public/shop/products/71/11/1171/images/11816/11816.970-1000x1000.png",
    "gallery": [
      "https://piter3tn.ru/image/cache/catalog/3tn_ru/wa-data/public/shop/products/71/11/1171/images/11816/11816.970-1000x1000.png",
      "https://piter3tn.ru/image/cache/catalog/3tn_ru/wa-data/public/shop/products/71/11/1171/images/11817/11817.970-1000x1000.png",
      "https://piter3tn.ru/image/cache/catalog/3tn_ru/wa-data/public/shop/products/71/11/1171/images/11818/11818.970-1000x1000.jpg",
      "https://piter3tn.ru/image/cache/catalog/3tn_ru/wa-data/public/shop/products/71/11/1171/images/11819/11819.970-1000x1000.jpg",
      "https://piter3tn.ru/image/cache/catalog/3tn_ru/wa-data/public/shop/products/71/11/1171/images/11821/11821.970-1000x1000.jpg",
      "https://piter3tn.ru/image/cache/catalog/3tn_ru/wa-data/public/shop/products/71/11/1171/images/11814/11814.970-1000x1000.jpg",
      "https://piter3tn.ru/image/cache/catalog/3tn_ru/wa-data/public/shop/products/71/11/1171/images/11815/11815.970-1000x1000.jpg",
      "https://piter3tn.ru/image/cache/catalog/3tn_ru/wa-data/public/shop/products/71/11/1171/images/11820/11820.970-1000x1000.jpg"
    ],
    "characteristics": [
      {
        "name": "Высота поддона",
        "value": "170 мм"
      },
      {
        "name": "Глубина поддона",
        "value": "45 мм"
      },
      {
        "name": "Диаметр слива",
        "value": "90 мм"
      },
      {
        "name": "Длина",
        "value": "900 мм"
      },
      {
        "name": "Материал",
        "value": "Закалённое стекло, металлический профиль, акрил"
      },
      {
        "name": "Размер",
        "value": "90х90"
      },
      {
        "name": "Тип (цвет, рисунок) переднего стекла",
        "value": "Прозрачное"
      },
      {
        "name": "Тип кабины",
        "value": "Закрытая кабина"
      },
      {
        "name": "Тип поддона",
        "value": "Низкий"
      }
    ]
  }
];
