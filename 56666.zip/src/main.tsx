import { Component, StrictMode, type ErrorInfo, type ReactNode } from "react";
import { createRoot } from "react-dom/client";
import "./index.css";
import App from "./App";

interface Props {
  children: ReactNode;
}

interface State {
  hasError: boolean;
  error: Error | null;
}

class RootErrorBoundary extends Component<Props, State> {
  constructor(props: Props) {
    super(props);
    this.state = { hasError: false, error: null };
  }

  static getDerivedStateFromError(error: Error): State {
    return { hasError: true, error };
  }

  componentDidCatch(error: Error, errorInfo: ErrorInfo) {
    console.error("Root error caught:", error, errorInfo);
  }

  render() {
    if (this.state.hasError) {
      return (
        <div className="flex min-h-screen flex-col items-center justify-center bg-[#f2f6f8] p-4 text-center">
          <div className="max-w-md rounded-3xl bg-white p-6 shadow-xl ring-1 ring-slate-100">
            <div className="mx-auto flex h-14 w-14 items-center justify-center rounded-2xl bg-teal-50 text-teal-700">
              <svg width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                <circle cx="12" cy="12" r="10" />
                <line x1="12" y1="8" x2="12" y2="12" />
                <line x1="12" y1="16" x2="12.01" y2="16" />
              </svg>
            </div>
            <h1 className="mt-4 text-[20px] font-black text-slate-900">Магазин «Водяной»</h1>
            <p className="mt-2 text-[13px] leading-relaxed text-slate-500">
              Произошло обновление данных. Нажмите кнопку ниже, чтобы перезагрузить витрину.
            </p>
            <button
              onClick={() => {
                localStorage.removeItem("vodyanoy_products_v1");
                window.location.reload();
              }}
              className="mt-5 w-full rounded-2xl bg-[#0b2b45] py-3 text-[14px] font-black text-white shadow-md transition hover:bg-[#123a5c] active:scale-95"
            >
              Обновить страницу
            </button>
          </div>
        </div>
      );
    }
    return this.props.children;
  }
}

createRoot(document.getElementById("root")!).render(
  <StrictMode>
    <RootErrorBoundary>
      <App />
    </RootErrorBoundary>
  </StrictMode>
);
