import {
  Car,
  ChevronRight,
  Clock,
  Layers,
  MapPin,
  Navigation,
  Phone,
} from "lucide-react";

export default function ContactsPage({
  onNavigate,
}: {
  onNavigate: (path: string) => void;
}) {
  return (
    <div className="mx-auto max-w-[1400px] px-3.5 py-4 sm:px-6 lg:px-8 lg:py-8">
      {/* Хлебные крошки */}
      <nav className="mb-5 flex items-center gap-1.5 text-[12.5px] font-bold text-slate-400 sm:text-[13px]">
        <button
          onClick={() => onNavigate("/")}
          className="transition hover:text-teal-700"
        >
          Главная
        </button>
        <ChevronRight size={14} className="text-slate-300" />
        <span className="font-extrabold text-slate-700">Контакты</span>
      </nav>

      {/* Карточки отделов по этажам */}
      <section className="mb-8 grid gap-4 md:grid-cols-2 lg:gap-6">
        {/* 1-й этаж */}
        <div className="flex flex-col justify-between rounded-[2rem] bg-white p-6 shadow-[0_4px_24px_rgba(15,60,70,0.06)] ring-1 ring-slate-100 sm:p-7">
          <div>
            <div className="flex items-center justify-between">
              <span className="inline-flex items-center gap-1.5 rounded-full bg-teal-50 px-3.5 py-1 text-[12px] font-black text-teal-800 ring-1 ring-teal-200/70">
                <Layers size={14} /> 1-й этаж
              </span>
              <span className="text-[12px] font-bold text-slate-400">Сантехника и мебель</span>
            </div>

            <h2 className="mt-3 text-[20px] font-black text-slate-900 sm:text-[22px]">
              Сантехника, отопление и кухни
            </h2>
            <p className="mt-2 text-[13px] leading-relaxed text-slate-500">
              Инженерная и бытовая сантехника, душевые кабины, смесители, насосы, мебель для ванных,
              модульные кухни.
            </p>

            <div className="mt-5 rounded-2xl bg-slate-50 p-4">
              <div className="text-[11.5px] font-bold uppercase tracking-wider text-slate-400">
                Прямой номер отдела:
              </div>
              <a
                href="tel:+79213143600"
                className="mt-1 block text-[22px] font-black text-[#0b2b45] transition hover:text-teal-700"
              >
                +7 (921) 314-36-00
              </a>
            </div>
          </div>

          <div className="mt-5">
            <a
              href="tel:+79213143600"
              className="flex w-full items-center justify-center gap-2 rounded-xl bg-teal-600 py-3.5 text-[14px] font-black text-white shadow-md transition hover:bg-teal-700 active:scale-95"
            >
              <Phone size={16} /> Позвонить
            </a>
          </div>
        </div>

        {/* 2-й этаж */}
        <div className="flex flex-col justify-between rounded-[2rem] bg-white p-6 shadow-[0_4px_24px_rgba(15,60,70,0.06)] ring-1 ring-slate-100 sm:p-7">
          <div>
            <div className="flex items-center justify-between">
              <span className="inline-flex items-center gap-1.5 rounded-full bg-amber-50 px-3.5 py-1 text-[12px] font-black text-amber-800 ring-1 ring-amber-200/70">
                <Layers size={14} /> 2-й этаж
              </span>
              <span className="text-[12px] font-bold text-slate-400">Инструмент и электрика</span>
            </div>

            <h2 className="mt-3 text-[20px] font-black text-slate-900 sm:text-[22px]">
              Электроинструмент, метизы и краска
            </h2>
            <p className="mt-2 text-[13px] leading-relaxed text-slate-500">
              Электроинструменты, электротовары, кабель, оснастка, крепеж, метизы, садовый инвентарь,
              краски и кисти.
            </p>

            <div className="mt-5 rounded-2xl bg-slate-50 p-4">
              <div className="text-[11.5px] font-bold uppercase tracking-wider text-slate-400">
                Прямой номер отдела:
              </div>
              <a
                href="tel:+79516785500"
                className="mt-1 block text-[22px] font-black text-[#0b2b45] transition hover:text-amber-800"
              >
                +7 (951) 678-55-00
              </a>
            </div>
          </div>

          <div className="mt-5">
            <a
              href="tel:+79516785500"
              className="flex w-full items-center justify-center gap-2 rounded-xl bg-amber-500 py-3.5 text-[14px] font-black text-white shadow-md transition hover:bg-amber-600 active:scale-95"
            >
              <Phone size={16} /> Позвонить
            </a>
          </div>
        </div>
      </section>

      {/* Адрес, режим работы и как добраться */}
      <section className="mb-8 grid gap-4 lg:grid-cols-3 lg:gap-6">
        <div className="rounded-3xl bg-white p-6 shadow-sm ring-1 ring-slate-100">
          <div className="flex h-11 w-11 items-center justify-center rounded-2xl bg-teal-50 text-teal-700">
            <MapPin size={22} strokeWidth={2.4} />
          </div>
          <h3 className="mt-3.5 text-[17px] font-black text-slate-900">Адрес магазина</h3>
          <p className="mt-1.5 text-[14px] font-bold text-slate-700">
            Ленинградская область, г. Луга, пр. Кирова, д. 80
          </p>
        </div>

        <div className="rounded-3xl bg-white p-6 shadow-sm ring-1 ring-slate-100">
          <div className="flex h-11 w-11 items-center justify-center rounded-2xl bg-sky-50 text-sky-700">
            <Clock size={22} strokeWidth={2.4} />
          </div>
          <h3 className="mt-3.5 text-[17px] font-black text-slate-900">Режим работы</h3>
          <div className="mt-2 space-y-1 text-[13.5px] font-bold text-slate-700">
            <div className="flex items-center justify-between">
              <span>Каждый день:</span>
              <span className="text-[15px] font-black text-[#0b2b45]">08:00 – 20:00</span>
            </div>
          </div>
          <p className="mt-2 text-[12px] font-semibold text-emerald-600">
            • Без выходных, обедов и перерывов
          </p>
        </div>

        <div className="rounded-3xl bg-white p-6 shadow-sm ring-1 ring-slate-100">
          <div className="flex h-11 w-11 items-center justify-center rounded-2xl bg-amber-50 text-amber-700">
            <Car size={22} strokeWidth={2.4} />
          </div>
          <h3 className="mt-3.5 text-[17px] font-black text-slate-900">Парковка</h3>
          <p className="mt-1.5 text-[13.5px] leading-relaxed text-slate-600">
            Перед входом в магазин оборудована <b>бесплатная парковка</b> для клиентов.
          </p>
        </div>
      </section>

      {/* Карта / Схема проезда */}
      <section className="rounded-[2.25rem] bg-[#FAF8F5] p-6 ring-1 ring-[#e8e4dc] sm:p-8">
        <div className="flex flex-col items-start justify-between gap-4 md:flex-row md:items-center">
          <div>
            <span className="text-[12px] font-black uppercase tracking-wider text-teal-700">
              Навигация
            </span>
            <h3 className="mt-1 text-[22px] font-black text-slate-900 sm:text-[26px]">
              Построить маршрут до магазина «Водяной»
            </h3>
            <p className="mt-1 text-[13.5px] text-slate-600">
              Откройте навигатор Яндекс.Карт для удобной поездки
            </p>
          </div>

          <a
            href="https://yandex.ru/maps/?text=Луга+пр+Кирова+80+Водяной"
            target="_blank"
            rel="noopener noreferrer"
            className="flex items-center gap-2 rounded-2xl bg-[#0b2b45] px-6 py-4 text-[14px] font-black text-white shadow-lg transition hover:bg-[#123a5c] active:scale-95"
          >
            <Navigation size={18} /> Открыть в Яндекс.Картах
          </a>
        </div>
      </section>
    </div>
  );
}
