import {
  Calendar,
  CheckCircle2,
  ChevronRight,
  HelpCircle,
  Phone,
  Store,
  Truck,
  Zap,
} from "lucide-react";
import { formatCutoff, formatDeliveryDate, upcomingDeliveries } from "../utils/delivery";

export default function DeliveryPage({
  onNavigate,
  onOpenCatalog,
}: {
  onNavigate: (path: string) => void;
  onOpenCatalog: () => void;
}) {
  const [near, next] = upcomingDeliveries();

  return (
    <div className="mx-auto max-w-[1400px] px-3.5 py-4 sm:px-6 lg:px-8 lg:py-8">
      {/* Хлебные крошки */}
      <nav className="mb-4 flex items-center gap-1.5 text-[12.5px] font-bold text-slate-400 sm:text-[13px]">
        <button
          onClick={() => onNavigate("/")}
          className="transition hover:text-teal-700"
        >
          Главная
        </button>
        <ChevronRight size={14} className="text-slate-300" />
        <span className="font-extrabold text-slate-700">Доставка</span>
      </nav>

      {/* Hero-блок */}
      <section className="mb-8 overflow-hidden rounded-[2.25rem] bg-gradient-to-br from-[#0e2f4a] via-[#104b57] to-[#0d3b44] p-6 text-white shadow-2xl sm:p-8 lg:p-12">
        <div className="max-w-3xl">
          <span className="inline-flex items-center gap-2 rounded-full bg-white/15 px-3.5 py-1 text-[11px] font-black uppercase tracking-wider text-teal-200 backdrop-blur-md">
            <Truck size={14} /> Условия доставки и самовывоза
          </span>
          <h1 className="mt-4 text-[28px] font-black leading-[1.1] tracking-tight text-white sm:text-[38px] lg:text-[46px]">
            Быстро привезём заказ по Луге и Лужскому району
          </h1>
          <p className="mt-4 text-[14px] leading-relaxed text-slate-200 sm:text-[16px]">
            Выбирайте удобный вариант: экспресс-доставка от 30 минут, бесплатный самовывоз из
            магазина или регулярный привоз заказных позиций от заводов-изготовителей.
          </p>
        </div>
      </section>

      {/* 3 главных варианта получения */}
      <section className="mb-8 grid gap-4 md:grid-cols-3 lg:gap-6">
        {/* Вариант 1: Яндекс Доставка */}
        <div className="flex flex-col justify-between rounded-[2rem] bg-[#fdece0] p-6 shadow-sm ring-1 ring-[#f9d7be] sm:p-7">
          <div>
            <div className="flex items-center justify-between">
              <span className="flex h-12 w-12 items-center justify-center rounded-2xl bg-[#fbdcc4] text-[#ff7a1a]">
                <Truck size={24} strokeWidth={2.4} />
              </span>
              <span className="inline-flex items-center gap-1 rounded-full bg-gradient-to-r from-[#ff6a1a] to-[#ff8a1f] px-3 py-1 text-[12px] font-black text-white shadow-sm">
                <Zap size={13} strokeWidth={3} className="fill-white" /> от 200 ₽
              </span>
            </div>

            <h3 className="mt-4 text-[20px] font-black text-slate-900">
              Быстрая доставка по городу
            </h3>
            <p className="mt-1 text-[12.5px] font-bold text-slate-500">
              С помощью сервиса «Яндекс Доставка»
            </p>

            <ul className="mt-4 space-y-2 text-[13px] font-semibold text-slate-700">
              <li className="flex items-start gap-2">
                <CheckCircle2 size={16} className="mt-0.5 shrink-0 text-[#ff7a1a]" />
                <span>Время доставки: <b>от 30 минут</b> после подтверждения</span>
              </li>
              <li className="flex items-start gap-2">
                <CheckCircle2 size={16} className="mt-0.5 shrink-0 text-[#ff7a1a]" />
                <span>Привезём прямо до подъезда или калитки</span>
              </li>
              <li className="flex items-start gap-2">
                <CheckCircle2 size={16} className="mt-0.5 shrink-0 text-[#ff7a1a]" />
                <span>Подходит для труб, фитингов, смесителей, насосов и инструмента</span>
              </li>
            </ul>
          </div>

          <div className="mt-6 border-t border-orange-200/60 pt-4">
            <span className="text-[12px] font-medium text-slate-600">
              Курьер заберёт готовый заказ сразу после сборки
            </span>
          </div>
        </div>

        {/* Вариант 2: Самовывоз */}
        <div className="flex flex-col justify-between rounded-[2rem] bg-white p-6 shadow-[0_4px_24px_rgba(15,60,70,0.06)] ring-1 ring-slate-100 sm:p-7">
          <div>
            <div className="flex items-center justify-between">
              <span className="flex h-12 w-12 items-center justify-center rounded-2xl bg-[#0f2c47] text-white">
                <Store size={24} strokeWidth={2.2} />
              </span>
              <span className="rounded-full bg-emerald-50 px-3 py-1 text-[12px] font-black text-emerald-700 ring-1 ring-emerald-200">
                Бесплатно
              </span>
            </div>

            <h3 className="mt-4 text-[20px] font-black text-slate-900">
              Самовывоз из магазина
            </h3>
            <p className="mt-1 text-[12.5px] font-bold text-slate-500">
              г. Луга, пр. Кирова, д. 80
            </p>

            <ul className="mt-4 space-y-2 text-[13px] font-semibold text-slate-700">
              <li className="flex items-start gap-2">
                <CheckCircle2 size={16} className="mt-0.5 shrink-0 text-emerald-600" />
                <span>Готов к выдаче через <b>15 минут</b> после заказа</span>
              </li>
              <li className="flex items-start gap-2">
                <CheckCircle2 size={16} className="mt-0.5 shrink-0 text-emerald-600" />
                <span>Выдача ежедневно: с 08:00 до 20:00 (без выходных)</span>
              </li>
              <li className="flex items-start gap-2">
                <CheckCircle2 size={16} className="mt-0.5 shrink-0 text-emerald-600" />
                <span>Бесплатная погрузка в ваш автомобиль и проверка комплектности</span>
              </li>
            </ul>
          </div>

          <div className="mt-6 border-t border-slate-100 pt-4">
            <button
              onClick={() => onNavigate("/contacts")}
              className="inline-flex items-center gap-1.5 text-[13px] font-black text-teal-700 transition hover:text-teal-900"
            >
              Схема проезда и режим работы <ChevronRight size={15} />
            </button>
          </div>
        </div>

        {/* Вариант 3: Товары под заказ */}
        <div className="flex flex-col justify-between rounded-[2rem] bg-[#FAF8F5] p-6 shadow-sm ring-1 ring-[#e8e4dc] sm:p-7">
          <div>
            <div className="flex items-center justify-between">
              <span className="flex h-12 w-12 items-center justify-center rounded-2xl bg-amber-100 text-amber-800">
                <Calendar size={24} strokeWidth={2.4} />
              </span>
              <span className="rounded-full bg-amber-500 px-3 py-1 text-[12px] font-black text-white shadow-sm">
                Под заказ
              </span>
            </div>

            <h3 className="mt-4 text-[20px] font-black text-slate-900">
              Поставки от производителей
            </h3>
            <p className="mt-1 text-[12.5px] font-bold text-slate-500">
              Душевые кабины Triton, ванны, котлы
            </p>

            <ul className="mt-4 space-y-2 text-[13px] font-semibold text-slate-700">
              <li className="flex items-start gap-2">
                <CheckCircle2 size={16} className="mt-0.5 shrink-0 text-amber-600" />
                <span>
                  Ближайший привоз:{" "}
                  <b className="text-slate-900">
                    {near ? formatDeliveryDate(near.delivery) : "каждый понедельник"}
                  </b>
                </span>
              </li>
              <li className="flex items-start gap-2">
                <CheckCircle2 size={16} className="mt-0.5 shrink-0 text-amber-600" />
                <span>
                  Заказ до:{" "}
                  <span className="text-slate-600">
                    {near ? formatCutoff(near.cutoff) : "пятницы 09:00"}
                  </span>
                </span>
              </li>
              <li className="flex items-start gap-2">
                <CheckCircle2 size={16} className="mt-0.5 shrink-0 text-amber-600" />
                <span>Бесплатная доставка до нашего магазина в Луге</span>
              </li>
            </ul>
          </div>

          <div className="mt-6 border-t border-amber-200/60 pt-4">
            <span className="text-[12px] font-medium text-slate-600">
              {next && <>Следующий рейс: {formatDeliveryDate(next.delivery)}</>}
            </span>
          </div>
        </div>
      </section>

      {/* Доставка по району */}
      <section className="mb-8 rounded-[2rem] bg-white p-6 shadow-[0_4px_24px_rgba(15,60,70,0.06)] ring-1 ring-slate-100 sm:p-8">
        <h2 className="text-[20px] font-black text-slate-900 sm:text-[24px]">
          Доставка по Лужскому району и Ленинградской области
        </h2>
        <p className="mt-2 text-[13.5px] leading-relaxed text-slate-600 sm:text-[14.5px]">
          Если вам требуется привезти крупную партию труб, утеплителя, ванну или душевую кабину на
          дачу / участок в Лужском районе — мы организуем транспортировку собственным транспортом
          или привлеченным грузовым такси по выгодному тарифу.
        </p>

        <div className="mt-6 grid gap-3 sm:grid-cols-3">
          <div className="rounded-2xl bg-slate-50 p-4">
            <div className="text-[13px] font-bold text-slate-400 uppercase tracking-wider">
              По городу Луга
            </div>
            <div className="mt-1 text-[20px] font-black text-slate-900">от 200 – 300 ₽</div>
            <p className="mt-1 text-[12px] text-slate-500">Доставка в черте города в течение дня</p>
          </div>
          <div className="rounded-2xl bg-slate-50 p-4">
            <div className="text-[13px] font-bold text-slate-400 uppercase tracking-wider">
              Лужский район
            </div>
            <div className="mt-1 text-[20px] font-black text-slate-900">от 35 ₽ / км</div>
            <p className="mt-1 text-[12px] text-slate-500">Точный расчёт километража до вашего СНТ</p>
          </div>
          <div className="rounded-2xl bg-slate-50 p-4">
            <div className="text-[13px] font-bold text-slate-400 uppercase tracking-wider">
              Крупногабарит
            </div>
            <div className="mt-1 text-[20px] font-black text-slate-900">по согласованию</div>
            <p className="mt-1 text-[12px] text-slate-500">Возможна доставка манипулятором</p>
          </div>
        </div>
      </section>

      {/* Вопросы и ответы (FAQ) */}
      <section className="mb-8">
        <h2 className="mb-4 text-[20px] font-black text-slate-900 sm:text-[24px]">
          Часто задаваемые вопросы
        </h2>

        <div className="space-y-3">
          {[
            {
              q: "Как быстро собирается заказ для самовывоза?",
              a: "Если все товары есть в наличии в магазине, сборка занимает не более 15 минут. Вы сразу можете забрать покупку.",
            },
            {
              q: "Можно ли оплатить заказ курьеру при получении?",
              a: "Да, курьерской службе доступна оплата наличными или банковской картой через мобильный терминал/СБП.",
            },
            {
              q: "Что делать, если товар не подошёл по размеру?",
              a: "Вы можете вернуть или обменять не подошедший товар надлежащего качества в течение 14 дней в нашем магазине.",
            },
          ].map((faq, i) => (
            <div
              key={i}
              className="rounded-2xl bg-white p-4.5 shadow-sm ring-1 ring-slate-100 sm:p-5"
            >
              <h3 className="flex items-center gap-2 text-[14.5px] font-black text-slate-900 sm:text-[15.5px]">
                <HelpCircle size={17} className="shrink-0 text-teal-600" />
                {faq.q}
              </h3>
              <p className="mt-2 text-[13px] leading-relaxed text-slate-600 sm:text-[13.5px]">
                {faq.a}
              </p>
            </div>
          ))}
        </div>
      </section>

      {/* CTA */}
      <div className="flex flex-col items-center justify-between gap-4 rounded-[2rem] bg-teal-50/70 p-6 text-center ring-1 ring-teal-100 sm:flex-row sm:text-left sm:p-8">
        <div>
          <h3 className="text-[18px] font-black text-teal-950 sm:text-[20px]">
            Остались вопросы по доставке?
          </h3>
          <p className="mt-1 text-[13px] text-teal-800/80">
            Позвоните нам: оперативно проконсультируем и рассчитаем стоимость.
          </p>
        </div>
        <div className="flex gap-2.5">
          <a
            href="tel:+79213143600"
            className="flex items-center gap-1.5 rounded-xl bg-teal-600 px-5 py-3 text-[13.5px] font-black text-white shadow-md transition hover:bg-teal-700 active:scale-95"
          >
            <Phone size={16} /> +7 (921) 314-36-00
          </a>
          <button
            onClick={onOpenCatalog}
            className="rounded-xl bg-white px-5 py-3 text-[13.5px] font-black text-teal-800 shadow-sm ring-1 ring-teal-200 transition hover:bg-teal-50 active:scale-95"
          >
            Каталог
          </button>
        </div>
      </div>
    </div>
  );
}
