import { useState } from "react";
import { ShieldCheck } from "lucide-react";
import type { Brand } from "../data/catalog";
import { COUNTRY_FLAGS } from "../data/catalog";

/**
 * Блок «Оригинальные товары с гарантией» в карточке товара:
 * имя бренда, логотип, ссылка на все товары бренда и страны происхождения.
 * Дизайн согласован с остальными карточками витрины (большие скругления,
 * мягкая шапка в бирюзовом тоне бренда и чистая типографика).
 */
export default function BrandBlock({
  brand,
  onShowBrand,
}: {
  brand: Brand;
  onShowBrand: () => void;
}) {
  const [infoOpen, setInfoOpen] = useState(false);
  const hasCountries = Boolean(brand.countryOrigin || brand.countryMade);

  return (
    <div className="overflow-hidden rounded-[1.75rem] bg-white shadow-[0_2px_14px_rgba(15,60,70,0.05)] ring-1 ring-slate-100">
      {/* Шапка «Оригинальные товары с гарантией» в бирюзовой гамме сайта */}
      <div className="flex items-center gap-2.5 border-b border-teal-100/70 bg-[#ecf7f7] px-4 py-3 lg:px-5">
        <ShieldCheck size={17} className="shrink-0 text-teal-600" strokeWidth={2.4} />
        <span className="text-[13px] font-black tracking-tight text-slate-900 lg:text-[13.5px]">
          Оригинальные товары с гарантией
        </span>
      </div>

      {/* Тело карточки */}
      <div className="p-4 lg:p-5">
        <div className="flex items-center justify-between gap-4">
          <div className="min-w-0 flex-1">
            <div className="flex items-center gap-1.5">
              <span className="text-[20px] font-black tracking-tight text-slate-900 lg:text-[22px]">
                {brand.name}
              </span>
              {brand.info && (
                <button
                  type="button"
                  onClick={() => setInfoOpen((o) => !o)}
                  className={`flex h-4.5 w-4.5 shrink-0 items-center justify-center rounded-full border text-[10px] font-black transition ${
                    infoOpen
                      ? "border-teal-500 bg-teal-500 text-white"
                      : "border-slate-300 text-slate-400 hover:border-teal-500 hover:text-teal-600"
                  }`}
                  title="О бренде"
                >
                  i
                </button>
              )}
            </div>
            <button
              type="button"
              onClick={onShowBrand}
              className="mt-1 text-[13px] font-semibold text-slate-400 transition hover:text-teal-700 hover:underline"
            >
              Все товары бренда
            </button>
          </div>

          {/* Логотип бренда справа */}
          {brand.logo ? (
            <img
              src={brand.logo}
              alt={brand.name}
              className="h-12 max-h-12 max-w-[48%] shrink-0 object-contain object-right"
              loading="lazy"
            />
          ) : (
            <span className="shrink-0 text-[22px] font-black italic tracking-tight text-slate-800">
              {brand.name}
            </span>
          )}
        </div>

        {/* Раскрывающаяся справка о бренде */}
        {infoOpen && brand.info && (
          <p className="mt-3 rounded-2xl bg-slate-50 p-3 text-[12px] leading-relaxed text-slate-600 ring-1 ring-slate-100">
            {brand.info}
          </p>
        )}

        {/* Страны родина / производство */}
        {hasCountries && (
          <div className="mt-4 space-y-2 border-t border-slate-100 pt-3.5">
            {brand.countryOrigin && (
              <div className="flex items-center gap-2.5 text-[13.5px] font-semibold text-slate-700">
                <span className="text-[17px] leading-none">
                  {COUNTRY_FLAGS[brand.countryOrigin] ?? "🏳️"}
                </span>
                <span>{brand.countryOrigin} — родина бренда</span>
              </div>
            )}
            {brand.countryMade && (
              <div className="flex items-center gap-2.5 text-[13.5px] font-semibold text-slate-700">
                <span className="text-[17px] leading-none">
                  {COUNTRY_FLAGS[brand.countryMade] ?? "🏳️"}
                </span>
                <span>{brand.countryMade} — страна производства</span>
              </div>
            )}
          </div>
        )}
      </div>
    </div>
  );
}
