import { useState } from "react";
import {
  ArrowRight,
  BadgePercent,
  CheckCircle2,
  ChevronRight,
  CreditCard,
  HelpCircle,
  Receipt,
  ShieldCheck,
  Sparkles,
  UserPlus,
  Wallet,
} from "lucide-react";

export default function LoyaltyPage({
  onNavigate,
  onOpenAccount,
  onOpenCatalog,
  logoUrl,
  cardBackgroundUrl,
}: {
  onNavigate: (path: string) => void;
  onOpenAccount: () => void;
  onOpenCatalog: () => void;
  logoUrl?: string;
  cardBackgroundUrl?: string;
}) {
  const [flipped, setFlipped] = useState(false);

  return (
    <div className="mx-auto max-w-[1400px] px-3.5 py-4 sm:px-6 lg:px-8 lg:py-8">
      {/* Хлебные крошки */}
      <nav className="mb-4 flex items-center gap-1.5 text-[12.5px] font-bold text-slate-400 sm:text-[13px]">
        <button
          onClick={() => onNavigate("/")}
          className="transition hover:text-teal-700"
        >
          Главная
        </button>
        <ChevronRight size={14} className="text-slate-300" />
        <span className="font-extrabold text-slate-700">Скидочная карта</span>
      </nav>

      {/* Hero-блок с интерактивной 3D-картой */}
      <section className="mb-8 overflow-hidden rounded-[2.5rem] bg-gradient-to-br from-[#09253c] via-[#0d3f4d] to-[#07242c] p-6 text-white shadow-2xl sm:p-8 lg:p-12">
        <div className="flex flex-col items-center gap-8 lg:flex-row lg:justify-between lg:gap-12">
          {/* Левая часть: описание программы */}
          <div className="max-w-xl text-center lg:text-left">
            <span className="inline-flex items-center gap-2 rounded-full bg-white/15 px-3.5 py-1 text-[11px] font-black uppercase tracking-wider text-amber-300 backdrop-blur-md">
              <Sparkles size={14} /> Клуб постоянных покупателей
            </span>
            <h1 className="mt-4 text-[30px] font-black leading-[1.1] tracking-tight text-white sm:text-[42px] lg:text-[48px]">
              Клубная карта «Водяной» со скидкой 5%
            </h1>
            <p className="mt-4 text-[14px] leading-relaxed text-slate-200 sm:text-[16px]">
              Получайте постоянную скидку 5% на весь ассортимент магазина и сайта. Карта
              привязывается к вашему номеру телефона — её невозможно забыть или потерять.
            </p>

            <div className="mt-6 flex flex-wrap items-center justify-center gap-3 lg:justify-start">
              <button
                onClick={onOpenAccount}
                className="flex items-center gap-2 rounded-2xl bg-gradient-to-r from-amber-400 to-amber-500 px-6 py-4 text-[14px] font-black text-slate-950 shadow-xl shadow-amber-500/25 transition hover:from-amber-300 hover:to-amber-400 active:scale-95 sm:text-[15px]"
              >
                <UserPlus size={18} /> Оформить карту в личном кабинете
              </button>
              <button
                onClick={onOpenCatalog}
                className="rounded-2xl bg-white/15 px-5 py-4 text-[14px] font-black text-white backdrop-blur-md transition hover:bg-white/25 active:scale-95 sm:text-[15px]"
              >
                В каталог со скидкой
              </button>
            </div>
          </div>

          {/* Правая часть: интерактивная карта лояльности */}
          <div className="w-full max-w-[340px] shrink-0 sm:max-w-[380px]">
            <div
              onClick={() => setFlipped((v) => !v)}
              className="cursor-pointer transition-transform duration-300 hover:scale-[1.02]"
              title="Нажмите, чтобы перевернуть карту"
            >
              <div
                className={`relative aspect-[1.586/1] w-full overflow-hidden rounded-[1.75rem] bg-gradient-to-br from-[#123a5c] via-[#0d5964] to-[#072d36] p-5 text-white shadow-2xl shadow-teal-950/50 ring-1 ring-white/20 transition-all duration-700 [transform-style:preserve-3d] ${
                  flipped ? "[transform:rotateY(180deg)]" : ""
                }`}
              >
                {/* Фоновый градиент или кастомный фон */}
                {cardBackgroundUrl ? (
                  <img
                    src={cardBackgroundUrl}
                    alt=""
                    className="absolute inset-0 h-full w-full object-cover opacity-80"
                  />
                ) : (
                  <div className="pointer-events-none absolute inset-0 bg-gradient-to-br from-teal-400/20 via-transparent to-amber-400/20" />
                )}

                {/* Блики карты */}
                <div className="discount-card-gloss" />

                {!flipped ? (
                  <div className="relative z-10 flex h-full flex-col justify-between">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-2">
                        {logoUrl ? (
                          <img src={logoUrl} alt="Водяной" className="h-8 w-auto object-contain" />
                        ) : (
                          <span className="text-[16px] font-black tracking-tight text-white">
                            ВОДЯНОЙ
                          </span>
                        )}
                        <span className="rounded-md bg-white/20 px-2 py-0.5 text-[10px] font-black uppercase tracking-wider text-amber-300 backdrop-blur-sm">
                          КЛУБ
                        </span>
                      </div>
                      <span className="rounded-full bg-amber-400 px-2.5 py-1 text-[12px] font-black text-slate-950 shadow-md">
                        −5%
                      </span>
                    </div>

                    <div className="my-auto">
                      {/* Чип */}
                      <div className="h-7 w-10 rounded-md bg-gradient-to-br from-amber-200 to-amber-400 shadow-inner" />
                    </div>

                    <div className="flex items-end justify-between font-mono text-[12px] text-white/80">
                      <span>ИМЕННАЯ КАРТА</span>
                      <span className="text-[10px] text-white/60">нажмите чтобы повернуть ↺</span>
                    </div>
                  </div>
                ) : (
                  <div className="relative z-10 flex h-full flex-col justify-between [transform:rotateY(180deg)]">
                    <div className="h-8 w-full rounded-md bg-black/60" />
                    <div className="text-[11px] leading-relaxed text-white/80">
                      Магазин сантехники «Водяной»
                      <br />
                      г. Луга, пр. Кирова, д. 80
                    </div>
                    <div className="text-right font-mono text-[11px] text-amber-300">
                      Скидка 5% на все товары
                    </div>
                  </div>
                )}
              </div>
            </div>
            <p className="mt-2.5 text-center text-[11.5px] font-semibold text-slate-400">
              Нажмите на карту, чтобы посмотреть обе стороны
            </p>
          </div>
        </div>
      </section>

      {/* 2 простых способа получить карту */}
      <section className="mb-8">
        <h2 className="mb-4 text-[22px] font-black tracking-tight text-slate-900 sm:text-[28px]">
          Как получить скидочную карту
        </h2>

        <div className="grid gap-4 md:grid-cols-2 lg:gap-6">
          {/* Способ 1: Разовая покупка */}
          <div className="flex flex-col justify-between rounded-[2rem] bg-white p-6 shadow-[0_4px_24px_rgba(15,60,70,0.06)] ring-1 ring-slate-100 sm:p-7">
            <div>
              <span className="inline-flex items-center gap-1.5 rounded-full bg-teal-50 px-3.5 py-1 text-[12px] font-black text-teal-800 ring-1 ring-teal-200/70">
                Способ 1 · Сразу
              </span>
              <h3 className="mt-3 text-[20px] font-black text-slate-900 sm:text-[22px]">
                Разовая покупка от 25 000 ₽
              </h3>
              <p className="mt-2 text-[13.5px] leading-relaxed text-slate-600 sm:text-[14px]">
                Оформите заказ на сумму от 25 000 ₽ (ванна, душевая кабина, комплект труб с
                насосом) — и скидка 5% <b>применится прямо к этому первому заказу</b>. Карта будет
                автоматически привязана к вашему номеру.
              </p>

              <div className="mt-4 flex items-center gap-2 rounded-2xl bg-teal-50/70 p-3.5 text-[13px] font-bold text-teal-800">
                <CheckCircle2 size={18} className="shrink-0 text-teal-600" />
                <span>Экономия от 1 250 ₽ уже с первой покупки</span>
              </div>
            </div>

            <div className="mt-6 border-t border-slate-100 pt-4">
              <button
                onClick={onOpenCatalog}
                className="inline-flex items-center gap-1.5 text-[13.5px] font-black text-teal-700 transition hover:text-teal-900"
              >
                Выбрать товары в каталоге <ArrowRight size={16} />
              </button>
            </div>
          </div>

          {/* Способ 2: Накопление чеков */}
          <div className="flex flex-col justify-between rounded-[2rem] bg-white p-6 shadow-[0_4px_24px_rgba(15,60,70,0.06)] ring-1 ring-slate-100 sm:p-7">
            <div>
              <span className="inline-flex items-center gap-1.5 rounded-full bg-amber-50 px-3.5 py-1 text-[12px] font-black text-amber-800 ring-1 ring-amber-200/70">
                Способ 2 · Накопление
              </span>
              <h3 className="mt-3 text-[20px] font-black text-slate-900 sm:text-[22px]">
                Сумма чеков от 25 000 ₽
              </h3>
              <p className="mt-2 text-[13.5px] leading-relaxed text-slate-600 sm:text-[14px]">
                Покупайте товары для ремонта постепенно: сохраняйте чеки из магазина и загружайте их
                фотографии в личном кабинете. Как только сумма чеков достигнет 25 000 ₽,
                администратор активирует вашу постоянную скидку.
              </p>

              <div className="mt-4 flex items-center gap-2 rounded-2xl bg-amber-50/70 p-3.5 text-[13px] font-bold text-amber-800">
                <Receipt size={18} className="shrink-0 text-amber-600" />
                <span>Чеки суммируются без ограничения по времени</span>
              </div>
            </div>

            <div className="mt-6 border-t border-slate-100 pt-4">
              <button
                onClick={onOpenAccount}
                className="inline-flex items-center gap-1.5 text-[13.5px] font-black text-amber-800 transition hover:text-amber-950"
              >
                Загрузить чек в личном кабинете <ArrowRight size={16} />
              </button>
            </div>
          </div>
        </div>
      </section>

      {/* Преимущества владения картой */}
      <section className="mb-8">
        <h2 className="mb-4 text-[22px] font-black tracking-tight text-slate-900 sm:text-[28px]">
          Преимущества карты «Водяной»
        </h2>

        <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-4 lg:gap-4">
          {[
            {
              icon: BadgePercent,
              title: "Скидка −5% на всё",
              desc: "Действует на сантехнику, инструмент, электрику, крепёж и все остальные категории магазина.",
              color: "bg-teal-50 text-teal-700",
            },
            {
              icon: CreditCard,
              title: "Электронная карта",
              desc: "Привязана к номеру телефона. На кассе достаточно назвать телефон, пластик носить не нужно.",
              color: "bg-sky-50 text-sky-700",
            },
            {
              icon: Wallet,
              title: "Скидка прямо на сайте",
              desc: "При входе в личный кабинет цены в каталоге автоматически показываются с учётом вашей скидки 5%.",
              color: "bg-amber-50 text-amber-700",
            },
            {
              icon: ShieldCheck,
              title: "Бессрочное действие",
              desc: "Карта не сгорает и не требует ежемесячных подтверждений. Скидка закрепляется навсегда.",
              color: "bg-emerald-50 text-emerald-700",
            },
          ].map((item, idx) => (
            <div
              key={idx}
              className="flex flex-col rounded-3xl bg-white p-5 shadow-sm ring-1 ring-slate-100"
            >
              <div
                className={`flex h-11 w-11 items-center justify-center rounded-2xl ${item.color} mb-3`}
              >
                <item.icon size={22} strokeWidth={2.4} />
              </div>
              <h3 className="text-[15px] font-black text-slate-900">{item.title}</h3>
              <p className="mt-1 text-[12.5px] leading-relaxed text-slate-500">{item.desc}</p>
            </div>
          ))}
        </div>
      </section>

      {/* FAQ */}
      <section className="mb-8">
        <h2 className="mb-4 text-[20px] font-black text-slate-900 sm:text-[24px]">
          Вопросы и ответы о карте
        </h2>

        <div className="space-y-3">
          {[
            {
              q: "Как войти в личный кабинет с другого устройства?",
              a: "Введите ваш номер телефона при входе на сайте — система мгновенно найдет вашу карту и историю покупок.",
            },
            {
              q: "Суммируется ли скидка 5% со специальными акциями?",
              a: "Скидка по карте применяется к базовым розничным ценам магазина. Для товаров с глубокой спецценой применяется максимальная выгода.",
            },
            {
              q: "Сколько чеков можно загрузить в кабинет?",
              a: "Количество чеков не ограничено. Загружайте чеки от любых покупок в нашем магазине на 1-м и 2-м этажах.",
            },
          ].map((faq, i) => (
            <div
              key={i}
              className="rounded-2xl bg-white p-4.5 shadow-sm ring-1 ring-slate-100 sm:p-5"
            >
              <h3 className="flex items-center gap-2 text-[14.5px] font-black text-slate-900 sm:text-[15.5px]">
                <HelpCircle size={17} className="shrink-0 text-teal-600" />
                {faq.q}
              </h3>
              <p className="mt-2 text-[13px] leading-relaxed text-slate-600 sm:text-[13.5px]">
                {faq.a}
              </p>
            </div>
          ))}
        </div>
      </section>

      {/* Призыв к действию */}
      <div className="flex flex-col items-center justify-between gap-4 rounded-[2rem] bg-gradient-to-r from-[#0b2b45] to-teal-800 p-6 text-center text-white shadow-xl sm:flex-row sm:p-8 sm:text-left">
        <div>
          <h3 className="text-[20px] font-black sm:text-[24px]">
            Начните экономить на покупках уже сегодня
          </h3>
          <p className="mt-1 text-[13.5px] text-white/85">
            Зарегистрируйтесь по номеру телефона и получите доступ к закрытым привилегиям клуба.
          </p>
        </div>
        <button
          onClick={onOpenAccount}
          className="shrink-0 rounded-2xl bg-amber-400 px-6 py-4 text-[14px] font-black text-slate-950 shadow-lg transition hover:bg-amber-300 active:scale-95"
        >
          Зарегистрироваться
        </button>
      </div>
    </div>
  );
}
