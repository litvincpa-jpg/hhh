import { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import {
  CheckCircle2,
  ChevronDown,
  ChevronRight,
  ChevronUp,
  Clock,
  Heart,
  Minus,
  Plus,
  ShieldCheck,
  ShoppingCart,
  ZoomIn,
} from "lucide-react";
import type { Brand, Product } from "../data/catalog";
import type { ShopCartItem } from "./ShopView";
import { formatDeliveryDate, isPreOrder, upcomingDeliveries } from "../utils/delivery";

export interface SeriesProductItem extends Product {
  sizeLabel: string;
}

export interface ProductSeriesGroup {
  key: string;
  title: string;
  category: string;
  subcategory?: string;
  brandId?: string;
  brand?: Brand | null;
  image?: string;
  gallery?: string[];
  description?: string;
  warranty?: boolean;
  unit?: "шт" | "м";
  items: SeriesProductItem[];
}

const money = (n: number) => n.toLocaleString("ru-RU");

function minMetersOf(p: Product): number {
  return p.minMeters && p.minMeters > 0 ? p.minMeters : 1;
}

/** Строка диаметра внутри блока трубы конкретного производителя */
function SeriesItemRow({
  item,
  inCart,
  onAdd,
  onOpen,
}: {
  item: SeriesProductItem;
  inCart?: ShopCartItem;
  onAdd: (p: Product, times: number) => void;
  onOpen: (p: Product) => void;
}) {
  const step = minMetersOf(item);
  const isM = item.unit === "м";
  const [qty, setQty] = useState(1);

  const preOrder = isPreOrder(item);
  const upcoming = preOrder ? upcomingDeliveries()[0] : null;

  const handleMinus = () => setQty((q) => Math.max(1, q - 1));
  const handlePlus = () => setQty((q) => q + 1);

  const handleAddToCart = () => {
    onAdd(item, qty);
  };

  return (
    <div className="flex flex-col gap-2 rounded-2xl bg-white p-3 transition hover:bg-slate-50/70 sm:flex-row sm:items-center sm:justify-between sm:gap-3.5 sm:p-3.5">
      {/* 1. Диаметр / размер и статус наличия */}
      <div className="min-w-0 sm:w-[160px] lg:w-[180px]">
        <button
          type="button"
          onClick={() => onOpen(item)}
          className="text-left font-black text-slate-900 transition hover:text-teal-700"
        >
          <span className="text-[14.5px] sm:text-[15.5px]">{item.sizeLabel || item.name}</span>
        </button>

        <div className="mt-1 flex items-center gap-1.5 text-[11.5px] font-bold">
          {preOrder ? (
            <span className="inline-flex items-center gap-1 text-amber-700">
              <Clock size={12} className="text-amber-500" />
              <span>
                {upcoming ? `Привоз ${formatDeliveryDate(upcoming.delivery)}` : "Под заказ"}
              </span>
            </span>
          ) : item.inStock ? (
            <span className="inline-flex items-center gap-1 text-emerald-700">
              <CheckCircle2 size={12} className="text-emerald-500" />
              <span>В наличии</span>
            </span>
          ) : (
            <span className="text-slate-400">Нет в наличии</span>
          )}
        </div>
      </div>

      {/* 2. Цена за метр / штуку */}
      <div className="flex items-baseline gap-1.5 sm:w-[140px] sm:flex-col sm:gap-0.5 lg:w-[155px]">
        <div className="flex items-baseline gap-1.5">
          <span className="text-[12px] font-semibold text-slate-500">
            {isM ? "Цена за метр" : "Цена"}:
          </span>
          <span className="text-[17px] font-black tracking-tight text-slate-900 lg:text-[18.5px]">
            {money(item.price)} ₽
          </span>
        </div>
        {item.oldPrice && item.oldPrice > item.price && (
          <span className="text-[11.5px] font-bold text-slate-400 line-through">
            {money(item.oldPrice)} ₽
          </span>
        )}
      </div>

      {/* 3. Счетчик метража + Кнопка «В корзину» */}
      <div className="flex items-center justify-between gap-2.5 sm:justify-end sm:gap-3">
        {(item.inStock || preOrder) && (
          <div className="flex items-center gap-1.5 rounded-xl border border-slate-200/80 bg-slate-50 p-1">
            <button
              type="button"
              onClick={handleMinus}
              className="flex h-7 w-7 items-center justify-center rounded-lg bg-white text-slate-700 shadow-xs transition hover:bg-slate-100 active:scale-90"
              title="Уменьшить"
            >
              <Minus size={12} strokeWidth={2.8} />
            </button>
            <span className="min-w-[44px] text-center font-mono text-[12px] font-black text-slate-900">
              {isM ? `${step * qty} м` : `${qty} шт`}
            </span>
            <button
              type="button"
              onClick={handlePlus}
              className="flex h-7 w-7 items-center justify-center rounded-lg bg-teal-500 text-white shadow-xs transition hover:bg-teal-600 active:scale-90"
              title="Увеличить"
            >
              <Plus size={12} strokeWidth={2.8} />
            </button>
          </div>
        )}

        <motion.button
          whileTap={{ scale: 0.96 }}
          onClick={handleAddToCart}
          disabled={!item.inStock && !preOrder}
          className={`flex min-w-[120px] items-center justify-center gap-1.5 rounded-xl px-3.5 py-2.5 text-[12.5px] font-black text-white shadow-sm transition disabled:from-slate-100 disabled:to-slate-100 disabled:text-slate-400 disabled:shadow-none sm:min-w-[130px] ${
            inCart
              ? "bg-gradient-to-r from-teal-500 to-emerald-600 shadow-teal-600/20 hover:from-teal-600 hover:to-emerald-700"
              : preOrder
              ? "bg-gradient-to-r from-amber-500 to-orange-600 shadow-orange-600/20 hover:from-amber-600 hover:to-orange-700"
              : "bg-[#0b2b45] hover:bg-[#123a5c]"
          }`}
        >
          <ShoppingCart size={14} strokeWidth={2.4} />
          <span>
            {inCart
              ? `В корзине (${isM ? `${inCart.meters} м` : inCart.quantity})`
              : "В корзину"}
          </span>
        </motion.button>

        <button
          type="button"
          onClick={() => onOpen(item)}
          className="hidden h-8 w-8 items-center justify-center rounded-xl text-slate-400 transition hover:bg-slate-100 hover:text-slate-700 active:scale-90 md:flex"
          title="Подробнее о товаре"
        >
          <ChevronRight size={17} />
        </button>
      </div>
    </div>
  );
}

/**
 * Карточка серии труб конкретного производителя (в стиле SantShop):
 * - Сверху: полное название трубы и производителя
 * - Слева: фотография серии
 * - Справа: компактный список всех диаметров с быстрым выбором метража и кнопками «В корзину»
 */
export default function PipeSeriesCard({
  group,
  cart,
  favs,
  onFav,
  onAdd,
  onOpen,
}: {
  group: ProductSeriesGroup;
  cart: ShopCartItem[];
  favs: number[];
  onFav: (id: number) => void;
  onAdd: (p: Product, times: number) => void;
  onOpen: (p: Product) => void;
}) {
  const [expanded, setExpanded] = useState(false);
  const INITIAL_VISIBLE_COUNT = 4;
  const isMulti = group.items.length > INITIAL_VISIBLE_COUNT;
  const visibleItems = isMulti && !expanded ? group.items.slice(0, INITIAL_VISIBLE_COUNT) : group.items;

  const firstItem = group.items[0];
  const isFav = firstItem ? favs.includes(firstItem.id) : false;
  const imageSrc =
    group.image ||
    firstItem?.image ||
    firstItem?.gallery?.[0] ||
    "/images/cat-ppr.png";

  return (
    <div className="mb-4 overflow-hidden rounded-[1.75rem] bg-white p-4 shadow-sm ring-1 ring-slate-100 transition-all hover:shadow-md sm:p-5 lg:p-6">
      {/* Шапка серии: Название трубы конкретного производителя */}
      <div className="mb-3.5 flex flex-wrap items-start justify-between gap-3 border-b border-slate-100 pb-3">
        <div className="min-w-0 flex-1">
          <div className="flex flex-wrap items-center gap-2">
            {group.brand && (
              <span className="rounded-lg bg-teal-50 px-2.5 py-0.5 text-[11px] font-black uppercase tracking-wider text-teal-800 ring-1 ring-teal-100">
                {group.brand.name}
              </span>
            )}
            {group.warranty && (
              <span className="inline-flex items-center gap-1 rounded-lg bg-slate-100 px-2 py-0.5 text-[11px] font-bold text-slate-600">
                <ShieldCheck size={12} className="text-teal-600" /> Гарантия 12 мес
              </span>
            )}
          </div>

          <h3
            onClick={() => firstItem && onOpen(firstItem)}
            className="mt-1.5 cursor-pointer text-[17px] font-black leading-snug tracking-tight text-slate-900 transition hover:text-teal-700 sm:text-[19px] lg:text-[20px]"
          >
            {group.title}
          </h3>

          {group.description && (
            <p className="mt-1 line-clamp-1 text-[12.5px] text-slate-400">
              {group.description}
            </p>
          )}
        </div>

        <div className="flex items-center gap-2">
          <span className="rounded-full bg-slate-100 px-3 py-1 font-mono text-[11.5px] font-bold text-slate-600">
            {group.items.length}{" "}
            {group.items.length === 1
              ? "размер"
              : group.items.length < 5
              ? "диаметра"
              : "диаметров"}
          </span>
        </div>
      </div>

      {/* Тело карточки: фото слева + список диаметров справа */}
      <div className="flex flex-col gap-4 md:flex-row md:items-start lg:gap-6">
        {/* Фотография серии */}
        <div className="relative flex aspect-[4/3] w-full shrink-0 items-center justify-center overflow-hidden rounded-2xl bg-[#FAF8F5] p-3 sm:aspect-square sm:w-[180px] md:w-[200px] lg:w-[230px]">
          <img
            src={imageSrc}
            alt={group.title}
            onClick={() => firstItem && onOpen(firstItem)}
            className="max-h-full max-w-full cursor-pointer object-contain transition-transform duration-500 hover:scale-105"
            loading="lazy"
          />

          {firstItem && (
            <button
              type="button"
              onClick={() => onFav(firstItem.id)}
              className={`absolute right-2.5 top-2.5 z-10 flex h-8 w-8 items-center justify-center rounded-full bg-white shadow-sm ring-1 ring-slate-100 transition active:scale-90 ${
                isFav ? "text-rose-500" : "text-slate-400 hover:text-rose-500"
              }`}
              title="В избранное"
            >
              <Heart
                size={15}
                fill={isFav ? "#f43f5e" : "none"}
                className={isFav ? "text-rose-500" : "currentColor"}
                strokeWidth={2}
              />
            </button>
          )}

          <button
            type="button"
            onClick={() => firstItem && onOpen(firstItem)}
            className="absolute bottom-2.5 left-2.5 flex h-7 w-7 items-center justify-center rounded-full bg-white/90 text-slate-600 shadow-sm backdrop-blur-sm transition hover:bg-white active:scale-90"
            title="Открыть фото"
          >
            <ZoomIn size={14} />
          </button>
        </div>

        {/* Список строк с диаметрами */}
        <div className="min-w-0 flex-1 divide-y divide-slate-100">
          <AnimatePresence initial={false}>
            {visibleItems.map((item) => (
              <SeriesItemRow
                key={item.id}
                item={item}
                inCart={cart.find((c) => c.product.id === item.id)}
                onAdd={onAdd}
                onOpen={onOpen}
              />
            ))}
          </AnimatePresence>

          {isMulti && (
            <div className="pt-2 text-center sm:text-left">
              <button
                type="button"
                onClick={() => setExpanded((v) => !v)}
                className="inline-flex items-center gap-1.5 rounded-xl bg-slate-100 px-4 py-2 text-[12px] font-black text-slate-700 transition hover:bg-slate-200 active:scale-95"
              >
                <span>
                  {expanded
                    ? "Свернуть список"
                    : `Показать все диаметры (${group.items.length})`}
                </span>
                {expanded ? <ChevronUp size={14} /> : <ChevronDown size={14} />}
              </button>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
