import { useEffect, useState } from "react";
import { Calendar, MapPin } from "lucide-react";
import { formatCutoff, formatDeliveryDate, upcomingDeliveries } from "../utils/delivery";

/**
 * Информация о доставке под заказ: две ближайшие доставки и адрес самовывоза.
 * Стиль подогнан к блоку «Быстрая доставка» — светлый скруглённый блок,
 * круглые пастельные иконки. Обновляется каждые 30 секунд.
 */
export default function PreOrderInfo() {
  const [now, setNow] = useState(() => new Date());

  useEffect(() => {
    const t = setInterval(() => setNow(new Date()), 30_000);
    return () => clearInterval(t);
  }, []);

  const [near, next] = upcomingDeliveries(now);
  if (!near) return null;

  return (
    <div className="mt-5 overflow-hidden rounded-[1.75rem] bg-[#faf7f2] px-4 py-4 ring-1 ring-[#efe9df] lg:px-5 lg:py-5">
      {/* Ближайшая доставка */}
      <div className="flex items-start gap-3">
        <span className="flex h-11 w-11 shrink-0 items-center justify-center rounded-full bg-[#fdece0] text-[#ff7a1a] lg:h-12 lg:w-12">
          <Calendar size={20} strokeWidth={2.4} />
        </span>
        <div className="min-w-0 flex-1 pt-0.5">
          <div className="text-[13.5px] font-semibold text-slate-500">Ближайшая доставка</div>
          <div className="mt-0.5 text-[15px] leading-snug text-slate-500 lg:text-[15.5px]">
            <span className="text-[17px] font-black text-slate-900 lg:text-[18px]">
              {formatDeliveryDate(near.delivery)}
            </span>{" "}
            <span className="whitespace-nowrap text-slate-400">
              (при заказе до {formatCutoff(near.cutoff)})
            </span>
          </div>
        </div>
      </div>

      {/* Следующая доставка */}
      {next && (
        <div className="mt-3 flex items-start gap-3">
          <span className="flex h-11 w-11 shrink-0 items-center justify-center rounded-full bg-white text-slate-400 shadow-sm ring-1 ring-[#efe9df] lg:h-12 lg:w-12">
            <Calendar size={20} strokeWidth={2.2} />
          </span>
          <div className="min-w-0 flex-1 pt-0.5">
            <div className="text-[13.5px] font-semibold text-slate-500">Следующая доставка</div>
            <div className="mt-0.5 text-[15px] leading-snug text-slate-500 lg:text-[15.5px]">
              <span className="text-[17px] font-black text-slate-800 lg:text-[18px]">
                {formatDeliveryDate(next.delivery)}
              </span>{" "}
              <span className="whitespace-nowrap text-slate-400">
                (при заказе до {formatCutoff(next.cutoff)})
              </span>
            </div>
          </div>
        </div>
      )}

      {/* Бесплатная доставка в магазин */}
      <div className="mt-3 flex items-start gap-3">
        <span className="flex h-11 w-11 shrink-0 items-center justify-center rounded-full bg-[#0f2c47] text-white lg:h-12 lg:w-12">
          <MapPin size={20} strokeWidth={2.4} />
        </span>
        <div className="min-w-0 flex-1 pt-0.5">
          <div className="text-[14.5px] font-black leading-snug text-slate-900 lg:text-[15px]">
            Бесплатная доставка в магазин «Водяной»
          </div>
          <div className="mt-0.5 text-[12.5px] font-semibold text-slate-500">
            Луга, пр. Кирова, д. 80
          </div>
        </div>
      </div>
    </div>
  );
}
