import {
  BadgePercent,
  Banknote,
  Building2,
  ChevronRight,
  CreditCard,
  FileCheck,
  Lock,
  Phone,
  QrCode,
  ShieldCheck,
} from "lucide-react";

export default function PaymentPage({
  onNavigate,
}: {
  onNavigate: (path: string) => void;
  onOpenCatalog?: () => void;
}) {
  return (
    <div className="mx-auto max-w-[1400px] px-3.5 py-4 sm:px-6 lg:px-8 lg:py-8">
      {/* Хлебные крошки */}
      <nav className="mb-4 flex items-center gap-1.5 text-[12.5px] font-bold text-slate-400 sm:text-[13px]">
        <button
          onClick={() => onNavigate("/")}
          className="transition hover:text-teal-700"
        >
          Главная
        </button>
        <ChevronRight size={14} className="text-slate-300" />
        <span className="font-extrabold text-slate-700">Оплата</span>
      </nav>

      {/* Hero-блок */}
      <section className="mb-8 overflow-hidden rounded-[2.25rem] bg-gradient-to-br from-[#0b2b45] via-[#123e59] to-[#0d3448] p-6 text-white shadow-2xl sm:p-8 lg:p-12">
        <div className="max-w-3xl">
          <span className="inline-flex items-center gap-2 rounded-full bg-white/15 px-3.5 py-1 text-[11px] font-black uppercase tracking-wider text-teal-200 backdrop-blur-md">
            <CreditCard size={14} /> Способы оплаты
          </span>
          <h1 className="mt-4 text-[28px] font-black leading-[1.1] tracking-tight text-white sm:text-[38px] lg:text-[46px]">
            Удобные и безопасные способы оплаты
          </h1>
          <p className="mt-4 text-[14px] leading-relaxed text-slate-200 sm:text-[16px]">
            Принимаем все виды платежей: наличные, банковские карты, QR-код СБП, онлайн-оплату на
            сайте и безналичный расчёт для юридических лиц с НДС и без НДС.
          </p>
        </div>
      </section>

      {/* Для физических лиц */}
      <section className="mb-8">
        <h2 className="mb-4 text-[20px] font-black text-slate-900 sm:text-[24px]">
          Для розничных покупателей
        </h2>

        <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
          <div className="flex flex-col justify-between rounded-3xl bg-white p-5 shadow-sm ring-1 ring-slate-100">
            <div>
              <div className="flex h-11 w-11 items-center justify-center rounded-2xl bg-teal-50 text-teal-700">
                <Banknote size={22} strokeWidth={2.4} />
              </div>
              <h3 className="mt-3 text-[16px] font-black text-slate-900">Наличный расчёт</h3>
              <p className="mt-1.5 text-[12.5px] leading-relaxed text-slate-500">
                Оплата наличными на кассе в магазине при самовывозе или курьеру при получении.
              </p>
            </div>
            <div className="mt-4 border-t border-slate-100 pt-3 text-[11.5px] font-bold text-slate-400">
              Выдаём кассовый чек
            </div>
          </div>

          <div className="flex flex-col justify-between rounded-3xl bg-white p-5 shadow-sm ring-1 ring-slate-100">
            <div>
              <div className="flex h-11 w-11 items-center justify-center rounded-2xl bg-sky-50 text-sky-700">
                <CreditCard size={22} strokeWidth={2.4} />
              </div>
              <h3 className="mt-3 text-[16px] font-black text-slate-900">Банковские карты</h3>
              <p className="mt-1.5 text-[12.5px] leading-relaxed text-slate-500">
                Принимаем карты МИР, Visa, Mastercard через терминал в магазине или мобильный
                терминал курьера.
              </p>
            </div>
            <div className="mt-4 border-t border-slate-100 pt-3 text-[11.5px] font-bold text-slate-400">
              Без дополнительных комиссий
            </div>
          </div>

          <div className="flex flex-col justify-between rounded-3xl bg-white p-5 shadow-sm ring-1 ring-slate-100">
            <div>
              <div className="flex h-11 w-11 items-center justify-center rounded-2xl bg-emerald-50 text-emerald-700">
                <QrCode size={22} strokeWidth={2.4} />
              </div>
              <h3 className="mt-3 text-[16px] font-black text-slate-900">СБП по QR-коду</h3>
              <p className="mt-1.5 text-[12.5px] leading-relaxed text-slate-500">
                Быстрая оплата смартфоном через приложение любого российского банка без ввода данных
                карты.
              </p>
            </div>
            <div className="mt-4 border-t border-slate-100 pt-3 text-[11.5px] font-bold text-slate-400">
              Моментальное зачисление
            </div>
          </div>

          <div className="flex flex-col justify-between rounded-3xl bg-white p-5 shadow-sm ring-1 ring-slate-100">
            <div>
              <div className="flex h-11 w-11 items-center justify-center rounded-2xl bg-indigo-50 text-indigo-700">
                <Lock size={22} strokeWidth={2.4} />
              </div>
              <h3 className="mt-3 text-[16px] font-black text-slate-900">Онлайн на сайте</h3>
              <p className="mt-1.5 text-[12.5px] leading-relaxed text-slate-500">
                Безопасная оплата заказа прямо на сайте через защищённый платёжный шлюз (3D-Secure).
              </p>
            </div>
            <div className="mt-4 border-t border-slate-100 pt-3 text-[11.5px] font-bold text-slate-400">
              Электронный чек на телефон
            </div>
          </div>
        </div>
      </section>

      {/* Для юридических лиц и ИП */}
      <section className="mb-8 rounded-[2rem] bg-white p-6 shadow-[0_4px_24px_rgba(15,60,70,0.06)] ring-1 ring-slate-100 sm:p-8">
        <div className="flex flex-col gap-6 lg:flex-row lg:items-center lg:justify-between">
          <div className="max-w-2xl">
            <span className="inline-flex items-center gap-1.5 rounded-full bg-slate-100 px-3 py-1 text-[11.5px] font-bold text-slate-700">
              <Building2 size={14} /> Для организаций и предпринимателей
            </span>
            <h2 className="mt-2 text-[20px] font-black text-slate-900 sm:text-[24px]">
              Безналичный расчёт для юридических лиц и ИП
            </h2>
            <p className="mt-2 text-[13.5px] leading-relaxed text-slate-600">
              Работаем с монтажными бригадами, строительными компаниями, ЖКХ и коммерческими
              организациями. Выставляем счёт на оплату с НДС или без НДС, резервируем товар на
              складе и предоставляем полный комплект бухгалтерских документов (УПД, накладные).
            </p>

            <ul className="mt-4 space-y-2 text-[13px] font-semibold text-slate-700">
              <li className="flex items-center gap-2">
                <FileCheck size={16} className="text-teal-600" />
                <span>Электронный документооборот (ЭДО СБИС / Диадок) или оригиналы документов</span>
              </li>
              <li className="flex items-center gap-2">
                <FileCheck size={16} className="text-teal-600" />
                <span>Резервирование продукции до 3 рабочих дней</span>
              </li>
              <li className="flex items-center gap-2">
                <FileCheck size={16} className="text-teal-600" />
                <span>Специальные оптовые условия при регулярных заказах</span>
              </li>
            </ul>
          </div>

          <div className="shrink-0 rounded-2xl bg-slate-50 p-5 ring-1 ring-slate-200/60 lg:w-[320px]">
            <h3 className="text-[14px] font-black text-slate-800">Запросить счёт на оплату</h3>
            <p className="mt-1 text-[12px] text-slate-500">
              Отправьте реквизиты и список товаров нашему менеджеру
            </p>
            <a
              href="tel:+79213143600"
              className="mt-3.5 flex w-full items-center justify-center gap-2 rounded-xl bg-[#0b2b45] py-3 text-[13.5px] font-black text-white shadow-md transition hover:bg-[#123a5c] active:scale-95"
            >
              <Phone size={15} /> +7 (921) 314-36-00
            </a>
          </div>
        </div>
      </section>

      {/* Скидочная карта */}
      <section className="mb-8 rounded-[2rem] bg-gradient-to-r from-[#0d2f4a] to-teal-800 p-6 text-white shadow-xl sm:p-8">
        <div className="flex flex-col items-start justify-between gap-4 md:flex-row md:items-center">
          <div>
            <span className="inline-flex items-center gap-1.5 rounded-full bg-white/20 px-3 py-1 text-[11px] font-black text-amber-300">
              <BadgePercent size={14} /> Клубная программа
            </span>
            <h3 className="mt-2 text-[20px] font-black text-white sm:text-[24px]">
              Скидка 5% по карте «Водяной»
            </h3>
            <p className="mt-1 text-[13.5px] text-white/85">
              Скидка рассчитывается автоматически при разовой покупке от 25 000 ₽ или по накоплению
              чеков в личном кабинете.
            </p>
          </div>
          <button
            onClick={() => onNavigate("/loyalty")}
            className="rounded-xl bg-amber-400 px-6 py-3.5 text-[14px] font-black text-slate-900 shadow-lg transition hover:bg-amber-300 active:scale-95"
          >
            Подробнее о карте
          </button>
        </div>
      </section>

      {/* Гарантия безопасности */}
      <div className="flex items-center gap-3 rounded-2xl bg-white p-4 shadow-sm ring-1 ring-slate-100">
        <ShieldCheck size={24} className="shrink-0 text-teal-600" />
        <p className="text-[12.5px] text-slate-600">
          Все платежи на сайте обрабатываются в соответствии с федеральным законом № 54-ФЗ.
          Персональные данные защищены по стандарту PCI DSS.
        </p>
      </div>
    </div>
  );
}
