import {
  Award,
  CheckCircle2,
  ChevronRight,
  Layers,
  MapPin,
  Phone,
  ShieldCheck,
  Store,
  Truck,
  Users,
  Wrench,
  Zap,
} from "lucide-react";

export default function AboutPage({
  onNavigate,
  onOpenCatalog,
}: {
  onNavigate: (path: string) => void;
  onOpenCatalog: () => void;
}) {
  return (
    <div className="mx-auto max-w-[1400px] px-3.5 py-4 sm:px-6 lg:px-8 lg:py-8">
      {/* Хлебные крошки */}
      <nav className="mb-4 flex items-center gap-1.5 text-[12.5px] font-bold text-slate-400 sm:text-[13px]">
        <button
          onClick={() => onNavigate("/")}
          className="transition hover:text-teal-700"
        >
          Главная
        </button>
        <ChevronRight size={14} className="text-slate-300" />
        <span className="font-extrabold text-slate-700">О компании</span>
      </nav>

      {/* Главный Hero-баннер */}
      <section className="relative mb-8 overflow-hidden rounded-[2.25rem] bg-gradient-to-br from-[#0b2b45] via-[#0f4d59] to-[#0a3843] p-6 text-white shadow-2xl sm:p-8 lg:p-12">
        <div className="pointer-events-none absolute -right-20 -top-20 h-80 w-80 rounded-full bg-teal-400/15 blur-3xl" />
        <div className="pointer-events-none absolute -bottom-20 -left-20 h-80 w-80 rounded-full bg-cyan-400/15 blur-3xl" />

        <div className="relative z-10 max-w-3xl">
          <span className="inline-flex items-center gap-2 rounded-full bg-white/15 px-3.5 py-1 text-[11px] font-black uppercase tracking-wider text-teal-200 backdrop-blur-md">
            <Store size={14} /> Магазин «Водяной» · г. Луга
          </span>
          <h1 className="mt-4 text-[30px] font-black leading-[1.1] tracking-tight text-white sm:text-[42px] lg:text-[50px]">
            Надёжная сантехника, инструмент и товары для дома
          </h1>
          <p className="mt-4 text-[14px] leading-relaxed text-slate-200 sm:text-[16px]">
            «Водяной» — это двухэтажный специализированный торговый центр в Луге. Мы помогаем
            грамотно укомплектовать квартиру, загородный дом или строительный объект: от фитинга и
            трубы до душевой кабины, котла и профессионального электроинструмента.
          </p>

          <div className="mt-6 flex flex-wrap items-center gap-3">
            <button
              onClick={onOpenCatalog}
              className="rounded-2xl bg-white px-6 py-3.5 text-[14px] font-black text-slate-900 shadow-xl transition hover:bg-slate-100 active:scale-95 sm:text-[15px]"
            >
              Перейти в каталог товаров
            </button>
            <button
              onClick={() => onNavigate("/contacts")}
              className="flex items-center gap-2 rounded-2xl bg-white/15 px-5 py-3.5 text-[14px] font-black text-white backdrop-blur-md transition hover:bg-white/25 active:scale-95"
            >
              <Phone size={16} /> Контакты и адрес
            </button>
          </div>
        </div>
      </section>

      {/* Секция: 2 этажа магазина */}
      <section className="mb-8">
        <div className="mb-4">
          <h2 className="text-[22px] font-black tracking-tight text-slate-900 lg:text-[28px]">
            Два этажа полезных покупок
          </h2>
          <p className="mt-1 text-[13px] font-medium text-slate-400 lg:text-[14px]">
            Удобное зонирование: быстро находите нужный товар для ремонта и стройки
          </p>
        </div>

        <div className="grid gap-4 md:grid-cols-2 lg:gap-6">
          {/* 1-й этаж */}
          <div className="flex flex-col justify-between rounded-[2rem] bg-white p-6 shadow-[0_4px_24px_rgba(15,60,70,0.06)] ring-1 ring-slate-100 sm:p-7">
            <div>
              <div className="flex items-center justify-between">
                <span className="inline-flex items-center gap-1.5 rounded-full bg-teal-50 px-3 py-1 text-[12px] font-black text-teal-700 ring-1 ring-teal-100">
                  <Layers size={14} /> 1-й этаж
                </span>
                <a
                  href="tel:+79213143600"
                  className="text-[14px] font-black text-teal-700 transition hover:text-teal-900"
                >
                  +7 (921) 314-36-00
                </a>
              </div>
              <h3 className="mt-3 text-[20px] font-black text-slate-900 sm:text-[22px]">
                Сантехника, мебель для ванных и кухни
              </h3>
              <p className="mt-2 text-[13px] leading-relaxed text-slate-600 sm:text-[14px]">
                Всё для водоснабжения, канализации, отопления и красивой ванной комнаты:
              </p>

              <ul className="mt-4 space-y-2 text-[13px] font-semibold text-slate-700 sm:text-[13.5px]">
                <li className="flex items-start gap-2">
                  <CheckCircle2 size={16} className="mt-0.5 shrink-0 text-teal-600" />
                  <span>Трубы и фитинги: полипропилен (PPR), ПНД, металлопластик, латунь</span>
                </li>
                <li className="flex items-start gap-2">
                  <CheckCircle2 size={16} className="mt-0.5 shrink-0 text-teal-600" />
                  <span>Насосы: скважинные (Belamos, TF3), дренажные, фекальные, циркуляционные</span>
                </li>
                <li className="flex items-start gap-2">
                  <CheckCircle2 size={16} className="mt-0.5 shrink-0 text-teal-600" />
                  <span>Душевые кабины, поддоны, стальные и акриловые ванны (ВИЗ Antika, Triton)</span>
                </li>
                <li className="flex items-start gap-2">
                  <CheckCircle2 size={16} className="mt-0.5 shrink-0 text-teal-600" />
                  <span>Смесители, душевые системы, инсталляции, полотенцесушители, радиаторы</span>
                </li>
                <li className="flex items-start gap-2">
                  <CheckCircle2 size={16} className="mt-0.5 shrink-0 text-teal-600" />
                  <span>Мебель для ванных комнат, зеркала с подсветкой, модульные кухни</span>
                </li>
              </ul>
            </div>

            <div className="mt-6 border-t border-slate-100 pt-4">
              <button
                onClick={onOpenCatalog}
                className="inline-flex items-center gap-1.5 text-[13.5px] font-black text-teal-700 transition hover:text-teal-900"
              >
                Смотреть каталог сантехники <ChevronRight size={16} />
              </button>
            </div>
          </div>

          {/* 2-й этаж */}
          <div className="flex flex-col justify-between rounded-[2rem] bg-white p-6 shadow-[0_4px_24px_rgba(15,60,70,0.06)] ring-1 ring-slate-100 sm:p-7">
            <div>
              <div className="flex items-center justify-between">
                <span className="inline-flex items-center gap-1.5 rounded-full bg-amber-50 px-3 py-1 text-[12px] font-black text-amber-800 ring-1 ring-amber-100">
                  <Zap size={14} /> 2-й этаж
                </span>
                <a
                  href="tel:+79516785500"
                  className="text-[14px] font-black text-amber-800 transition hover:text-amber-950"
                >
                  +7 (951) 678-55-00
                </a>
              </div>
              <h3 className="mt-3 text-[20px] font-black text-slate-900 sm:text-[22px]">
                Инструмент, электрика и стройматериалы
              </h3>
              <p className="mt-2 text-[13px] leading-relaxed text-slate-600 sm:text-[14px]">
                Профессиональный инструмент и расходные материалы для монтажа и отделки:
              </p>

              <ul className="mt-4 space-y-2 text-[13px] font-semibold text-slate-700 sm:text-[13.5px]">
                <li className="flex items-start gap-2">
                  <CheckCircle2 size={16} className="mt-0.5 shrink-0 text-amber-600" />
                  <span>Электроинструменты: шуруповерты, перфораторы, УШМ, пилы</span>
                </li>
                <li className="flex items-start gap-2">
                  <CheckCircle2 size={16} className="mt-0.5 shrink-0 text-amber-600" />
                  <span>Электротовары: кабель (ВВГнг, NYM), автоматы, щиты, розетки и выключатели</span>
                </li>
                <li className="flex items-start gap-2">
                  <CheckCircle2 size={16} className="mt-0.5 shrink-0 text-amber-600" />
                  <span>Крепеж и метизы: саморезы, дюбели, анкеры, болты, такелаж</span>
                </li>
                <li className="flex items-start gap-2">
                  <CheckCircle2 size={16} className="mt-0.5 shrink-0 text-amber-600" />
                  <span>Оснастка: буры, диски, коронки, свёрла, пилки, биты</span>
                </li>
                <li className="flex items-start gap-2">
                  <CheckCircle2 size={16} className="mt-0.5 shrink-0 text-amber-600" />
                  <span>Лакокрасочные материалы, герметики, пена, валики, садовый инвентарь</span>
                </li>
              </ul>
            </div>

            <div className="mt-6 border-t border-slate-100 pt-4">
              <a
                href="tel:+79516785500"
                className="inline-flex items-center gap-1.5 text-[13.5px] font-black text-amber-800 transition hover:text-amber-950"
              >
                Узнать наличие на 2-м этаже <ChevronRight size={16} />
              </a>
            </div>
          </div>
        </div>
      </section>

      {/* Преимущества */}
      <section className="mb-8">
        <h2 className="mb-4 text-[22px] font-black tracking-tight text-slate-900 lg:text-[28px]">
          Почему выбирают нас
        </h2>

        <div className="grid grid-cols-2 gap-3 sm:grid-cols-2 lg:grid-cols-4 lg:gap-4">
          {[
            {
              icon: ShieldCheck,
              title: "Официальная гарантия",
              desc: "12 месяцев и более на всю сертифицированную продукцию от производителей.",
              color: "bg-teal-50 text-teal-700",
            },
            {
              icon: Truck,
              title: "Быстрая доставка",
              desc: "По Луге от 30 минут с «Яндекс Доставкой», бесплатный самовывоз в день заказа.",
              color: "bg-emerald-50 text-emerald-700",
            },
            {
              icon: Users,
              title: "Проверенные мастера",
              desc: "Контакты опытных лужских сантехников с отзывами и гарантией на монтаж.",
              color: "bg-sky-50 text-sky-700",
            },
            {
              icon: Award,
              title: "Скидки постоянным клиентам",
              desc: "Клубная карта −5% при покупках от 25 000 ₽ или по сумме чеков.",
              color: "bg-amber-50 text-amber-700",
            },
          ].map((item, idx) => (
            <div
              key={idx}
              className="flex flex-col rounded-3xl bg-white p-4 shadow-sm ring-1 ring-slate-100 sm:p-5"
            >
              <div
                className={`flex h-11 w-11 items-center justify-center rounded-2xl ${item.color} mb-3`}
              >
                <item.icon size={22} strokeWidth={2.4} />
              </div>
              <h3 className="text-[15px] font-black text-slate-900">{item.title}</h3>
              <p className="mt-1 text-[12.5px] leading-relaxed text-slate-500">{item.desc}</p>
            </div>
          ))}
        </div>
      </section>

      {/* Контактная плашка внизу */}
      <section className="rounded-[2rem] bg-[#FAF8F5] p-6 ring-1 ring-[#e8e4dc] sm:p-8">
        <div className="flex flex-col items-start justify-between gap-4 md:flex-row md:items-center">
          <div>
            <div className="flex items-center gap-2 text-[13px] font-bold text-slate-500">
              <MapPin size={16} className="text-teal-600" /> г. Луга, пр. Кирова, д. 80
            </div>
            <h3 className="mt-1 text-[20px] font-black text-slate-900 sm:text-[24px]">
              Ждём вас ежедневно в магазине «Водяной»
            </h3>
            <p className="mt-1 text-[13px] text-slate-500">
              Каждый день: 08:00 – 20:00 (без выходных, обедов и перерывов)
            </p>
          </div>

          <div className="flex flex-wrap gap-2.5">
            <button
              onClick={() => onNavigate("/contacts")}
              className="rounded-xl bg-[#0b2b45] px-5 py-3 text-[13.5px] font-black text-white shadow-md transition hover:bg-[#123a5c] active:scale-95"
            >
              Схема проезда
            </button>
            <button
              onClick={() => onNavigate("/plumbers")}
              className="flex items-center gap-1.5 rounded-xl bg-white px-4 py-3 text-[13.5px] font-black text-slate-700 shadow-sm ring-1 ring-slate-200 transition hover:bg-slate-50 active:scale-95"
            >
              <Wrench size={16} className="text-teal-600" /> База сантехников
            </button>
          </div>
        </div>
      </section>
    </div>
  );
}
