import { useEffect, useState } from "react";
import { DEFAULT_PRODUCTS, type Product } from "../data/catalog";
import { cloudSync } from "../utils/cloudSync";

const STORAGE_KEY = "vodyanoy_products_v1";
const BACKUP_PREFIX = "vodyanoy_backup_prod_";

function saveLocalBackup(data: Product[]) {
  if (!Array.isArray(data) || data.length === 0) return;
  try {
    const backupKey = `${BACKUP_PREFIX}${Date.now()}`;
    localStorage.setItem(backupKey, JSON.stringify(data));

    // Храним до 10 последних бэкапов, старые удаляем
    const allBackupKeys: string[] = [];
    for (let i = 0; i < localStorage.length; i++) {
      const k = localStorage.key(i);
      if (k && k.startsWith(BACKUP_PREFIX)) allBackupKeys.push(k);
    }
    allBackupKeys.sort().reverse();
    while (allBackupKeys.length > 10) {
      const oldKey = allBackupKeys.pop();
      if (oldKey) localStorage.removeItem(oldKey);
    }
  } catch {
    /* ignore storage quota */
  }
}

export function useProducts() {
  const [products, setProducts] = useState<Product[]>(() => {
    try {
      const cached = JSON.parse(localStorage.getItem(STORAGE_KEY) || "[]");
      if (Array.isArray(cached) && cached.length > 0) return cached;
    } catch { /* игнорируем */ }
    return DEFAULT_PRODUCTS;
  });

  const [loading, setLoading] = useState(false);
  const [syncStatus, setSyncStatus] = useState<"synced" | "syncing" | "error">("syncing");

  useEffect(() => {
    let cancelled = false;
    (async () => {
      try {
        setSyncStatus("syncing");
        const cloud = await cloudSync.getProducts();
        if (cancelled) return;

        if (cloud === undefined) {
          setSyncStatus("error");
        } else if (Array.isArray(cloud) && cloud.length > 0) {
          setProducts(cloud);
          localStorage.setItem(STORAGE_KEY, JSON.stringify(cloud));
          setSyncStatus("synced");
        } else {
          // Если в облаке пусто, но есть локальные товары — выгружаем их в облако
          try {
            const cached = JSON.parse(localStorage.getItem(STORAGE_KEY) || "[]");
            if (Array.isArray(cached) && cached.length > 0) {
              setProducts(cached);
              await cloudSync.saveProducts(cached);
            }
          } catch { /* ignore */ }
          setSyncStatus("synced");
        }
      } catch {
        if (!cancelled) setSyncStatus("error");
      }
      if (!cancelled) setLoading(false);
    })();
    return () => { cancelled = true; };
  }, []);

  const save = async (next: Product[]) => {
    setProducts(next);
    localStorage.setItem(STORAGE_KEY, JSON.stringify(next));
    saveLocalBackup(next);
    setSyncStatus("syncing");
    const ok = await cloudSync.saveProducts(next);
    setSyncStatus(ok ? "synced" : "error");
    return ok;
  };

  const importProducts = async (importedList: Product[]) => {
    if (!Array.isArray(importedList)) return false;
    return await save(importedList);
  };

  const updateProduct = (id: number, patch: Partial<Product>) => {
    setProducts((prev) => {
      const next = prev.map((p) => (p.id === id ? { ...p, ...patch } : p));
      save(next);
      return next;
    });
  };

  const addProduct = (p: Omit<Product, "id">) => {
    setProducts((prev) => {
      const nextId = Math.max(0, ...prev.map((x) => x.id)) + 1;
      const next = [...prev, { ...p, id: nextId }];
      save(next);
      return next;
    });
  };

  const deleteProduct = (id: number) => {
    setProducts((prev) => {
      const next = prev.filter((p) => p.id !== id);
      save(next);
      return next;
    });
  };

  const swapProducts = (idA: number, idB: number) => {
    setProducts((prev) => {
      const idxA = prev.findIndex((p) => p.id === idA);
      const idxB = prev.findIndex((p) => p.id === idB);
      if (idxA === -1 || idxB === -1) return prev;
      const next = [...prev];
      [next[idxA], next[idxB]] = [next[idxB], next[idxA]];
      save(next);
      return next;
    });
  };

  const resetCatalog = () => save(DEFAULT_PRODUCTS.map((p) => ({ ...p })));

  const refreshProducts = async () => {
    setSyncStatus("syncing");
    const cloud = await cloudSync.getProducts();
    if (cloud === undefined) {
      setSyncStatus("error");
      return false;
    }
    if (Array.isArray(cloud)) {
      setProducts(cloud);
      localStorage.setItem(STORAGE_KEY, JSON.stringify(cloud));
      setSyncStatus("synced");
      return true;
    }
    return false;
  };

  return {
    products,
    updateProduct,
    addProduct,
    deleteProduct,
    swapProducts,
    resetCatalog,
    refreshProducts,
    importProducts,
    productsLoading: loading,
    productsSyncStatus: syncStatus,
  };
}
