import fs from "node:fs/promises";
import path from "node:path";

const SUPABASE_URL = "https://adajsqmrzwlquvuqzsuw.supabase.co";
const SUPABASE_KEY = "sb_publishable_ffnB-v8ba3VdOwzg9lRJrQ_DCgGdkZT";

async function main() {
  const cabinsRaw = JSON.parse(
    await fs.readFile("scripts/parsed-cabins.json", "utf8")
  );

  let currentId = 1;

  const products = [];

  // ===================== 1. PPR ТРУБЫ И ФИТИНГИ (36+ позиций) =====================
  const pprPipes = [
    // Серия Valtec Стекловолокно PN25
    {
      name: "Труба полипропиленовая Valtec PN25 20 мм (армированная стекловолокном)",
      price: 170,
      code: "VTp.705.0020",
      category: "ppr",
      subcategory: "ppr-pipe",
      brandId: "valtec",
      seriesName: "Труба полипропиленовая Valtec армированная стекловолокном PN25",
      sizeLabel: "20×3,4 мм",
      unit: "м",
      minMeters: 2,
      inStock: true,
      image: "https://piter3tn.ru/image/cache/catalog/3tn_ru/wa-data/public/shop/products/27/11/1127/images/11014/11014.970-1000x1000.jpg",
      description: "Труба полипропиленовая PPR, армированная стекловолокном (PN 25). Применяется в системах питьевого и хозяйственно-питьевого холодного и горячего водоснабжения, отопления.",
      characteristics: [
        { name: "Наружный диаметр", value: "20 мм" },
        { name: "Толщина стенки", value: "3.4 мм" },
        { name: "Номинальное давление", value: "PN 25 (2.5 МПа)" },
        { name: "Рабочая температура", value: "до +90°C" },
        { name: "Армирование", value: "Стекловолокно (PPR-FB-PPR)" },
      ],
    },
    {
      name: "Труба полипропиленовая Valtec PN25 25 мм (армированная стекловолокном)",
      price: 225,
      code: "VTp.705.0025",
      category: "ppr",
      subcategory: "ppr-pipe",
      brandId: "valtec",
      seriesName: "Труба полипропиленовая Valtec армированная стекловолокном PN25",
      sizeLabel: "25×4,2 мм",
      unit: "м",
      minMeters: 2,
      inStock: true,
      description: "Труба PPR армированная стекловолокном 25 мм. Высокая термостойкость и минимальное линейное расширение.",
      characteristics: [
        { name: "Наружный диаметр", value: "25 мм" },
        { name: "Толщина стенки", value: "4.2 мм" },
        { name: "Номинальное давление", value: "PN 25" },
        { name: "Армирование", value: "Стекловолокно" },
      ],
    },
    {
      name: "Труба полипропиленовая Valtec PN25 32 мм (армированная стекловолокном)",
      price: 380,
      code: "VTp.705.0032",
      category: "ppr",
      subcategory: "ppr-pipe",
      brandId: "valtec",
      seriesName: "Труба полипропиленовая Valtec армированная стекловолокном PN25",
      sizeLabel: "32×5,4 мм",
      unit: "м",
      minMeters: 2,
      inStock: true,
      description: "Труба PPR армированная стекловолокном 32 мм для стояков и магистралей.",
      characteristics: [
        { name: "Наружный диаметр", value: "32 мм" },
        { name: "Толщина стенки", value: "5.4 мм" },
        { name: "Номинальное давление", value: "PN 25" },
      ],
    },
    {
      name: "Труба полипропиленовая Valtec PN25 40 мм (армированная стекловолокном)",
      price: 590,
      code: "VTp.705.0040",
      category: "ppr",
      subcategory: "ppr-pipe",
      brandId: "valtec",
      seriesName: "Труба полипропиленовая Valtec армированная стекловолокном PN25",
      sizeLabel: "40×6,7 мм",
      unit: "м",
      minMeters: 2,
      inStock: true,
      description: "Магистральная труба PPR 40 мм.",
      characteristics: [
        { name: "Наружный диаметр", value: "40 мм" },
        { name: "Толщина стенки", value: "6.7 мм" },
      ],
    },

    // Серия Valfex Стекловолокно PN25
    {
      name: "Труба полипропиленовая VALFEX PN25 20 мм (стекловолокно)",
      price: 88,
      code: "VF.PPR.20.25",
      category: "ppr",
      subcategory: "ppr-pipe",
      seriesName: "Труба полипропиленовая армированная стекловолокном (PN 25) VALFEX",
      sizeLabel: "20×3,4 мм",
      unit: "м",
      minMeters: 2,
      inStock: true,
      description: "Труба полипропиленовая армированная стекловолокном VALFEX для отопления и горячего водоснабжения.",
      characteristics: [
        { name: "Диаметр", value: "20 мм" },
        { name: "Давление", value: "PN 25" },
      ],
    },
    {
      name: "Труба полипропиленовая VALFEX PN25 25 мм (стекловолокно)",
      price: 125,
      code: "VF.PPR.25.25",
      category: "ppr",
      subcategory: "ppr-pipe",
      seriesName: "Труба полипропиленовая армированная стекловолокном (PN 25) VALFEX",
      sizeLabel: "25×4,2 мм",
      unit: "м",
      minMeters: 2,
      inStock: true,
      description: "Труба полипропиленовая армированная стекловолокном VALFEX 25 мм.",
      characteristics: [
        { name: "Диаметр", value: "25 мм" },
        { name: "Давление", value: "PN 25" },
      ],
    },
    {
      name: "Труба полипропиленовая VALFEX PN25 32 мм (стекловолокно)",
      price: 205,
      code: "VF.PPR.32.25",
      category: "ppr",
      subcategory: "ppr-pipe",
      seriesName: "Труба полипропиленовая армированная стекловолокном (PN 25) VALFEX",
      sizeLabel: "32×5,4 мм",
      unit: "м",
      minMeters: 2,
      inStock: true,
      description: "Труба полипропиленовая армированная стекловолокном VALFEX 32 мм.",
      characteristics: [
        { name: "Диаметр", value: "32 мм" },
        { name: "Давление", value: "PN 25" },
      ],
    },
    {
      name: "Труба полипропиленовая VALFEX PN25 40 мм (стекловолокно)",
      price: 311,
      code: "VF.PPR.40.25",
      category: "ppr",
      subcategory: "ppr-pipe",
      seriesName: "Труба полипропиленовая армированная стекловолокном (PN 25) VALFEX",
      sizeLabel: "40×6,7 мм",
      unit: "м",
      minMeters: 2,
      inStock: true,
      description: "Труба полипропиленовая армированная стекловолокном VALFEX 40 мм.",
      characteristics: [
        { name: "Диаметр", value: "40 мм" },
        { name: "Давление", value: "PN 25" },
      ],
    },

    // Серия SPK PN20 (для холодной воды)
    {
      name: "Труба полипропиленовая SPK PN20 20 мм",
      price: 75,
      code: "SPK.20.20",
      category: "ppr",
      subcategory: "ppr-pipe",
      seriesName: "Труба полипропиленовая SPK PN20",
      sizeLabel: "20×3,4 мм",
      unit: "м",
      minMeters: 2,
      inStock: true,
      description: "Труба полипропиленовая однослойная SPK PN20 для систем холодного и умеренно горячего водоснабжения.",
      characteristics: [
        { name: "Диаметр", value: "20 мм" },
        { name: "Давление", value: "PN 20" },
      ],
    },
    {
      name: "Труба полипропиленовая SPK PN20 25 мм",
      price: 112,
      code: "SPK.25.20",
      category: "ppr",
      subcategory: "ppr-pipe",
      seriesName: "Труба полипропиленовая SPK PN20",
      sizeLabel: "25×4,2 мм",
      unit: "м",
      minMeters: 2,
      inStock: true,
      description: "Труба полипропиленовая SPK PN20 25 мм.",
      characteristics: [
        { name: "Диаметр", value: "25 мм" },
        { name: "Давление", value: "PN 20" },
      ],
    },
    {
      name: "Труба полипропиленовая SPK PN20 32 мм",
      price: 185,
      code: "SPK.32.20",
      category: "ppr",
      subcategory: "ppr-pipe",
      seriesName: "Труба полипропиленовая SPK PN20",
      sizeLabel: "32×5,4 мм",
      unit: "м",
      minMeters: 2,
      inStock: true,
      description: "Труба полипропиленовая SPK PN20 32 мм.",
      characteristics: [
        { name: "Диаметр", value: "32 мм" },
        { name: "Давление", value: "PN 20" },
      ],
    },

    // Муфты PPR
    { name: "Муфта полипропиленовая соединительная 20 мм", price: 18, code: "PPR-M20", category: "ppr", subcategory: "ppr-coupling", inStock: true, unit: "шт", description: "Муфта PPR прямая 20 мм." },
    { name: "Муфта полипропиленовая соединительная 25 мм", price: 26, code: "PPR-M25", category: "ppr", subcategory: "ppr-coupling", inStock: true, unit: "шт", description: "Муфта PPR прямая 25 мм." },
    { name: "Муфта полипропиленовая соединительная 32 мм", price: 42, code: "PPR-M32", category: "ppr", subcategory: "ppr-coupling", inStock: true, unit: "шт", description: "Муфта PPR прямая 32 мм." },
    { name: "Муфта полипропиленовая переходная 25x20 мм", price: 24, code: "PPR-MR2520", category: "ppr", subcategory: "ppr-coupling", inStock: true, unit: "шт", description: "Редукционная муфта 25х20 мм." },
    { name: "Муфта полипропиленовая переходная 32x25 мм", price: 38, code: "PPR-MR3225", category: "ppr", subcategory: "ppr-coupling", inStock: true, unit: "шт", description: "Редукционная муфта 32х25 мм." },

    // Уголки PPR
    { name: "Уголок полипропиленовый 90° 20 мм", price: 20, code: "PPR-E20-90", category: "ppr", subcategory: "ppr-elbow", inStock: true, unit: "шт", description: "Угольник PPR 90 градусов 20 мм." },
    { name: "Уголок полипропиленовый 90° 25 мм", price: 28, code: "PPR-E25-90", category: "ppr", subcategory: "ppr-elbow", inStock: true, unit: "шт", description: "Угольник PPR 90 градусов 25 мм." },
    { name: "Уголок полипропиленовый 90° 32 мм", price: 48, code: "PPR-E32-90", category: "ppr", subcategory: "ppr-elbow", inStock: true, unit: "шт", description: "Угольник PPR 90 градусов 32 мм." },
    { name: "Уголок полипропиленовый 45° 20 мм", price: 24, code: "PPR-E20-45", category: "ppr", subcategory: "ppr-elbow", inStock: true, unit: "шт", description: "Угольник PPR 45 градусов 20 мм." },
    { name: "Уголок полипропиленовый 45° 25 мм", price: 32, code: "PPR-E25-45", category: "ppr", subcategory: "ppr-elbow", inStock: true, unit: "шт", description: "Угольник PPR 45 градусов 25 мм." },

    // Тройники PPR
    { name: "Тройник полипропиленовый 20 мм", price: 28, code: "PPR-T20", category: "ppr", subcategory: "ppr-cross", inStock: true, unit: "шт", description: "Тройник PPR равнопроходной 20 мм." },
    { name: "Тройник полипропиленовый 25 мм", price: 38, code: "PPR-T25", category: "ppr", subcategory: "ppr-cross", inStock: true, unit: "шт", description: "Тройник PPR равнопроходной 25 мм." },
    { name: "Тройник полипропиленовый 32 мм", price: 62, code: "PPR-T32", category: "ppr", subcategory: "ppr-cross", inStock: true, unit: "шт", description: "Тройник PPR равнопроходной 32 мм." },
    { name: "Тройник полипропиленовый переходной 25x20x25 мм", price: 42, code: "PPR-TR2520", category: "ppr", subcategory: "ppr-cross", inStock: true, unit: "шт", description: "Тройник редукционный 25х20х25 мм." },

    // Американки и резьбовые фитинги PPR
    { name: "Муфта с накидной гайкой (американка) PPR 20x1/2\" ВР", price: 245, code: "PPR-UN20-12", category: "ppr", subcategory: "ppr-union", inStock: true, unit: "шт", description: "Разъемное соединение PPR с латунной резьбой 1/2\"." },
    { name: "Муфта с накидной гайкой (американка) PPR 25x3/4\" ВР", price: 360, code: "PPR-UN25-34", category: "ppr", subcategory: "ppr-union", inStock: true, unit: "шт", description: "Разъемное соединение PPR с латунной резьбой 3/4\"." },
    { name: "Муфта комбинированная с внутренней резьбой 20x1/2\"", price: 145, code: "PPR-MRB20-12", category: "ppr", subcategory: "ppr-union", inStock: true, unit: "шт", description: "Муфта PPR с латунной резьбой 1/2\"." },
    { name: "Муфта комбинированная с наружной резьбой 20x1/2\"", price: 165, code: "PPR-MRE20-12", category: "ppr", subcategory: "ppr-union", inStock: true, unit: "шт", description: "Муфта PPR с наружной латунной резьбой 1/2\"." },

    // Краны PPR
    { name: "Кран шаровой полипропиленовый 20 мм", price: 280, code: "PPR-V20", category: "ppr", subcategory: "ppr-valve", inStock: true, unit: "шт", description: "Кран шаровой PPR 20 мм полнопроходной." },
    { name: "Кран шаровой полипропиленовый 25 мм", price: 390, code: "PPR-V25", category: "ppr", subcategory: "ppr-valve", inStock: true, unit: "шт", description: "Кран шаровой PPR 25 мм полнопроходной." },
    { name: "Кран шаровой полипропиленовый 32 мм", price: 580, code: "PPR-V32", category: "ppr", subcategory: "ppr-valve", inStock: true, unit: "шт", description: "Кран шаровой PPR 32 мм." },

    // Монтажные элементы: планка смесителя, обвод, заглушка, опора
    { name: "Планка смесителя настенная полипропиленовая 20x1/2\" ВР", price: 320, code: "PPR-PL20", category: "ppr", subcategory: "ppr-union", inStock: true, unit: "шт", description: "Комплект для подключения настенного смесителя со стандартным межосевым расстоянием 150 мм." },
    { name: "Обвод полипропиленовый раструбный 20 мм", price: 65, code: "PPR-OB20", category: "ppr", subcategory: "ppr-elbow", inStock: true, unit: "шт", description: "Обвод изогнутый PPR 20 мм для пересечения трубопроводов." },
    { name: "Обвод полипропиленовый раструбный 25 мм", price: 95, code: "PPR-OB25", category: "ppr", subcategory: "ppr-elbow", inStock: true, unit: "шт", description: "Обвод изогнутый PPR 25 мм." },
    { name: "Заглушка полипропиленовая 20 мм", price: 12, code: "PPR-CAP20", category: "ppr", subcategory: "ppr-cap", inStock: true, unit: "шт", description: "Заглушка PPR круглая 20 мм." },
    { name: "Опора (клипса) полипропиленовая для труб 20 мм", price: 8, code: "PPR-CL20", category: "ppr", subcategory: "ppr-cap", inStock: true, unit: "шт", description: "Клипса одинарная для фиксации трубы 20 мм к стене." },
    { name: "Опора (клипса) полипропиленовая для труб 25 мм", price: 11, code: "PPR-CL25", category: "ppr", subcategory: "ppr-cap", inStock: true, unit: "шт", description: "Клипса одинарная для фиксации трубы 25 мм к стене." },
  ];

  for (const p of pprPipes) {
    products.push({ id: currentId++, ...p });
  }

  // ===================== 2. НАСОСЫ (JEMIX + BELAMOS TF3) =====================
  const pumpItems = [
    {
      name: "Фекальный насос JEMIX ФН-125-5 (GS-400)",
      price: 4495,
      oldPrice: 4990,
      code: "GS-400",
      category: "Насосы",
      brandId: "belamos",
      inStock: true,
      unit: "шт",
      warranty: true,
      image: "https://piter3tn.ru/image/cache/catalog/3tn_ru/wa-data/public/shop/products/27/11/1127/images/11014/11014.970-1000x1000.jpg",
      description: "Насос фекальный погружной JEMIX ФН-125-5 предназначен для откачки канализационных, дренажных и грунтовых вод с волокнистыми включениями.",
      characteristics: [
        { name: "Мощность", value: "400 Вт" },
        { name: "Производительность", value: "7.5 м³/ч (125 л/мин)" },
        { name: "Максимальный напор", value: "5 м" },
        { name: "Диаметр патрубка", value: "1\" / 1¼\" / 1½\"" },
      ],
    },
    {
      name: "Скважинный насос Belamos TF3-40 (кабель 20 м)",
      price: 14800,
      code: "TF3-40",
      category: "Насосы",
      brandId: "belamos",
      inStock: true,
      unit: "шт",
      warranty: true,
      description: "Скважинный насос диаметром 3 дюйма (78 мм). Подходит для скважин от 80 мм.",
      characteristics: [
        { name: "Макс. напор", value: "42 м" },
        { name: "Подача", value: "2.7 м³/ч" },
        { name: "Мощность", value: "550 Вт" },
        { name: "Длина кабеля", value: "20 м" },
      ],
    },
    {
      name: "Скважинный насос Belamos TF3-60 (кабель 35 м)",
      price: 18200,
      code: "TF3-60",
      category: "Насосы",
      brandId: "belamos",
      inStock: true,
      unit: "шт",
      warranty: true,
      description: "Глубинный насос Belamos TF3-60 для систем водоснабжения загородного дома.",
      characteristics: [
        { name: "Макс. напор", value: "60 м" },
        { name: "Подача", value: "2.7 м³/ч" },
        { name: "Мощность", value: "800 Вт" },
        { name: "Длина кабеля", value: "35 м" },
      ],
    },
    {
      name: "Скважинный насос Belamos TF3-80 (кабель 50 м)",
      price: 22400,
      code: "TF3-80",
      category: "Насосы",
      brandId: "belamos",
      inStock: true,
      unit: "шт",
      warranty: true,
      description: "Глубинный насос Belamos TF3-80 с кабелем 50 м для глубоких скважин.",
      characteristics: [
        { name: "Макс. напор", value: "85 м" },
        { name: "Подача", value: "2.7 м³/ч" },
        { name: "Мощность", value: "1000 Вт" },
        { name: "Длина кабеля", value: "50 м" },
      ],
    },
  ];

  for (const p of pumpItems) {
    products.push({ id: currentId++, ...p });
  }

  // ===================== 3. ВАННА ВИЗ ANTIKA =====================
  products.push({
    id: currentId++,
    name: "Ванна стальная ВИЗ Antika 170x70 см с ножками",
    price: 12000,
    oldPrice: 14500,
    code: "ANT-17070",
    category: "Ванны, экраны и комплектующие",
    brandId: "antika",
    inStock: true,
    unit: "шт",
    warranty: true,
    description: "Стальная эмалированная ванна Antika 170х70 см от Верх-Исетского металлургического завода (ВИЗ). Прочное стеклокерамическое покрытие, устойчивость к царапинам и бытовой химии, опорные ножки в комплекте.",
    characteristics: [
      { name: "Длина", value: "170 см" },
      { name: "Ширина", value: "70 см" },
      { name: "Глубина", value: "40 см" },
      { name: "Материал", value: "Сталь эмалированная (1.8 мм)" },
      { name: "Объем", value: "180 л" },
      { name: "Цвет", value: "Белый глянцевый" },
    ],
  });

  // ===================== 4. ДУШЕВЫЕ КАБИНЫ TRITON (49 СПАРСЕННЫХ МОДЕЛЕЙ) =====================
  for (const cabin of cabinsRaw) {
    products.push({
      id: currentId++,
      ...cabin,
      // Душевые кабины Triton возим под заказ с календарем поставок
      inStock: false,
    });
  }

  console.log(`Prepared total ${products.length} products!`);
  console.log(
    `Breakdown: PPR (${pprPipes.length}), Pumps (${pumpItems.length}), Bath (1), Triton Cabins (${cabinsRaw.length})`
  );

  // Сохраняем в Supabase
  console.log("Saving full catalog to Supabase...");
  const cfg = { url: SUPABASE_URL, key: SUPABASE_KEY };
  const res = await fetch(`${cfg.url}/rest/v1/vodyanoy_store?on_conflict=key`, {
    method: "POST",
    headers: {
      apikey: cfg.key,
      Authorization: `Bearer ${cfg.key}`,
      "Content-Type": "application/json",
      Prefer: "resolution=merge-duplicates,return=minimal",
    },
    body: JSON.stringify({ key: "products", value: products }),
  });

  if (!res.ok) {
    throw new Error(`Failed to save to Supabase: ${res.status} ${await res.text()}`);
  }

  console.log("SUCCESS! Full catalog saved to Supabase (key: products).");

  // Также обновляем локальный файл экспорта и DEFAULT_PRODUCTS в коде
  await fs.writeFile("scripts/full-catalog.json", JSON.stringify(products, null, 2));
}

main().catch(console.error);
