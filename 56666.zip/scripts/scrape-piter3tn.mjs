import fs from "node:fs/promises";
import path from "node:path";

const SUPABASE_URL = "https://adajsqmrzwlquvuqzsuw.supabase.co";
const SUPABASE_KEY = "sb_publishable_ffnB-v8ba3VdOwzg9lRJrQ_DCgGdkZT";

export async function scrapeCabins() {
  console.log("Fetching sitemap from piter3tn.ru...");
  const sitemapRes = await fetch("https://piter3tn.ru/sitemap.xml", {
    headers: { "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64)" },
  });
  if (!sitemapRes.ok) throw new Error(`Sitemap error: ${sitemapRes.status}`);
  const sitemapText = await sitemapRes.text();
  const locs =
    sitemapText
      .match(/<loc>([^<]+)<\/loc>/g)
      ?.map((l) => l.replace(/<\/?loc>/g, "")) || [];

  const cabinUrls = locs.filter((u) => {
    if (!u.includes("dushevye-kabiny-1/")) return false;
    if (u.includes("komplektuyushchie")) return false;
    const parts = u
      .replace("https://piter3tn.ru/dushevye-kabiny-1/", "")
      .split("/")
      .filter(Boolean);
    return parts.length >= 2;
  });

  console.log(`Found ${cabinUrls.length} candidate URLs for shower cabins.`);

  const cabins = [];
  const seenNames = new Set();
  const concurrency = 10;
  let currentIdx = 0;

  async function worker() {
    while (currentIdx < cabinUrls.length) {
      const myIdx = currentIdx++;
      const url = cabinUrls[myIdx];
      try {
        const res = await fetch(url, {
          headers: { "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64)" },
        });
        if (!res.ok) continue;
        const html = await res.text();

        const titleMatch = html.match(/<h1[^>]*>([^<]+)<\/h1>/i);
        if (!titleMatch) continue;
        const name = titleMatch[1]
          .replace(/&quot;/g, '"')
          .replace(/&amp;/g, "&")
          .replace(/&nbsp;/g, " ")
          .replace(/\s+/g, " ")
          .trim();

        // Must be a shower cabin
        if (!/душев.*кабин/i.test(name)) continue;

        const normalizedName = name.toLowerCase();
        if (seenNames.has(normalizedName)) continue;
        seenNames.add(normalizedName);

        // Price
        let price = 0;
        const priceText =
          html.match(/class="[^"]*price[^"]*"[^>]*>([\s\S]*?)<\/div>/i)?.[1] ||
          html.match(/(\d[\d\s]*)\s*руб/i)?.[1];
        if (priceText) {
          const cleanNum = priceText
            .replace(/<[^>]+>/g, "")
            .replace(/[^\d]/g, "");
          price = parseInt(cleanNum, 10) || 0;
        }

        // Code / Article
        const codeMatch =
          html.match(/Код товара:[^<]*<b>([^<]+)<\/b>/i) ||
          html.match(/Код товара:?\s*([A-Za-z0-9а-яА-Я_-]+)/i);
        const code = codeMatch
          ? codeMatch[1].trim()
          : "DK" + Math.floor(100 + Math.random() * 900);

        // Images
        const imgMatches = Array.from(
          html.matchAll(
            /data-image="([^"]+)"|data-zoom-image="([^"]+)"|href="(https:\/\/piter3tn\.ru\/image\/cache\/catalog\/[^"]+\.(?:jpg|png|webp|jpeg))"/gi
          )
        )
          .map((m) => m[1] || m[2] || m[3])
          .filter(Boolean)
          .filter((u) => u.includes("products/") || u.includes("wa-data/"));
        const uniqueImgs = Array.from(new Set(imgMatches));
        const mainImg =
          uniqueImgs[0] ||
          html.match(/property="og:image"\s+content="([^"]+)"/i)?.[1];

        // Specs
        const characteristics = [];
        const tdMatches = html.matchAll(
          /<td>\s*<small>([^<]+)<\/small>\s*([^<]+)\s*<\/td>/gi
        );
        for (const m of tdMatches) {
          characteristics.push({ name: m[1].trim(), value: m[2].trim() });
        }

        // Subcategory mapping
        let subcategory = "С низким поддоном";
        const subcatMatch = characteristics.find((c) => /поддон/i.test(c.name));
        const poddonVal = (subcatMatch?.value || "").toLowerCase();

        if (poddonVal.includes("средн") || url.includes("srednim")) {
          subcategory = "С средним поддоном";
        } else if (
          poddonVal.includes("высок") ||
          poddonVal.includes("глубок") ||
          url.includes("vysokim")
        ) {
          subcategory = "С высоким поддоном";
        } else if (poddonVal.includes("низк") || url.includes("nizkim")) {
          subcategory = "С низким поддоном";
        }

        cabins.push({
          id: 0, // will assign sequentially
          name,
          price: price || 35000,
          code,
          brandId: "triton",
          category: "dushevye-kabiny",
          subcategory,
          inStock: false,
          unit: "шт",
          warranty: true,
          description: `Душевая кабина Triton (${name}). Надежное закаленное стекло, усиленный акриловый поддон с металлическим каркасом, качественные ролики и заводская гарантия производителя.`,
          image: mainImg,
          gallery: uniqueImgs.length > 1 ? uniqueImgs.slice(0, 8) : undefined,
          characteristics: characteristics.length > 0 ? characteristics : undefined,
        });

        if (cabins.length % 10 === 0) {
          console.log(`Parsed ${cabins.length} shower cabins...`);
        }
      } catch (err) {
        // ignore
      }
    }
  }

  await Promise.all(Array.from({ length: concurrency }, worker));

  console.log(`Finished! Total valid cabins scraped: ${cabins.length}`);
  return cabins;
}

async function run() {
  const cabins = await scrapeCabins();
  await fs.writeFile(
    path.resolve("scripts/parsed-cabins.json"),
    JSON.stringify(cabins, null, 2)
  );
  console.log("Saved parsed-cabins.json!");
}

run().catch(console.error);
