import { mkdir, writeFile } from "node:fs/promises";
import path from "node:path";
import { fileURLToPath } from "node:url";

const OWNER = "9bm9zccw5j-a11y";
const REPOSITORY = "9g-y";
const API_ROOT = `https://api.github.com/repos/${OWNER}/${REPOSITORY}`;
const projectRoot = path.resolve(path.dirname(fileURLToPath(import.meta.url)), "..");

const componentNames = new Set([
  "AdminPanel.tsx",
  "BrandBlock.tsx",
  "BrandsAdmin.tsx",
  "CustomerAccount.tsx",
  "ImageViewer.tsx",
  "LoyaltyCard.tsx",
  "OrdersTab.tsx",
  "PlumbersList.tsx",
  "PreOrderInfo.tsx",
  "PumpCalculator.tsx",
  "ShopView.tsx",
]);

const dataNames = new Set(["catalog.ts", "orders.ts"]);
const utilityNames = new Set([
  "cloudSync.ts",
  "cn.ts",
  "delivery.ts",
  "imageUpload.ts",
  "saveCache.ts",
  "supabase.ts",
  "thumb.ts",
]);

function destinationFor(repositoryPath) {
  const fileName = path.basename(repositoryPath);

  if (repositoryPath.startsWith("src/")) return repositoryPath;
  if (repositoryPath === "App.tsx") return "src/App.tsx";
  if (repositoryPath === "main.tsx") return "src/main.tsx";
  if (repositoryPath === "index.css") return "src/index.css";
  if (repositoryPath === "index.html") return "index.html";
  if (repositoryPath === "vite.config.ts") return null;
  if (componentNames.has(fileName)) return `src/components/${fileName}`;
  if (dataNames.has(fileName)) return `src/data/${fileName}`;
  if (utilityNames.has(fileName)) return `src/utils/${fileName}`;
  if (/^use[A-Z].*\.tsx?$/.test(fileName)) return `src/hooks/${fileName}`;

  // Keep nested files from a newer repository layout in their original folders.
  if (repositoryPath.startsWith("public/")) return repositoryPath;
  if (/\.(png|jpe?g|gif|webp|svg|avif)$/i.test(repositoryPath)) {
    return `public/images/${fileName}`;
  }
  if (/\.tsx$/i.test(fileName)) return `src/components/${fileName}`;
  if (/\.ts$/i.test(fileName)) return `src/utils/${fileName}`;
  return null;
}

async function fetchJson(url) {
  const response = await fetch(url, {
    headers: {
      Accept: "application/vnd.github+json",
      "User-Agent": "vodyanoy-store-puller",
    },
  });
  if (!response.ok) {
    throw new Error(`GitHub API ${response.status}: ${url}`);
  }
  return response.json();
}

async function downloadBytes(url) {
  const response = await fetch(url, {
    headers: { "User-Agent": "vodyanoy-store-puller" },
  });
  if (!response.ok) {
    throw new Error(`GitHub raw ${response.status}: ${url}`);
  }
  return new Uint8Array(await response.arrayBuffer());
}

async function writeRepositoryFile(repositoryPath, commit, outputPath) {
  const rawUrl = `https://raw.githubusercontent.com/${OWNER}/${REPOSITORY}/${commit}/${repositoryPath}`;
  const bytes = await downloadBytes(rawUrl);
  const absolutePath = path.join(projectRoot, outputPath);
  await mkdir(path.dirname(absolutePath), { recursive: true });
  await writeFile(absolutePath, bytes);
  return { repositoryPath, outputPath, bytes: bytes.byteLength };
}

export async function pullFromGithub() {
  const repository = await fetchJson(API_ROOT);
  const tree = await fetchJson(`${API_ROOT}/git/trees/${repository.default_branch}?recursive=1`);

  if (!Array.isArray(tree.tree)) {
    throw new Error("GitHub returned an invalid repository tree");
  }
  if (tree.truncated) {
    throw new Error("GitHub returned a truncated tree; refusing to pull an incomplete project");
  }

  const files = tree.tree
    .filter((entry) => entry.type === "blob")
    .map((entry) => ({ repositoryPath: entry.path, outputPath: destinationFor(entry.path) }))
    .filter((entry) => {
      if (!entry.outputPath) return false;
      return /\.(ts|tsx|css|html)$/i.test(entry.repositoryPath)
        || /^public\/images\//.test(entry.repositoryPath)
        || /\.(png|jpe?g|gif|webp|svg|avif)$/i.test(entry.repositoryPath);
    });

  let completed = 0;
  const results = [];
  const queue = [...files];
  const worker = async () => {
    while (queue.length > 0) {
      const file = queue.shift();
      if (!file) return;
      results.push(await writeRepositoryFile(file.repositoryPath, tree.sha, file.outputPath));
      completed += 1;
      if (!process.env.VODYANO_SILENT_PULL) {
        console.log(`[pull-from-github] ${completed}/${files.length} ${file.repositoryPath} -> ${file.outputPath}`);
      }
    }
  };

  await Promise.all(Array.from({ length: Math.min(8, files.length) }, worker));
  return { commit: tree.sha, files: results };
}

if (process.argv[1] === fileURLToPath(import.meta.url)) {
  pullFromGithub()
    .then(({ commit, files }) => console.log(`[pull-from-github] Pulled ${files.length} files from ${commit}`))
    .catch((error) => {
      console.error("[pull-from-github] Failed:", error);
      process.exitCode = 1;
    });
}